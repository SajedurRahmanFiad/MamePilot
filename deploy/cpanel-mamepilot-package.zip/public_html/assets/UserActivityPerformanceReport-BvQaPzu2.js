import{r as y,ab as se,j as e}from"./vendor-K-96t4is.js";import{u as he,r as be,d as fe,N as ye,z as ve,f as ae,w as re,i as F,fc as je,a9 as ie,o as m,X as Ne,I as we,ag as le,fd as ke,Z as $e,$ as Ae}from"./index-DsOr_3hi.js";import"./Input-CF138f5A.js";import{F as Ce}from"./FilterBar-CY1dlwQB.js";import"./metaAdsCurrency-C9nogOG8.js";import{D as Pe}from"./DynamicFilterBar-D67gasMa.js";import{P as Se}from"./Pagination-Bqay0Phl.js";import{a as Re}from"./router-DvQ5GHgr.js";import"./react-query-Dt6GkCro.js";import"./icons-ZwY3gNqL.js";const Ue=["All Time","Today","This Week","This Month","This Year","Custom"],V="/uploads/Empty_avatar.png",z=r=>ae(r)||"N/A",a=r=>new Intl.NumberFormat("en-BD").format(r),Oe=r=>r==="Income"?"bg-emerald-100 text-emerald-700":r==="Expense"?"bg-rose-100 text-rose-700":r==="Transfer"?"bg-sky-100 text-sky-700":Ae(r),E=r=>r.includes("T")||/\d{2}:\d{2}/.test(r)?z(r):$e(r),Te=(r,t)=>r!=="Custom"?r:t.from&&t.to?`${E(t.from)} to ${E(t.to)}`:t.from?`From ${E(t.from)}`:t.to?`Until ${E(t.to)}`:"Custom Range",i=r=>r.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"),ze=r=>r.replace(/[<>:"/\\|?*]+/g,"-").replace(/\s+/g," ").trim(),X=r=>{if(!r)return"";if(/^(https?:|data:|blob:)/i.test(r)||typeof window>"u")return r;try{return new URL(r,window.location.href).href}catch{return r}},Le=()=>{const r={primary:"#0f2f57",medium:"#3c5a82",dark:"#0c203b",soft:"#ebf4ff"};if(typeof window>"u")return r;const t=window.getComputedStyle(document.documentElement),d=(x,v)=>{const P=t.getPropertyValue(x).trim();return/^#[0-9a-f]{6}$/i.test(P)?P:v};return{primary:d("--primary-color",r.primary),medium:d("--primary-medium",r.medium),dark:d("--primary-dark",r.dark),soft:d("--primary-soft",r.soft)}},Me=r=>{const{report:t,companyName:d,companyLogo:x,generatedAt:v,selectedPeriod:P,businessMode:j,themeColors:c}=r,u=F(t.user.role)?"role-admin":"role-employee",U=X(t.user.image||V),N=X(V),w=X(x),_=`<img src="${i(U)}" alt="${i(t.user.name)}" class="avatar-image" onerror="this.onerror=null;this.src='${i(N)}';" />`,k=[{label:"Orders Created",value:a(t.metrics.ordersCreated),hint:`${a(t.metrics.completedOrders)} completed | ${a(t.metrics.cancelledOrders)} cancelled`,tone:"card-blue"},{label:"Order Value",value:m(t.metrics.orderValue),hint:`${m(t.metrics.orderPaidAmount)} collected`,tone:"card-green"},{label:"Bills Created",value:a(t.metrics.billsCreated),hint:`${m(t.metrics.billValue)} purchase value`,tone:"card-amber"},{label:"Transactions Posted",value:a(t.metrics.transactionsCreated),hint:`${a(t.metrics.activeDays)} active days`,tone:"card-rose"}],B=[["Active days",a(t.metrics.activeDays)],["Unique customers served",a(t.metrics.uniqueCustomers)],[le("Items handled in orders",j),a(t.metrics.orderQuantity)],["Average order value",m(t.metrics.averageOrderValue)],["Completion rate",`${Math.round(t.metrics.completionRate)}%`],["Collection rate",`${Math.round(t.metrics.collectionRate)}%`]],D=[["Completed order value",m(t.metrics.completedOrderValue)],["Purchase settlement rate",`${Math.round(t.metrics.billSettlementRate)}%`],["Income entries",`${a(t.metrics.incomeTransactions)} | ${m(t.metrics.incomeAmount)}`],["Expense entries",`${a(t.metrics.expenseTransactions)} | ${m(t.metrics.expenseAmount)}`],["Transfer entries",`${a(t.metrics.transferTransactions)} | ${m(t.metrics.transferAmount)}`],["Last activity",t.metrics.lastActivity?z(t.metrics.lastActivity):"No activity"]],I=[["On Hold",t.metrics.onHoldOrders],["Processing",t.metrics.processingOrders],["Picked",t.metrics.pickedOrders],["Completed",t.metrics.completedOrders],["Returned",t.metrics.returnedOrders],["Cancelled",t.metrics.cancelledOrders]],g=[["Unique vendors handled",a(t.metrics.uniqueVendors)],["Bills paid amount",m(t.metrics.billPaidAmount)],["First tracked activity",t.metrics.firstActivity?z(t.metrics.firstActivity):"No activity"],["Tracked activities",a(t.metrics.totalActivities)]],L=$=>$.map(([R,O])=>`
          <tr>
            <td>${i(R)}</td>
            <td>${i(String(O))}</td>
          </tr>
        `).join(""),f=I.map(([$,R])=>{const O=Number(R),q=t.metrics.ordersCreated>0?`${Math.round(O/t.metrics.ordersCreated*100)}%`:"0%";return`
        <tr>
          <td>${i($)}</td>
          <td>${i(a(O))}</td>
          <td>${i(q)}</td>
        </tr>
      `}).join(""),H=k.map($=>`
        <div class="summary-card ${$.tone}">
          <p class="summary-label">${i($.label)}</p>
          <h3 class="summary-value">${i($.value)}</h3>
          <p class="summary-hint">${i($.hint)}</p>
        </div>
      `).join(""),h=w?`<img src="${i(w)}" alt="${i(d)}" class="company-logo" />`:`<div class="company-logo company-logo-fallback">${i(d.slice(0,1).toUpperCase())}</div>`;return`<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${i(ze(`${t.user.name} Activity Performance Report`))}</title>
    <style>
      @page { size: A4; margin: 9mm; }
      * {
        box-sizing: border-box;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      body {
        margin: 0;
        background: #ffffff;
        color: #111827;
        font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
        font-size: 10.5px;
        line-height: 1.35;
      }
      .page {
        width: 100%;
        margin: 0 auto;
        background: #ffffff;
      }
      .header {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .user-card {
        display: flex;
        gap: 10px;
        align-items: center;
        padding: 10px 12px;
        border-radius: 8px;
        background-color: #f8fafc;
        border: 1px solid #dbe3ec;
      }
      .avatar-image {
        width: 52px;
        height: 52px;
        border-radius: 8px;
        flex: 0 0 52px;
      }
      .avatar-image {
        object-fit: cover;
        border: 1px solid #d8e0e8;
      }
      .user-meta h1 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        line-height: 1.2;
      }
      .meta-line {
        margin-top: 5px;
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        font-size: 10.5px;
        color: #526173;
      }
      .role-badge {
        display: inline-block;
        padding: 4px 7px;
        border-radius: 4px;
        font-size: 8px;
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
      }
      .role-admin {
        background: #efe8f8;
        color: #6a4f8d;
      }
      .role-employee {
        background: ${i(c.soft)};
        color: ${i(c.primary)};
      }
      .report-meta {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 10px;
        padding: 12px 14px;
        border-radius: 8px;
        background-color: ${i(c.primary)};
        color: #ffffff;
      }
      .report-meta-top {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
      }
      .report-meta-copy {
        min-width: 0;
      }
      .report-kicker {
        margin: 0;
        font-size: 8px;
        font-weight: 700;
        letter-spacing: 0.16em;
        text-transform: uppercase;
      }
      .report-title {
        margin: 0 0 2px;
        font-size: 18px;
        font-weight: 700;
        letter-spacing: 0.01em;
      }
      .report-subtitle {
        margin: 0;
        font-size: 10.5px;
        line-height: 1.35;
      }
      .company-lockup {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .company-logo {
        width: 40px;
        height: 40px;
        flex: 0 0 40px;
        border-radius: 8px;
        object-fit: cover;
        background-color: rgba(255, 255, 255, 0.14);
      }
      .company-logo-fallback {
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-weight: 700;
      }
      .meta-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
        font-size: 10.5px;
      }
      .meta-item {
        padding: 7px 9px;
        border-radius: 6px;
        border: 1px solid rgba(255, 255, 255, 0.16);
        background-color: rgba(255, 255, 255, 0.08);
      }
      .meta-item span {
        display: block;
        font-size: 8px;
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        margin-bottom: 4px;
      }
      .section {
        margin-top: 10px;
      }
      .section-panel {
        border: 1px solid #d9e0e7;
        border-radius: 8px;
        background-color: #ffffff;
        padding: 12px;
      }
      .section-title {
        margin: 0;
        font-size: 15px;
        font-weight: 700;
      }
      .section-subtitle {
        margin: 3px 0 0;
        font-size: 10.5px;
        color: #677487;
        line-height: 1.5;
      }
      .summary-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        margin-top: 10px;
      }
      .summary-card {
        border-radius: 8px;
        padding: 9px 10px;
        border: 1px solid;
      }
      .summary-label {
        margin: 0;
        font-size: 7.5px;
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: #5c6978;
      }
      .summary-value {
        margin: 5px 0 3px;
        font-size: 16px;
        font-weight: 700;
        line-height: 1.2;
      }
      .summary-hint {
        margin: 0;
        font-size: 9.5px;
        color: #5d6875;
        line-height: 1.45;
      }
      .card-blue {
        background-color: ${i(c.soft)};
        border-color: ${i(c.medium)};
        color: ${i(c.dark)};
      }
      .card-green {
        background-color: #f7fbf7;
        border-color: #d6e7d8;
        color: #315544;
      }
      .card-amber {
        background-color: #fffaf3;
        border-color: #eadcc2;
        color: #735833;
      }
      .card-rose {
        background-color: #fff7f8;
        border-color: #ecd8dd;
        color: #7f4955;
      }
      .detail-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
        margin-top: 10px;
      }
      .sub-panel {
        border: 1px solid #dde4ea;
        border-radius: 8px;
        padding: 12px;
        background-color: #fcfdff;
      }
      .sub-title {
        margin: 0;
        font-size: 14px;
        font-weight: 700;
      }
      .sub-copy {
        margin: 3px 0 0;
        font-size: 10.5px;
        color: #677487;
        line-height: 1.5;
      }
      table.info-table,
      table.status-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 8px;
      }
      table.info-table td,
      table.status-table td,
      table.status-table th {
        padding: 6px 0;
        border-bottom: 1px solid #e3e8ee;
        vertical-align: top;
      }
      table.info-table tr:last-child td,
      table.status-table tr:last-child td {
        border-bottom: none;
      }
      table.info-table td:first-child {
        font-size: 10.5px;
        color: #5d6b7a;
        padding-right: 12px;
      }
      table.info-table td:last-child {
        text-align: right;
        font-size: 10.5px;
        font-weight: 600;
        color: #203040;
      }
      table.status-table th {
        font-size: 8px;
        font-weight: 700;
        letter-spacing: 0.14em;
        text-transform: uppercase;
        color: #7a8695;
        text-align: left;
      }
      table.status-table th:nth-child(2),
      table.status-table th:nth-child(3),
      table.status-table td:nth-child(2),
      table.status-table td:nth-child(3) {
        text-align: right;
      }
      table.status-table td {
        font-size: 10.5px;
        color: #2a3747;
      }
      .footer {
        margin-top: 10px;
        padding-top: 7px;
        border-top: 1px solid #e5e7eb;
        font-size: 9px;
        color: #808b98;
        text-align: center;
      }
      .report-meta,
      .user-card,
      .summary-card,
      .sub-panel {
        break-inside: avoid;
        page-break-inside: avoid;
      }
      @media (max-width: 600px) {
        .report-meta-top {
          flex-direction: column;
        }
        .report-meta-copy {
          max-width: 100%;
        }
        .meta-grid,
        .detail-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
      }
      @media print {
        body { background: #ffffff; }
        .page { margin: 0; }
        .report-meta,
        .user-card,
        .summary-card,
        .sub-panel,
        .meta-item {
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
      }
    </style>
  </head>
  <body>
    <div class="page">
      <section class="header">
        <div class="report-meta">
          <div class="report-meta-top">
            <div class="company-lockup">
              ${h}
              <div class="report-meta-copy">
                <h2 class="report-title">${i(d)}</h2>
                <p class="report-subtitle">User activity and performance report</p>
              </div>
            </div>
          </div>
          <div class="meta-grid">
            <div class="meta-item"><span>Period</span>${i(P)}</div>
            <div class="meta-item"><span>Generated</span>${i(v)}</div>
          </div>
        </div>
        <div class="user-card">
          ${_}
          <div class="user-meta">
            <p class="report-kicker" style="color:#6f7d8d;">User Activity & Performance</p>
            <h1>${i(t.user.name)}</h1>
            <div class="meta-line">
              <span>${i(t.user.phone||"No phone")}</span>
              <span class="role-badge ${u}">${i(t.user.role)}</span>
            </div>
          </div>
        </div>
      </section>

      <section class="section section-panel">
        <h3 class="section-title">Performance Snapshot</h3>
        <p class="section-subtitle">Summary for the selected reporting period.</p>
        <div class="summary-grid">
          ${H}
        </div>
      </section>

      <section class="section detail-grid">
        <div class="sub-panel">
          <h4 class="sub-title">Performance Indicators</h4>
          <p class="sub-copy">Key activity and value measures for performance, salary, commission, and incentive review.</p>
          <table class="info-table">
            ${L(B)}
          </table>
          <table class="info-table">
            ${L(D)}
          </table>
        </div>

        <div class="sub-panel">
          <h4 class="sub-title">Order Status Breakdown</h4>
          <p class="sub-copy">Status distribution for all orders created by this user in the selected period.</p>
          <table class="status-table">
            <thead>
              <tr>
                <th>Status</th>
                <th>Orders</th>
                <th>Share</th>
              </tr>
            </thead>
            <tbody>
              ${f}
            </tbody>
          </table>
          <table class="info-table">
            ${L(g)}
          </table>
        </div>
      </section>

      <div class="footer">
        Generated by ${i(d)} | User Activity & Performance
      </div>
    </div>
    <script>
      const ready = () => {
        const images = Array.from(document.images || []);
        Promise.all(
          images.map((image) => image.complete ? Promise.resolve() : new Promise((resolve) => {
            image.onload = resolve;
            image.onerror = resolve;
          }))
        ).then(() => {
          window.focus();
          setTimeout(() => window.print(), 250);
        });
      };
      window.addEventListener('load', ready);
      window.addEventListener('afterprint', () => window.close());
    <\/script>
  </body>
</html>`},S=({label:r,value:t,hint:d,tone:x})=>e.jsxs("div",{className:`rounded-xl border p-4 ${x}`,children:[e.jsx("p",{className:"text-[10px] font-black uppercase tracking-[0.2em] opacity-70",children:r}),e.jsx("h4",{className:"mt-3 text-lg font-black",children:t}),e.jsx("p",{className:"mt-2 text-xs font-semibold opacity-80",children:d})]}),b=({label:r,value:t,accent:d})=>e.jsxs("div",{className:"flex items-center justify-between gap-4 border-b border-gray-100 py-3 last:border-b-0",children:[e.jsx("span",{className:"text-sm font-medium text-gray-500",children:r}),e.jsx("span",{className:`text-sm font-black ${d?"text-[#0f2f57]":"text-gray-900"}`,children:t})]}),o=({className:r})=>e.jsx("div",{className:`animate-pulse rounded-lg bg-gray-200/80 ${r}`}),Ee=()=>e.jsx("div",{className:"space-y-3 px-6 py-6",children:Array.from({length:5}).map((r,t)=>e.jsxs("div",{className:"grid grid-cols-[1.1fr_0.8fr_1fr_1.3fr] gap-3",children:[e.jsx(o,{className:"h-12"}),e.jsx(o,{className:"h-12"}),e.jsx(o,{className:"h-12"}),e.jsx(o,{className:"h-12"})]},t))}),Fe=()=>e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm",children:[e.jsx("div",{className:`${ie.colors.primary[600]} px-6 py-6`,children:e.jsxs("div",{className:"flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx(o,{className:"h-14 w-14 bg-white/20"}),e.jsxs("div",{className:"space-y-3",children:[e.jsx(o,{className:"h-3 w-28 bg-white/20"}),e.jsx(o,{className:"h-8 w-56 bg-white/20"}),e.jsx(o,{className:"h-4 w-64 bg-white/20"})]})]}),e.jsxs("div",{className:"space-y-2 rounded-lg border border-white/15 bg-white/10 px-5 py-4",children:[e.jsx(o,{className:"h-4 w-48 bg-white/20"}),e.jsx(o,{className:"h-4 w-40 bg-white/20"})]})]})}),e.jsx("div",{className:"grid grid-cols-1 gap-4 px-6 py-6 md:grid-cols-2 xl:grid-cols-5",children:Array.from({length:5}).map((r,t)=>e.jsxs("div",{className:"rounded-xl border border-gray-100 p-4",children:[e.jsx(o,{className:"h-3 w-24"}),e.jsx(o,{className:"mt-4 h-7 w-28"}),e.jsx(o,{className:"mt-3 h-4 w-36"})]},t))})]}),Array.from({length:3}).map((r,t)=>e.jsxs("section",{className:"overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm",children:[e.jsx("div",{className:"border-b border-gray-100 bg-gradient-to-r from-white via-[#f8fbff] to-white px-6 py-6",children:e.jsxs("div",{className:"flex flex-col gap-4 md:flex-row md:items-center md:justify-between",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx(o,{className:"h-16 w-16 rounded-lg"}),e.jsxs("div",{className:"space-y-3",children:[e.jsx(o,{className:"h-6 w-40"}),e.jsx(o,{className:"h-4 w-32"})]})]}),e.jsx(o,{className:"h-10 w-32"})]})}),e.jsxs("div",{className:"space-y-6 px-6 py-6",children:[e.jsx("div",{className:"grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4",children:Array.from({length:4}).map((d,x)=>e.jsxs("div",{className:"rounded-xl border border-gray-100 p-4",children:[e.jsx(o,{className:"h-3 w-24"}),e.jsx(o,{className:"mt-4 h-7 w-28"}),e.jsx(o,{className:"mt-3 h-4 w-32"})]},x))}),e.jsxs("div",{className:"grid gap-6 xl:grid-cols-[1.15fr_0.85fr]",children:[e.jsx("div",{className:"rounded-xl border border-gray-100 p-6",children:Array.from({length:6}).map((d,x)=>e.jsxs("div",{className:"flex items-center justify-between border-b border-gray-100 py-3 last:border-b-0",children:[e.jsx(o,{className:"h-4 w-32"}),e.jsx(o,{className:"h-4 w-24"})]},x))}),e.jsx("div",{className:"rounded-xl border border-gray-100 p-6",children:Array.from({length:5}).map((d,x)=>e.jsxs("div",{className:"space-y-2 py-2",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx(o,{className:"h-4 w-24"}),e.jsx(o,{className:"h-4 w-10"})]}),e.jsx(o,{className:"h-3 w-full rounded-full"})]},x))})]})]})]},t))]}),Ve=({userId:r,isExpanded:t,filterRange:d,customDates:x})=>{const{data:v=[],isPending:P,error:j}=ke(r,{filterRange:d,customDates:x},{enabled:t});return t?P?e.jsx(Ee,{}):j?e.jsx("div",{className:"px-6 py-6 text-sm font-medium text-rose-500",children:"Failed to load the activity log for this user."}):e.jsx("div",{className:"print-overflow-reset overflow-x-auto",children:e.jsxs("table",{className:"activity-table min-w-full text-left",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-50",children:[e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400",children:"Date"}),e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400",children:"Type"}),e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400",children:"Reference"}),e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400",children:"Counterparty"}),e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400",children:"Details"}),e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 text-right",children:"Qty"}),e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 text-right",children:"Amount"}),e.jsx("th",{className:"px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 text-right",children:"Status"})]})}),e.jsx("tbody",{className:"divide-y divide-gray-50",children:v.length===0?e.jsx("tr",{children:e.jsx("td",{colSpan:8,className:"px-6 py-16 text-center text-sm font-medium italic text-gray-400",children:"No activity tracked for this user in the selected period."})}):v.map(c=>e.jsxs("tr",{className:"hover:bg-gray-50/70",children:[e.jsx("td",{className:"px-6 py-4 text-sm font-semibold text-gray-600",children:z(c.rawDate)}),e.jsx("td",{className:"px-6 py-4",children:e.jsx("span",{className:"rounded-full bg-gray-100 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-gray-600",children:c.type})}),e.jsx("td",{className:"px-6 py-4 text-sm font-black text-gray-900",children:c.reference}),e.jsx("td",{className:"px-6 py-4 text-sm font-semibold text-gray-700",children:c.counterparty}),e.jsx("td",{className:"px-6 py-4 text-sm text-gray-500",children:c.details}),e.jsx("td",{className:"px-6 py-4 text-right text-sm font-black text-gray-900",children:c.quantity===null?"-":a(c.quantity)}),e.jsx("td",{className:"px-6 py-4 text-right text-sm font-black text-gray-900",children:c.amount===null?"-":m(c.amount)}),e.jsx("td",{className:"px-6 py-4 text-right",children:e.jsx("span",{className:`inline-flex rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-widest ${Oe(c.status)}`,children:c.status})})]},c.id))})]})}):e.jsx("div",{className:"px-6 py-6 text-sm font-medium text-gray-400",children:"Expand this section to review the full activity-by-activity log for this user."})},Xe=()=>{const r=Re(),{user:t}=he(),d=be(),{hasCapability:x,settings:v}=fe(),P=v==null?void 0:v.businessMode,{data:j}=ye(),{data:c=[]}=ve(),u=x("sales"),U=x("purchases"),N=x("banking"),[w,_]=y.useState("All Time"),[k,B]=y.useState({from:"",to:""}),[D,I]=y.useState(!1),[g,L]=y.useState(null),[f,H]=y.useState(null),[h,$]=y.useState(null),[R,O]=y.useState(""),[q,G]=y.useState([]),[Q,Z]=y.useState(1),J=10,W=y.useMemo(()=>ae(new Date),[]),M=(j==null?void 0:j.name)||re.settings.company.name||"Mame Pilot",K=(j==null?void 0:j.logo)||re.settings.company.logo||"",Y=y.useMemo(()=>Te(w,k),[w,k]),oe=y.useMemo(()=>[{type:"User",label:"User name, phone, or role",operators:["=","≠","contains","does not contain"],allowCustomValue:!0,customValuePlaceholder:"Search users",renderOptions:s=>{const n=s.trim().toLowerCase();return c.filter(l=>{const C=`${l.name} ${l.phone||""} ${l.role||""}`.toLowerCase();return!n||C.includes(n)}).map(l=>({value:String(l.phone||l.name).trim(),label:[l.name,l.phone,l.role].filter(Boolean).join(" · ")}))}},{type:"Role",operators:["=","≠"],values:[{value:"Admins",label:"Admins"},{value:"Employees",label:"Employees"}]},{type:"Activity",operators:["=","≠"],values:[{value:"active",label:"Has activity"},{value:"inactive",label:"No activity"}]}],[c]),ce=y.useMemo(()=>{const s=[];return g&&s.push({id:"user-search",type:"User",operator:g.operator,value:g.value,display:g.display}),f&&s.push({id:"role",type:"Role",operator:f.operator,value:f.value}),h&&s.push({id:"activity",type:"Activity",operator:h.operator,value:h.value,display:h.value==="active"?"Has activity":"No activity"}),s},[h,f,g]),ne=s=>{const n=s.find(p=>p.type==="User"),l=s.find(p=>p.type==="Role"),C=s.find(p=>p.type==="Activity");L(n?{operator:n.operator,value:n.value.trim(),display:n.display}:null),H(l&&(l.value==="Admins"||l.value==="Employees")?{operator:l.operator,value:l.value,display:l.display}:null),$(C&&(C.value==="active"||C.value==="inactive")?{operator:C.operator,value:C.value,display:C.display}:null)},de=y.useMemo(()=>({search:(g==null?void 0:g.value)||R,searchOperator:(g==null?void 0:g.operator)||"contains",roleFilter:(f==null?void 0:f.value)||"All Users",roleOperator:(f==null?void 0:f.operator)||"=",filterRange:w,customDates:k,activityFilter:(h==null?void 0:h.value)||"all",activityOperator:(h==null?void 0:h.operator)||"="}),[h,k,w,R,f,g]),me=!!t&&F(t.role),{data:A,isPending:pe,isFetching:_e}=je(Q,J,de,{enabled:me}),ee=(A==null?void 0:A.data)??[],T=(A==null?void 0:A.totals)??{users:0,activeUsers:0,orders:0,bills:0,transactions:0,orderValue:0},xe=(A==null?void 0:A.count)??0,te=Math.max(1,Math.ceil(xe/J));se.useEffect(()=>{Z(1),G([])},[g,f,h,R,w,k.from,k.to]),se.useEffect(()=>{G([])},[Q]);const ue=s=>{G(n=>n.includes(s)?n.filter(l=>l!==s):[...n,s])},ge=s=>{const n=window.open("","_blank","width=1100,height=820");if(!n){d.error("Please allow pop-ups to export the user PDF.");return}try{const l=Me({report:s,companyName:M,companyLogo:K,generatedAt:W,selectedPeriod:Y,businessMode:P,themeColors:Le()});n.document.open(),n.document.write(l),n.document.close(),n.focus()}catch(l){n.close(),d.error(l instanceof Error?l.message:"Could not prepare the report. Please try again.")}};return t?F(t.role)?pe&&!A?e.jsx(Fe,{}):e.jsxs("div",{className:"space-y-6",children:[e.jsx("div",{className:"no-print flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between",children:e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("button",{onClick:()=>r("/reports"),className:"p-2 hover:bg-white rounded-lg border border-transparent hover:border-gray-200 text-gray-500",children:e.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M10 19l-7-7m0 0l7-7m-7 7h18"})})}),e.jsxs("div",{children:[e.jsx("h2",{className:"text-2xl font-bold text-gray-900",children:"User Activity & Performance"}),e.jsx("p",{className:"mt-1 text-sm text-gray-500",children:"Compare activity, output, and financial contribution by user."})]})]})}),e.jsxs("div",{className:"report-cover overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm",children:[e.jsx("div",{className:`${ie.colors.primary[600]} px-5 py-5 text-white sm:px-6`,children:e.jsxs("div",{className:"flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[K?e.jsx("img",{src:K,alt:M,className:"h-12 w-12 rounded-lg bg-white/10 object-cover p-1"}):e.jsx("div",{className:"flex h-12 w-12 items-center justify-center rounded-lg bg-white/10 text-xl font-black",children:M.slice(0,1).toUpperCase()}),e.jsxs("div",{children:[e.jsx("p",{className:"text-[10px] font-black uppercase tracking-[0.3em] text-white/70",children:"Admin Report"}),e.jsx("h3",{className:"mt-1 text-xl font-black",children:M}),e.jsx("p",{className:"mt-1 text-sm text-white/80",children:"Orders, bills, and finance activity attributed to each user."})]})]}),e.jsxs("div",{className:"rounded-lg border border-white/15 bg-white/10 px-4 py-3 text-sm font-medium",children:[e.jsxs("p",{children:[e.jsx("span",{className:"text-white/70",children:"Period:"})," ",Y]}),e.jsxs("p",{className:"mt-1",children:[e.jsx("span",{className:"text-white/70",children:"Generated:"})," ",W]})]})]})}),e.jsx("div",{className:"no-print border-b border-gray-100 bg-gray-50/60 px-5 py-5 sm:px-6",children:e.jsxs("div",{className:"space-y-5",children:[e.jsxs("div",{children:[e.jsx("div",{className:"mb-2 flex items-center justify-between gap-3",children:e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-black text-gray-900",children:"Date and time"}),e.jsx("p",{className:"text-xs text-gray-500",children:"Choose the activity period included in every total below."})]})}),e.jsx("div",{className:"[&_.rounded-2xl]:!rounded-xl",children:e.jsx(Ce,{filterRange:w,setFilterRange:_,customDates:k,setCustomDates:B,includeTime:D,setIncludeTime:I,ranges:Ue,compact:!0,showOnMobile:!0})})]}),e.jsxs("div",{children:[e.jsxs("div",{className:"mb-2",children:[e.jsx("p",{className:"text-sm font-black text-gray-900",children:"User filters"}),e.jsx("p",{className:"text-xs text-gray-500",children:"Filter by a user detail, role group, or whether activity exists."})]}),e.jsx(Pe,{filterDefinitions:oe,initialFilters:ce,freeTextLabel:"Users",rawSearchValue:R,onRawSearchChange:O,onApply:ne,className:"[&>div>div]:!rounded-xl"})]})]})}),e.jsxs("div",{className:"border-b border-gray-100 px-5 pt-5 sm:px-6",children:[e.jsx("h3",{className:"text-base font-black text-gray-900",children:"Report overview"}),e.jsx("p",{className:"mt-1 text-sm text-gray-500",children:"A quick reading of the users and activity included by the filters."})]}),e.jsxs("div",{className:`grid grid-cols-1 gap-3 px-5 py-5 sm:px-6 md:grid-cols-2 ${u&&N?"xl:grid-cols-5":u||N?"xl:grid-cols-4":"xl:grid-cols-2"}`,children:[e.jsx(S,{label:"Users Included",value:a(T.users),hint:`${a(T.activeUsers)} active users`,tone:"bg-[#ebf4ff] border-[#c7dff5] text-[#0f2f57]"}),u&&e.jsx(S,{label:"Orders Captured",value:a(T.orders),hint:"User-created orders in this view",tone:"bg-emerald-50 border-emerald-100 text-emerald-700"}),U&&e.jsx(S,{label:"Bills Captured",value:a(T.bills),hint:"User-created bills in this view",tone:"bg-amber-50 border-amber-100 text-amber-700"}),N&&e.jsx(S,{label:"Finance Entries",value:a(T.transactions),hint:"Transactions posted by users",tone:"bg-rose-50 border-rose-100 text-rose-700"}),u&&e.jsx(S,{label:"Gross Order Value",value:m(T.orderValue),hint:"All tracked order totals",tone:"bg-[#ebf4ff] border-[#c7dff5] text-[#0f2f57]"})]})]}),ee.length===0?e.jsx("div",{className:"rounded-xl border border-dashed border-gray-200 bg-white p-16 text-center text-gray-500",children:"No users matched the current filters."}):e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"space-y-6",children:ee.map(s=>{const n=q.includes(s.user.id),l=[{label:"On Hold",value:s.metrics.onHoldOrders,color:"bg-amber-500",track:"bg-amber-100"},{label:"Processing",value:s.metrics.processingOrders,color:"bg-sky-500",track:"bg-sky-100"},{label:"Picked",value:s.metrics.pickedOrders,color:"bg-cyan-500",track:"bg-cyan-100"},{label:"Completed",value:s.metrics.completedOrders,color:"bg-emerald-500",track:"bg-emerald-100"},{label:"Returned",value:s.metrics.returnedOrders,color:"bg-orange-500",track:"bg-orange-100"},{label:"Cancelled",value:s.metrics.cancelledOrders,color:"bg-rose-500",track:"bg-rose-100"}],C=Math.max(1,...l.map(p=>p.value));return e.jsxs("section",{className:"user-report-card overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm","data-user-id":s.user.id,children:[e.jsxs("div",{className:"border-b border-gray-100 bg-[#f8fbff] px-5 py-5 sm:px-6",children:[e.jsxs("div",{className:"flex flex-col gap-4 md:flex-row md:items-center md:justify-between",children:[e.jsxs("div",{className:"flex min-w-0 items-center gap-4",children:[e.jsx("img",{src:s.user.image||V,alt:s.user.name,onError:p=>{p.currentTarget.onerror=null,p.currentTarget.src=V},className:"h-16 w-16 rounded-lg object-cover ring-1 ring-[#dce6f2]"}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-[10px] font-black uppercase tracking-[0.2em] text-[#3c5a82]",children:"User performance"}),e.jsx("h3",{className:"mt-1 truncate text-xl font-black text-gray-900",children:s.user.name}),e.jsxs("div",{className:"mt-2 flex flex-wrap items-center gap-2 text-sm font-medium text-gray-500",children:[e.jsx("span",{children:s.user.phone||"No phone"}),e.jsx("span",{className:`rounded-md px-2.5 py-1 text-[10px] font-black uppercase tracking-widest ${F(s.user.role)?"bg-purple-100 text-purple-700":"bg-blue-100 text-blue-700"}`,children:s.user.role})]})]})]}),e.jsx("div",{className:"no-print md:ml-auto",children:e.jsx(Ne,{onClick:()=>ge(s),variant:"primary",size:"md",icon:we.Download,children:"Export PDF"})})]}),e.jsxs("div",{className:"mt-4 grid gap-3 text-sm font-medium text-gray-600 sm:grid-cols-2",children:[e.jsxs("div",{className:"rounded-lg border border-[#d6e3f0] bg-white px-4 py-3",children:[e.jsx("p",{className:"text-[10px] font-black uppercase tracking-[0.2em] text-gray-400",children:"Period"}),e.jsx("p",{className:"mt-1 text-sm font-bold text-gray-900",children:Y})]}),e.jsxs("div",{className:"rounded-lg border border-[#d6e3f0] bg-white px-4 py-3",children:[e.jsx("p",{className:"text-[10px] font-black uppercase tracking-[0.2em] text-gray-400",children:"Generated"}),e.jsx("p",{className:"mt-1 text-sm font-bold text-gray-900",children:W})]})]})]}),e.jsxs("div",{className:"space-y-6 px-5 py-5 sm:px-6",children:[e.jsxs("div",{className:`grid grid-cols-1 gap-4 md:grid-cols-2 ${u&&U&&N?"xl:grid-cols-4":"xl:grid-cols-3"}`,children:[u&&e.jsx(S,{label:"Orders Created",value:a(s.metrics.ordersCreated),hint:`${a(s.metrics.completedOrders)} completed | ${a(s.metrics.cancelledOrders)} cancelled`,tone:"bg-[#ebf4ff] border-[#c7dff5] text-[#0f2f57]"}),u&&e.jsx(S,{label:"Order Value",value:m(s.metrics.orderValue),hint:`${m(s.metrics.orderPaidAmount)} collected`,tone:"bg-emerald-50 border-emerald-100 text-emerald-700"}),U&&e.jsx(S,{label:"Bills Created",value:a(s.metrics.billsCreated),hint:`${m(s.metrics.billValue)} purchase value`,tone:"bg-amber-50 border-amber-100 text-amber-700"}),N&&e.jsx(S,{label:"Transactions Posted",value:a(s.metrics.transactionsCreated),hint:`${a(s.metrics.activeDays)} active days`,tone:"bg-rose-50 border-rose-100 text-rose-700"})]}),e.jsxs("div",{className:`grid gap-6 ${u?"xl:grid-cols-[1.15fr_0.85fr]":""}`,children:[e.jsxs("div",{className:"rounded-xl border border-gray-100 bg-white p-5",children:[e.jsx("h4",{className:"text-lg font-black text-gray-900",children:"Performance indicators"}),e.jsx("p",{className:"text-sm text-gray-500",children:"Key activity and value measures for performance, salary, and incentive review."}),e.jsxs("div",{className:"mt-4 grid gap-1 md:grid-cols-2 md:gap-x-8",children:[e.jsxs("div",{children:[e.jsx(b,{label:"Active days",value:a(s.metrics.activeDays),accent:!0}),u&&e.jsx(b,{label:"Unique customers served",value:a(s.metrics.uniqueCustomers)}),u&&e.jsx(b,{label:le("Items handled in orders",P),value:a(s.metrics.orderQuantity)}),u&&e.jsx(b,{label:"Average order value",value:m(s.metrics.averageOrderValue)}),u&&e.jsx(b,{label:"Completion rate",value:`${Math.round(s.metrics.completionRate)}%`}),u&&e.jsx(b,{label:"Collection rate",value:`${Math.round(s.metrics.collectionRate)}%`})]}),e.jsxs("div",{children:[u&&e.jsx(b,{label:"Completed order value",value:m(s.metrics.completedOrderValue),accent:!0}),U&&e.jsx(b,{label:"Purchase settlement rate",value:`${Math.round(s.metrics.billSettlementRate)}%`}),N&&e.jsx(b,{label:"Income entries",value:`${a(s.metrics.incomeTransactions)} | ${m(s.metrics.incomeAmount)}`}),N&&e.jsx(b,{label:"Expense entries",value:`${a(s.metrics.expenseTransactions)} | ${m(s.metrics.expenseAmount)}`}),N&&e.jsx(b,{label:"Transfer entries",value:`${a(s.metrics.transferTransactions)} | ${m(s.metrics.transferAmount)}`}),e.jsx(b,{label:"Last activity",value:s.metrics.lastActivity?z(s.metrics.lastActivity):"No activity"})]})]})]}),u&&e.jsxs("div",{className:"rounded-xl border border-gray-100 bg-white p-5",children:[e.jsx("h4",{className:"text-lg font-black text-gray-900",children:"Order Status Breakdown"}),e.jsx("p",{className:"mt-1 text-sm text-gray-500",children:"Snapshot of all orders created by this user."}),e.jsx("div",{className:"mt-6 space-y-4",children:l.map(p=>e.jsxs("div",{children:[e.jsxs("div",{className:"mb-2 flex items-center justify-between text-sm",children:[e.jsx("span",{className:"font-semibold text-gray-600",children:p.label}),e.jsx("span",{className:"font-black text-gray-900",children:a(p.value)})]}),e.jsx("div",{className:`h-3 overflow-hidden rounded-full ${p.track}`,children:e.jsx("div",{className:`h-full rounded-full ${p.color}`,style:{width:p.value===0?"0%":`${Math.max(p.value/C*100,8)}%`}})})]},p.label))}),U&&e.jsxs("div",{className:"mt-6 border-t border-gray-100 pt-5",children:[e.jsx(b,{label:"Unique vendors handled",value:a(s.metrics.uniqueVendors)}),e.jsx(b,{label:"Bills paid amount",value:m(s.metrics.billPaidAmount)}),e.jsx(b,{label:"First tracked activity",value:s.metrics.firstActivity?z(s.metrics.firstActivity):"No activity"})]})]})]}),e.jsxs("div",{className:"exclude-from-user-pdf overflow-hidden rounded-xl border border-gray-100 bg-white",children:[e.jsxs("div",{className:"flex flex-col gap-3 border-b border-gray-100 px-6 py-5 md:flex-row md:items-center md:justify-between",children:[e.jsxs("div",{children:[e.jsx("h4",{className:"text-lg font-black text-gray-900",children:"Detailed Activity Log"}),e.jsx("p",{className:"text-sm text-gray-500",children:"Every filtered order, bill, and transaction linked to this user."})]}),e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsxs("div",{className:"rounded-lg bg-gray-50 px-3 py-2 text-sm font-bold text-gray-600",children:[a(s.metrics.totalActivities)," entries"]}),e.jsx("button",{type:"button",onClick:()=>ue(s.user.id),className:"rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-black text-gray-700 transition-colors hover:border-gray-300 hover:bg-gray-50","aria-expanded":n,children:n?"Hide Log":"Show Log"})]})]}),e.jsx(Ve,{userId:s.user.id,isExpanded:n,filterRange:w,customDates:k})]})]})]},s.user.id)})}),te>1&&e.jsx("div",{className:"flex justify-center",children:e.jsx(Se,{page:Q,totalPages:te,onPageChange:Z})}),e.jsx("style",{children:`
            @media print {
              @page { size: A4; margin: 0.35in; }
              body { background: white; }
              .no-print { display: none !important; }
              .print-overflow-reset { overflow: visible !important; }
              .report-cover, .user-report-card { box-shadow: none !important; }
              .user-report-card { page-break-after: always; break-after: page; border-color: #d1d5db !important; }
              .user-report-card:last-of-type { page-break-after: auto; break-after: auto; }
              .activity-table { font-size: 10px; }
              .activity-table thead { display: table-header-group; }
              .activity-table tr { page-break-inside: avoid; break-inside: avoid; }
            }
          `})]})]}):e.jsx("div",{className:"p-8 text-center text-gray-500",children:"This report is available to admin-access users only."}):e.jsx("div",{className:"p-8 text-center text-gray-500",children:"Loading report access..."})};export{Xe as default};
