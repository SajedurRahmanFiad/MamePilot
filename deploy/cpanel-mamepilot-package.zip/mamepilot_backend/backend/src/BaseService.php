<?php

declare(strict_types=1);

namespace App;

abstract class BaseService
{
    protected const DEFAULT_PAGE_SIZE = 25;
    protected const DEFAULT_PAYROLL_STATUSES = ['On Hold', 'Processing', 'Courier assigned', 'Picked', 'Completed', 'Exchange delivered', 'Cancelled'];
    protected const ALL_ORDER_STATUSES = [
        'On Hold', 'Processing', 'Courier assigned', 'Picked', 'Completed',
        'Exchange processing', 'Exchange picked', 'Exchange delivered', 'Exchange returned',
        'Exchange cancelled', 'Returned', 'Cancelled',
    ];
    protected const ORDER_STOCK_STATUSES = ['Processing', 'Courier assigned', 'Picked', 'Exchange processing', 'Exchange picked', 'Exchange delivered', 'Completed'];
    protected const BILL_STOCK_STATUSES = ['Received', 'Paid'];
    protected const DEFAULT_WALLET_CUTOFF_DATE = '2026-04-01';
    protected const DEFAULT_WALLET_CUTOFF_AT_UTC = '2026-03-31 18:00:00';
    protected const RESERVED_PERMISSION_ROLES = ['Admin', 'Developer'];
    protected const BUILT_IN_PERMISSION_ROLES = ['Admin', 'Employee'];
    protected const ADMIN_DEFAULT_DASHBOARD_ID = 'admin-default';
    protected const EMPLOYEE_DEFAULT_DASHBOARD_ID = 'employee-default';
    protected const DASHBOARD_KPI_SCOPES = [
        'admin.totalSales' => 'admin',
        'admin.totalPurchases' => 'admin',
        'admin.otherExpenses' => 'admin',
        'admin.totalProfit' => 'admin',
        'admin.totalOrders' => 'admin',
        'admin.onHoldOrders' => 'admin',
        'admin.processingOrders' => 'admin',
        'admin.courierAssignedOrders' => 'admin',
        'admin.pickedOrders' => 'admin',
        'admin.deliveredOrders' => 'admin',
        'admin.partiallyDeliveredOrders' => 'admin',
        'admin.exchangedOrders' => 'admin',
        'admin.exchangeProcessingOrders' => 'admin',
        'admin.exchangePickedOrders' => 'admin',
        'admin.exchangeDeliveredOrders' => 'admin',
        'admin.exchangeReturnedOrders' => 'admin',
        'admin.exchangeCancelledOrders' => 'admin',
        'admin.returnedOrders' => 'admin',
        'admin.cancelledOrders' => 'admin',
        'admin.paidOrders' => 'admin',
        'admin.partiallyPaidOrders' => 'admin',
        'admin.unpaidOrders' => 'admin',
        'admin.overpaidOrders' => 'admin',
        'admin.refundedOrders' => 'admin',
        'employee.allTimeOrders' => 'employee',
        'employee.createdToday' => 'employee',
        'employee.activeOrders' => 'employee',
        'employee.availableBalance' => 'employee',
    ];
    protected const DASHBOARD_WIDGET_SCOPES = [
        'admin.cashFlow' => 'admin',
        'admin.topSoldProducts' => 'admin',
        'admin.topSoldBatches' => 'admin',
        'admin.lowStockProducts' => 'admin',
        'admin.topCustomers' => 'admin',
        'admin.profitLoss' => 'admin',
        'admin.expensesByCategory' => 'admin',
        'admin.actionRequired' => 'admin',
        'employee.ordersByStatus' => 'employee',
        'employee.performanceOverview' => 'employee',
        'employee.orderActivity' => 'employee',
    ];
    protected const ADMIN_DEFAULT_DASHBOARD_KPIS = [
        'admin.totalSales',
        'admin.totalPurchases',
        'admin.otherExpenses',
        'admin.totalProfit',
        'admin.totalOrders',
        'admin.onHoldOrders',
        'admin.processingOrders',
        'admin.pickedOrders',
        'admin.deliveredOrders',
        'admin.cancelledOrders',
    ];
    protected const ADMIN_DEFAULT_DASHBOARD_WIDGETS = [
        'admin.cashFlow',
        'admin.topSoldProducts',
        'admin.topSoldBatches',
        'admin.topCustomers',
        'admin.profitLoss',
        'admin.expensesByCategory',
        'admin.actionRequired',
    ];
    protected const EMPLOYEE_DEFAULT_DASHBOARD_KPIS = [
        'employee.allTimeOrders',
        'employee.createdToday',
        'employee.activeOrders',
        'employee.availableBalance',
    ];
    protected const EMPLOYEE_DEFAULT_DASHBOARD_WIDGETS = [
        'employee.ordersByStatus',
        'employee.performanceOverview',
        'employee.orderActivity',
    ];
    protected const ROLE_PERMISSION_KEYS = [
        'dashboard.viewAdmin',
        'dashboard.viewEmployee',
        'orders.view',
        'orders.create',
        'orders.editOwn',
        'orders.editAny',
        'orders.deleteOwn',
        'orders.deleteAny',
        'orders.cancelOwn',
        'orders.cancelAny',
        'orders.moveOnHoldToProcessingOwn',
        'orders.moveOnHoldToProcessingAny',
        'orders.sendToCourierOwn',
        'orders.sendToCourierAny',
        'orders.moveToPickedOwn',
        'orders.moveToPickedAny',
        'orders.markCompletedOwn',
        'orders.markCompletedAny',
        'orders.markReturnedOwn',
        'orders.markReturnedAny',
        'orders.processReturnExchangeOwn',
        'orders.processReturnExchangeAny',
        'orders.print',
        'customers.view',
        'customers.create',
        'customers.edit',
        'customers.delete',
        'leads.view',
        'leads.create',
        'leads.edit',
        'leads.delete',
        'bills.view',
        'bills.create',
        'bills.editOwn',
        'bills.editAny',
        'bills.deleteOwn',
        'bills.deleteAny',
        'bills.cancelOwn',
        'bills.cancelAny',
        'bills.moveOnHoldToProcessingOwn',
        'bills.moveOnHoldToProcessingAny',
        'bills.markReceivedOwn',
        'bills.markReceivedAny',
        'bills.markPaidOwn',
        'bills.markPaidAny',
        'bills.processReturnOwn',
        'bills.processReturnAny',
        'bills.print',
        'transactions.view',
        'transactions.create',
        'transactions.edit',
        'transactions.delete',
        'vendors.view',
        'vendors.create',
        'vendors.edit',
        'vendors.delete',
        'vendors.viewBills',
        'products.view',
        'products.create',
        'products.edit',
        'products.delete',
        'accounts.view',
        'accounts.create',
        'accounts.edit',
        'accounts.delete',
        'accounts.viewBalance',
        'fraudChecker.check',
        'fraudChecker.viewHistory',
        'transfers.create',
        'transfers.view',
        'reports.view',
        'reports.viewExpense',
        'reports.viewIncome',
        'reports.viewProfitLoss',
        'reports.viewCustomerSales',
        'reports.viewProductQuantity',
        'reports.viewUserActivity',
        'reports.export',
        'wallet.view',
        'wallet.viewAny',
        'settings.editWallet',
        'payroll.view',
        'payroll.pay',
        'payroll.deletePayments',
        'recycleBin.view',
        'recycleBin.restore',
        'recycleBin.deletePermanent',
        'undoer.view',
        'undoer.execute',
        'users.view',
        'users.create',
        'users.edit',
        'users.delete',
        'marketing.view',
        'marketing.manageAds',
        'marketing.syncAds',
        'settings.view',
        'settings.editCompany',
        'settings.editOrderInvoice',
        'settings.editDefaults',
        'settings.editCourier',
        'settings.editCategories',
        'settings.editPaymentMethods',
        'settings.managePermissions',
        'subscriptions.view',
    ];
    protected const DEFAULT_ROLE_PERMISSIONS = [
        'Employee' => [
            'dashboard.viewEmployee' => true,
            'orders.view' => true,
            'orders.create' => true,
            'orders.editOwn' => true,
            'orders.print' => true,
            'customers.view' => true,
            'customers.create' => true,
            'customers.edit' => true,
            'leads.view' => true,
            'leads.create' => true,
            'leads.edit' => true,
            'products.view' => true,
            'fraudChecker.check' => true,
            'wallet.view' => true,
            'reports.view' => true,
            'reports.viewExpense' => true,
            'reports.viewIncome' => true,
            'reports.viewProfitLoss' => true,
            'reports.viewCustomerSales' => true,
            'reports.viewProductQuantity' => true,
            'reports.viewUserActivity' => true,
        ],
    ];
    protected const LEGACY_SCOPED_PERMISSION_KEYS = [
        ['legacy' => 'orders.edit', 'own' => 'orders.editOwn', 'any' => 'orders.editAny'],
        ['legacy' => 'orders.delete', 'own' => 'orders.deleteOwn', 'any' => 'orders.deleteAny'],
        ['legacy' => 'orders.cancel', 'own' => 'orders.cancelOwn', 'any' => 'orders.cancelAny'],
        [
            'legacy' => 'orders.moveOnHoldToProcessing',
            'own' => 'orders.moveOnHoldToProcessingOwn',
            'any' => 'orders.moveOnHoldToProcessingAny',
        ],
        ['legacy' => 'orders.sendToCourier', 'own' => 'orders.sendToCourierOwn', 'any' => 'orders.sendToCourierAny'],
        ['legacy' => 'orders.moveToPicked', 'own' => 'orders.moveToPickedOwn', 'any' => 'orders.moveToPickedAny'],
        ['legacy' => 'orders.markCompleted', 'own' => 'orders.markCompletedOwn', 'any' => 'orders.markCompletedAny'],
        ['legacy' => 'orders.markReturned', 'own' => 'orders.markReturnedOwn', 'any' => 'orders.markReturnedAny'],
        ['legacy' => 'bills.edit', 'own' => 'bills.editOwn', 'any' => 'bills.editAny'],
        ['legacy' => 'bills.delete', 'own' => 'bills.deleteOwn', 'any' => 'bills.deleteAny'],
        ['legacy' => 'bills.cancel', 'own' => 'bills.cancelOwn', 'any' => 'bills.cancelAny'],
        [
            'legacy' => 'bills.moveOnHoldToProcessing',
            'own' => 'bills.moveOnHoldToProcessingOwn',
            'any' => 'bills.moveOnHoldToProcessingAny',
        ],
        ['legacy' => 'bills.markReceived', 'own' => 'bills.markReceivedOwn', 'any' => 'bills.markReceivedAny'],
        ['legacy' => 'bills.markPaid', 'own' => 'bills.markPaidOwn', 'any' => 'bills.markPaidAny'],
        [
            'legacy' => 'orders.processReturnExchange',
            'own' => 'orders.processReturnExchangeOwn',
            'any' => 'orders.processReturnExchangeAny',
        ],
        [
            'legacy' => 'bills.processReturn',
            'own' => 'bills.processReturnOwn',
            'any' => 'bills.processReturnAny',
        ],
    ];

    protected Database $database;
    protected Auth $auth;
    protected Config $config;
    private ?ServiceLifecycle $serviceLifecycleInstance = null;
    /** @var array<string, bool> */
    private array $tableExistsCache = [];
    /** @var array<string, bool> */
    private array $columnExistsCache = [];
    /** @var array<string, mixed>|null */
    protected ?array $permissionsSettingsPayloadCache = null;

    public function __construct(Database $database, Auth $auth, Config $config)
    {
        $this->database = $database;
        $this->auth = $auth;
        $this->config = $config;
    }

    protected function currentUser(): array
    {
        return $this->auth->requireUser();
    }

    protected function serviceLifecycle(): ServiceLifecycle
    {
        if (!$this->serviceLifecycleInstance instanceof ServiceLifecycle) {
            $this->serviceLifecycleInstance = new ServiceLifecycle($this->database, $this->config);
        }

        return $this->serviceLifecycleInstance;
    }

    protected function requireAdmin(): array
    {
        return $this->auth->requireAdmin();
    }

    /**
     * @param array<int, string> $values
     * @return array{0: array<int, string>, 1: array<string, string>}
     */
    protected function inClause(array $values, string $prefix): array
    {
        $placeholders = [];
        $bindings = [];
        foreach (array_values($values) as $index => $value) {
            $name = ':' . $prefix . '_' . $index;
            $placeholders[] = $name;
            $bindings[$name] = $value;
        }

        return [$placeholders, $bindings];
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     * @return array<string, array<string, mixed>>
     */
    protected function keyBy(array $rows, string $column): array
    {
        $map = [];
        foreach ($rows as $row) {
            $key = (string) ($row[$column] ?? '');
            if ($key !== '') {
                $map[$key] = $row;
            }
        }

        return $map;
    }

    protected function stringId($value): string
    {
        $string = trim((string) ($value ?? ''));
        if ($string !== '') {
            return $string;
        }

        return $this->uuid4();
    }

    protected function uuid4(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($bytes), 4));
    }

    protected function normalizeDateOnly(string $value): string
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return '';
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $trimmed) === 1) {
            return $trimmed;
        }

        $timestamp = strtotime($trimmed);
        return $timestamp === false ? '' : gmdate('Y-m-d', $timestamp);
    }

    protected function normalizeUploadedFileValue(?string $value, string $category, ?string $originalFileName = null): ?string
    {
        $trimmed = trim((string) ($value ?? ''));
        if ($trimmed === '') {
            return null;
        }

        if (!$this->isDataUrl($trimmed)) {
            return $trimmed;
        }

        return $this->saveUploadedFileFromDataUrl($trimmed, $category, $originalFileName);
    }

    protected function normalizeUploadedWebpValue(?string $value, string $category, ?string $originalFileName = null): ?string
    {
        $trimmed = trim((string) ($value ?? ''));
        if ($trimmed === '') {
            return null;
        }

        if (!$this->isDataUrl($trimmed)) {
            return $trimmed;
        }

        $decoded = $this->decodeDataUrl($trimmed);
        if ($decoded === null || !$this->isImageMimeType((string) ($decoded[0] ?? ''))) {
            throw new \RuntimeException('The uploaded profile picture is not a valid image.');
        }

        [, $data] = $decoded;
        $uploadDir = $this->uploadPublicPath($category);
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            throw new \RuntimeException(sprintf('Failed to create upload directory: %s', $uploadDir));
        }

        $webpFileName = $this->uniqueUploadFilename('webp', $originalFileName);
        $webpTargetPath = $uploadDir . DIRECTORY_SEPARATOR . $webpFileName;
        if (!$this->saveImageAsWebp($data, $webpTargetPath)) {
            throw new \RuntimeException('Profile pictures require WebP support on the server.');
        }

        return '/uploads/' . trim($category, '/') . '/' . $webpFileName;
    }

    protected function normalizeUserProfileImageValue(?string $value, ?string $userId = null, ?string $originalFileName = null): string
    {
        $trimmed = trim((string) ($value ?? ''));
        if ($trimmed === '') {
            return '';
        }

        if (!$this->isDataUrl($trimmed)) {
            return $this->ensurePublicUploadedFileValue($trimmed);
        }

        try {
            $normalized = $this->normalizeUploadedWebpValue($trimmed, 'profile-pictures', $originalFileName) ?? '';
            if ($normalized !== '' && $userId !== null && trim($userId) !== '') {
                $this->database->execute(
                    'UPDATE users SET image = :normalized_image WHERE id = :user_id AND image = :legacy_image',
                    [
                        ':normalized_image' => $normalized,
                        ':user_id' => trim($userId),
                        ':legacy_image' => $trimmed,
                    ]
                );
            }
            return $normalized;
        } catch (\Throwable) {
            // Never return a persisted base64 payload to the frontend. Existing
            // legacy data remains untouched so it can be migrated once WebP
            // support and the public upload directory are available.
            return '';
        }
    }

    protected function isDataUrl(string $value): bool
    {
        return preg_match('/^\s*data:[^;]+;base64,/', $value) === 1;
    }

    protected function decodeDataUrl(string $value): ?array
    {
        if (!preg_match('/^\s*data:([^;]+);base64,(.+)$/i', trim($value), $matches)) {
            return null;
        }

        $mimeType = strtolower(trim($matches[1]));
        $payload = preg_replace('/\s+/', '', $matches[2]);
        $decoded = base64_decode($payload, true);
        if ($decoded === false) {
            return null;
        }

        return [$mimeType, $decoded];
    }

    protected function saveUploadedFileFromDataUrl(string $dataUrl, string $category, ?string $originalFileName = null): string
    {
        $decoded = $this->decodeDataUrl($dataUrl);
        if ($decoded === null) {
            return trim($dataUrl);
        }

        [$mimeType, $data] = $decoded;
        $uploadDir = $this->uploadPublicPath($category);
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            throw new \RuntimeException(sprintf('Failed to create upload directory: %s', $uploadDir));
        }

        $fileName = $this->uniqueUploadFilename($this->extensionFromMimeType($mimeType, $originalFileName), $originalFileName);
        $targetPath = $uploadDir . DIRECTORY_SEPARATOR . $fileName;

        if ($this->isImageMimeType($mimeType)) {
            $webpFileName = $this->uniqueUploadFilename('webp', $originalFileName);
            $webpTargetPath = $uploadDir . DIRECTORY_SEPARATOR . $webpFileName;
            if ($this->saveImageAsWebp($data, $webpTargetPath)) {
                return '/uploads/' . trim($category, '/') . '/' . $webpFileName;
            }
        }

        if (file_put_contents($targetPath, $data) === false) {
            throw new \RuntimeException(sprintf('Failed to save uploaded file to %s', $targetPath));
        }

        return '/uploads/' . trim($category, '/') . '/' . $fileName;
    }

    protected function uploadPublicPath(string $category): string
    {
        // Save uploads to the web-accessible uploads directory.
        // Resolution order:
        //   1. {project_root}/public/uploads/{category}/  — local dev (Vite serves public/ at root)
        //   2. {web_root}/public_html/uploads/{category}/ — cPanel deploy (Apache serves public_html/)
        //   3. {backend}/public/uploads/{category}/        — last resort fallback
        $projectRoot = dirname(dirname(__DIR__)); // backend/src → backend → project root
        $categoryPath = 'uploads' . DIRECTORY_SEPARATOR . trim($category, '/');

        // During an HTTP request, the active site's document root is authoritative for
        // absolute /uploads URLs. This also avoids writing a subdomain's files into a
        // parent public_html directory when updater paths are stale or too broad.
        $requestPublicRoot = $this->requestPublicRoot();
        if ($requestPublicRoot !== null) {
            return $requestPublicRoot . DIRECTORY_SEPARATOR . $categoryPath;
        }

        // Package releases publish to UPDATE_PUBLIC_ROOT; git releases publish to
        // UPDATE_DOCUMENT_ROOT. Prefer the path that matches the configured mode.
        $useGitUpdates = filter_var($this->config->get('UPDATE_USE_GIT', '0'), FILTER_VALIDATE_BOOLEAN);
        $configKeys = $useGitUpdates
            ? ['UPDATE_DOCUMENT_ROOT', 'UPDATE_PUBLIC_ROOT']
            : ['UPDATE_PUBLIC_ROOT', 'UPDATE_DOCUMENT_ROOT'];
        foreach ($configKeys as $configKey) {
            $configuredRoot = trim((string) $this->config->get($configKey, ''));
            if ($configuredRoot !== '' && is_dir($configuredRoot)) {
                return rtrim($configuredRoot, '/\\') . DIRECTORY_SEPARATOR . $categoryPath;
            }
        }

        // 1. Local dev: project_root/public/uploads/
        $publicDir = $projectRoot . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . $categoryPath;
        if (is_dir(dirname($publicDir)) || is_dir($projectRoot . DIRECTORY_SEPARATOR . 'public')) {
            return $publicDir;
        }

        $serverDocumentRoot = trim((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''));
        if ($serverDocumentRoot !== '' && is_dir($serverDocumentRoot)) {
            return rtrim($serverDocumentRoot, '/\\') . DIRECTORY_SEPARATOR . $categoryPath;
        }

        // 2. cPanel deploy: walk up from project root to find public_html/
        //    Typical layout: /home/user/public_html/mamepilot_backend/backend/...
        //    The web root is /home/user/public_html/
        $checkDir = $projectRoot;
        for ($i = 0; $i < 5; $i++) {
            if (strtolower(basename($checkDir)) === 'public_html' && is_dir($checkDir)) {
                return $checkDir . DIRECTORY_SEPARATOR . $categoryPath;
            }

            $candidate = $checkDir . DIRECTORY_SEPARATOR . 'public_html';
            if (is_dir($candidate) && (is_file($candidate . DIRECTORY_SEPARATOR . '.htaccess') || is_file($candidate . DIRECTORY_SEPARATOR . 'index.html'))) {
                return $candidate . DIRECTORY_SEPARATOR . $categoryPath;
            }
            $parent = dirname($checkDir);
            if ($parent === $checkDir) {
                break;
            }
            $checkDir = $parent;
        }

        // 3. Fallback: backend/public/uploads/
        return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . $categoryPath;
    }

    protected function ensurePublicUploadedFileValue(string $value): string
    {
        $trimmed = trim($value);
        if (preg_match('#^/uploads/([a-zA-Z0-9_-]+)/([a-zA-Z0-9_.-]+)$#', $trimmed, $matches) !== 1) {
            return $trimmed;
        }

        $targetDirectory = $this->uploadPublicPath($matches[1]);
        $targetPath = $targetDirectory . DIRECTORY_SEPARATOR . $matches[2];
        if (is_file($targetPath)) {
            return $trimmed;
        }

        // Recover files saved by older deployments under backend/public/uploads.
        $legacyDirectories = [
            dirname(__DIR__) . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $matches[1],
            dirname(dirname(__DIR__)) . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . $matches[1],
        ];
        foreach (array_unique($legacyDirectories) as $legacyDirectory) {
            $legacyPath = $legacyDirectory . DIRECTORY_SEPARATOR . $matches[2];
            if (!is_file($legacyPath) || $legacyPath === $targetPath) {
                continue;
            }

            if (!is_dir($targetDirectory) && !mkdir($targetDirectory, 0755, true) && !is_dir($targetDirectory)) {
                return $trimmed;
            }

            if (@copy($legacyPath, $targetPath)) {
                break;
            }
        }

        return $trimmed;
    }

    private function requestPublicRoot(): ?string
    {
        // The PHP development server handles API calls from backend/public while Vite
        // serves the frontend's public directory, so its document root is intentionally
        // ignored here and the local-project branch below remains in control.
        if (PHP_SAPI === 'cli' || PHP_SAPI === 'cli-server') {
            return null;
        }

        $scriptFilename = trim((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''));
        if ($scriptFilename !== '' && strtolower(basename(dirname($scriptFilename))) === 'api') {
            $gatewayRoot = dirname(dirname($scriptFilename));
            if (is_dir($gatewayRoot)) {
                return rtrim($gatewayRoot, '/\\');
            }
        }

        $serverDocumentRoot = trim((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''));
        if ($serverDocumentRoot !== '' && is_dir($serverDocumentRoot)) {
            return rtrim($serverDocumentRoot, '/\\');
        }

        return null;
    }

    protected function uniqueUploadFilename(string $extension, ?string $originalFileName = null): string
    {
        $baseName = $this->sanitizeFileName(pathinfo((string) ($originalFileName ?? ''), PATHINFO_FILENAME));
        if ($baseName === '') {
            $baseName = $this->uuid4();
        }

        return sprintf('%s-%s.%s', $baseName, bin2hex(random_bytes(4)), $extension);
    }

    protected function extensionFromMimeType(string $mimeType, ?string $originalFileName = null): string
    {
        $extensionMap = [
            'image/jpeg' => 'jpg',
            'image/pjpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'image/svg+xml' => 'svg',
            'application/pdf' => 'pdf',
            'text/plain' => 'txt',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/vnd.ms-excel' => 'xls',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
            'application/zip' => 'zip',
            'application/octet-stream' => 'bin',
        ];

        if (isset($extensionMap[$mimeType])) {
            return $extensionMap[$mimeType];
        }

        $originalExtension = strtolower(pathinfo((string) ($originalFileName ?? ''), PATHINFO_EXTENSION));
        if ($originalExtension !== '' && preg_match('/^[a-z0-9]+$/', $originalExtension) === 1) {
            return $originalExtension;
        }

        $parts = explode('/', $mimeType, 2);
        if (count($parts) === 2 && preg_match('/^[a-z0-9]+$/', $parts[1]) === 1) {
            return $parts[1];
        }

        return 'bin';
    }

    protected function sanitizeFileName(string $fileName): string
    {
        $fileName = preg_replace('/[^a-zA-Z0-9-_\.]/', '_', $fileName) ?: '';
        return trim($fileName, '._-');
    }

    protected function saveImageAsWebp(string $data, string $targetPath): bool
    {
        if (function_exists('imagecreatefromstring') && function_exists('imagewebp')) {
            $image = @imagecreatefromstring($data);
            if ($image !== false) {
                $result = imagewebp($image, $targetPath, 85);
                imagedestroy($image);
                return $result !== false;
            }
        }

        if (class_exists('\Imagick')) {
            try {
                $imagick = new \Imagick();
                $imagick->readImageBlob($data);
                $imagick->setImageFormat('webp');
                $imagick->setOption('webp:lossless', 'false');
                $imagick->setImageCompressionQuality(85);
                $result = $imagick->writeImage($targetPath);
                $imagick->clear();
                $imagick->destroy();
                return $result;
            } catch (\ImagickException $exception) {
                // Fallback to raw save below if conversion fails.
            }
        }

        return false;
    }

    protected function isImageMimeType(string $mimeType): bool
    {
        return str_starts_with($mimeType, 'image/');
    }

    protected function utcTimezone(): \DateTimeZone
    {
        static $timezone = null;
        if (!$timezone instanceof \DateTimeZone) {
            $timezone = new \DateTimeZone('UTC');
        }

        return $timezone;
    }

    protected function parseDateTimeValue(string $value, ?\DateTimeZone $naiveTimezone = null): ?\DateTimeImmutable
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return null;
        }

        $timezone = $naiveTimezone ?? $this->utcTimezone();

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $trimmed) === 1) {
            $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $trimmed, $timezone);
            return $date instanceof \DateTimeImmutable ? $date : null;
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?$/', $trimmed) === 1) {
            $normalized = str_replace('T', ' ', $trimmed);
            $format = str_contains($normalized, '.') ? 'Y-m-d H:i:s.u' : 'Y-m-d H:i:s';
            $date = \DateTimeImmutable::createFromFormat($format, $normalized, $timezone);
            return $date instanceof \DateTimeImmutable ? $date : null;
        }

        try {
            return new \DateTimeImmutable($trimmed);
        } catch (\Exception) {
            return null;
        }
    }

    /**
     * Parse a history timestamp value which can be either ISO 8601 or human-readable format.
     * Human-readable format: "Marked delivered on 26 Jul 2025, at 04:30 PM" or "on 26 Jul 2025, at 04:30 PM"
     */
    protected function parseHistoryTimestampValue(string $value): ?\DateTimeImmutable
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return null;
        }

        // Try ISO 8601 format first (from gmdate('c'))
        $parsed = $this->parseDateTimeValue($trimmed, $this->utcTimezone());
        if ($parsed !== null) {
            return $parsed;
        }

        // Try human-readable format: "Marked delivered on 26 Jul 2025, at 04:30 PM"
        // or "on 26 Jul 2025, at 04:30 PM"
        // Also handle UTC timestamps in webhook text:
        // "Marked delivered automatically from Steadfast webhook event \"delivered\" on 2026-08-14 14:46:15."
        $patterns = [
            // UTC timestamp in history text: "...on 2026-08-14 14:46:15." (Steadfast/courier webhooks)
            '/(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})/',
            // "Marked delivered on 26 Jul 2025, at 04:30 PM" (local time, with "on" prefix)
            '/^.*?on\s+(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})[\,\s]+at\s+(\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm|AM|PM))[\.\s]*$/',
            // "on 26 Jul 2025, at 04:30 PM"
            '/^on\s+(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})[\,\s]+at\s+(\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm|AM|PM))[\.\s]*$/',
            // "26 Jul 2025, 04:30 PM" (without "on" and "at")
            '/^(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})[\,\s]+(\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm|AM|PM))[\.\s]*$/',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $trimmed, $matches)) {
                $dateStr = $matches[1];
                $timeStr = $matches[2];

                // UTC format: YYYY-MM-DD HH:MM:SS (from courier webhooks)
                if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateStr)) {
                    $dateTimeStr = $dateStr . ' ' . $timeStr;
                    $utcDateTime = \DateTimeImmutable::createFromFormat(
                        'Y-m-d H:i:s',
                        $dateTimeStr,
                        $this->utcTimezone()
                    );
                    if ($utcDateTime !== false) {
                        return $utcDateTime;
                    }
                    continue;
                }

                // Local format: "d M Y" with optional AM/PM time
                $localTimezone = new \DateTimeZone($this->config->timezone());
                $date = \DateTimeImmutable::createFromFormat('d M Y', $dateStr, $localTimezone);
                if ($date === false) {
                    continue;
                }

                // Parse time with am/pm
                $timeStrLower = strtolower(trim($timeStr));
                $hasAmPm = false;
                if (preg_match('/(\d{1,2}:\d{2}(?::\d{2})?)\s*(am|pm)/', $timeStrLower, $timeMatches)) {
                    $timePart = $timeMatches[1];
                    $meridiem = $timeMatches[2];
                    $hasAmPm = true;
                } else {
                    $timePart = $timeStrLower;
                }

                $timeParts = explode(':', $timePart);
                $hour = (int)($timeParts[0] ?? 0);
                $minute = (int)($timeParts[1] ?? 0);
                $second = (int)($timeParts[2] ?? 0);

                if ($hasAmPm) {
                    if ($meridiem === 'pm' && $hour !== 12) {
                        $hour += 12;
                    } elseif ($meridiem === 'am' && $hour === 12) {
                        $hour = 0;
                    }
                }

                // Combine date and time in LOCAL timezone, then convert to UTC
                $dateTimeStr = $date->format('Y-m-d') . ' ' . sprintf('%02d:%02d:%02d', $hour, $minute, $second);
                $localDateTime = \DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $dateTimeStr, $localTimezone);

                if ($localDateTime !== false) {
                    // Convert to UTC
                    return $localDateTime->setTimezone($this->utcTimezone());
                }
            }
        }

        return null;
    }

    protected function normalizeDateTimeInput(string $value): string
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return $this->database->nowUtc();
        }

        $dateTime = $this->parseDateTimeValue($trimmed, $this->utcTimezone());
        return $dateTime instanceof \DateTimeImmutable
            ? $dateTime->setTimezone($this->utcTimezone())->format('Y-m-d H:i:s')
            : $this->database->nowUtc();
    }

    protected function normalizeDateTimeInputWithCurrentLocalTime(string $value): string
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return $this->database->nowUtc();
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $trimmed) === 1) {
            $localTimezone = new \DateTimeZone($this->config->timezone());
            $utcTimezone = new \DateTimeZone('UTC');
            $localNow = new \DateTimeImmutable('now', $localTimezone);
            $localDateTime = \DateTimeImmutable::createFromFormat(
                'Y-m-d H:i:s',
                $trimmed . ' ' . $localNow->format('H:i:s'),
                $localTimezone
            );

            if ($localDateTime instanceof \DateTimeImmutable) {
                return $localDateTime->setTimezone($utcTimezone)->format('Y-m-d H:i:s');
            }
        }

        return $this->normalizeDateTimeInput($trimmed);
    }

    protected function toIso(?string $value): ?string
    {
        $trimmed = trim((string) ($value ?? ''));
        if ($trimmed === '') {
            return null;
        }

        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $trimmed) === 1) {
            return $trimmed;
        }

        $dateTime = $this->parseDateTimeValue($trimmed, $this->utcTimezone());
        return $dateTime instanceof \DateTimeImmutable
            ? $dateTime->setTimezone($this->utcTimezone())->format('Y-m-d\TH:i:s\Z')
            : $trimmed;
    }

    /**
     * @param mixed $value
     */
    protected function money($value): float
    {
        return round((float) $value, 2);
    }

    protected function formatMoney($value): string
    {
        return number_format((float) $value, 2, '.', '');
    }

    /**
     * @param mixed $value
     */
    protected function nullableTrimmedString($value): ?string
    {
        $string = trim((string) ($value ?? ''));
        return $string === '' ? null : $string;
    }

    /**
     * Normalize a Unicode string to NFC form for consistent matching.
     * This ensures that composed characters (like Bengali with matras) match
     * regardless of how they were input (composed vs decomposed).
     *
     * @param string $value The string to normalize
     * @return string The normalized string (NFC form), or the original if normalization fails
     */
    protected function normalizeUnicodeString(string $value): string
    {
        if ($value === '') {
            return $value;
        }

        // Check if the intl extension is available with Normalizer
        if (class_exists('\Normalizer', false) && defined('\Normalizer::FORM_C')) {
            try {
                return \Normalizer::normalize($value, \Normalizer::FORM_C);
            } catch (\Throwable $e) {
                // Fall through to return original value
            }
        }

        // Fallback: return the original string
        // MySQL's utf8mb4_unicode_ci collation should handle most cases
        return $value;
    }

    /**
     * Convert a string of Bengali digits (০-৯) to an integer.
     * Non-Bengali-digit characters are ignored.
     */
    protected function bengaliToNumber(string $bengali): int
    {
        $map = [
            '০' => '0', '১' => '1', '২' => '2', '৩' => '3', '৪' => '4',
            '৫' => '5', '৬' => '6', '৭' => '7', '৮' => '8', '৯' => '9',
        ];
        return (int) strtr($bengali, $map);
    }

    /**
     * Sort comparator for product names that may contain trailing Bengali
     * numerals.  When two names share the same alphabetic prefix and differ
     * only in a trailing Bengali number group, they are sorted numerically;
     * otherwise the standard alphabetical (strcmp) order is used.
     */
    protected function compareProductNames(string $a, string $b): int
    {
        // Match an optional common prefix followed by a Bengali digit group
        // and an optional suffix.  The prefix captures everything before the
        // first Bengali digit that appears as a number token (preceded by
        // a space, tilde, or start-of-string and followed by a space or end).
        $pattern = '/^(.*?)([০-৯]+)(.*)$/u';

        $matchA = preg_match($pattern, $a, $partsA);
        $matchB = preg_match($pattern, $b, $partsB);

        if ($matchA && $matchB && $partsA[1] === $partsB[1]) {
            // Same alphabetic prefix — sort by numeric value of Bengali digits
            $numA = $this->bengaliToNumber($partsA[2]);
            $numB = $this->bengaliToNumber($partsB[2]);
            $cmp = $numA <=> $numB;
            if ($cmp !== 0) {
                return $cmp;
            }
            // Same numeric value — fall through to suffix comparison
            return strcmp($partsA[3], $partsB[3]);
        }

        // Default: alphabetical sort
        return strcmp($a, $b);
    }

    /**
     * @param mixed $value
     */
    protected function nullableString($value): ?string
    {
        if ($value === null) {
            return null;
        }

        $string = (string) $value;
        return $string === '' ? null : $string;
    }

    /**
     * @param mixed $value
     */
    protected function jsonEncode($value): ?string
    {
        if ($value === null) {
            return null;
        }

        return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /**
     * @param mixed $value
     * @return array<int, mixed>
     */
    protected function jsonDecodeList($value): array
    {
        if (is_array($value)) {
            return array_values($value);
        }

        if ($value === null || trim((string) $value) === '') {
            return [];
        }

        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? array_values($decoded) : [];
    }

    /**
     * @param mixed $value
     * @return array<string, mixed>
     */
    protected function jsonDecodeAssoc($value): array
    {
        if (is_array($value)) {
            return $value;
        }

        if ($value === null || trim((string) $value) === '') {
            return [];
        }

        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * @param array<string, mixed> $updates
     */
    protected function touchUpdate(string $table, string $id, array $updates): void
    {
        if ($updates === []) {
            return;
        }

        $updates = $this->filterExistingColumns($table, $updates);
        $updates['updated_at'] = $this->database->nowUtc();
        [$setClause, $bindings] = $this->database->buildSetClause($updates);
        $bindings[':id'] = $id;
        $this->database->execute("UPDATE {$table} SET {$setClause} WHERE id = :id", $bindings);
    }

    protected function softDelete(string $table, string $id): void
    {
        $actor = $this->currentUser();
        $deletedAt = $this->database->nowUtc();
        $this->database->execute(
            "UPDATE {$table} SET deleted_at = :deleted_at, deleted_by = :deleted_by, updated_at = :updated_at WHERE id = :id AND deleted_at IS NULL",
            [
                ':deleted_at' => $deletedAt,
                ':deleted_by' => (string) $actor['id'],
                ':updated_at' => $deletedAt,
                ':id' => $id,
            ]
        );
    }

    protected function restoreSoftDeletedRow(string $table, string $id): void
    {
        $this->database->execute(
            "UPDATE {$table} SET deleted_at = NULL, deleted_by = NULL, updated_at = :updated_at WHERE id = :id AND deleted_at IS NOT NULL",
            [
                ':updated_at' => $this->database->nowUtc(),
                ':id' => $id,
            ]
        );
    }

    protected function permanentlyDeleteSoftDeletedRow(string $table, string $id): void
    {
        $this->database->execute(
            "DELETE FROM {$table} WHERE id = :id AND deleted_at IS NOT NULL",
            [':id' => $id]
        );
    }

    protected function saveSingleton(string $table, string $id, array $updates, callable $resolver): array
    {
        $row = $this->database->fetchOne("SELECT id FROM {$table} LIMIT 1");
        $existingId = (string) ($row['id'] ?? $id);
        $filtered = [];

        foreach ($updates as $column => $value) {
            if ($value !== null) {
                $filtered[$column] = is_string($value) ? trim($value) : $value;
            }
        }

        if ($row !== null) {
            $this->touchUpdate($table, $existingId, $filtered);
            return $resolver();
        }

        $filtered['id'] = $existingId;
        $filtered['created_at'] = $this->database->nowUtc();
        $filtered['updated_at'] = $this->database->nowUtc();
        $columns = implode(', ', array_keys($filtered));
        $placeholders = implode(', ', array_map(static fn(string $column): string => ':' . $column, array_keys($filtered)));
        $bindings = [];
        foreach ($filtered as $column => $value) {
            $bindings[':' . $column] = $value;
        }
        $this->database->execute("INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})", $bindings);
        return $resolver();
    }

    /**
     * @param array<string, mixed> $fallback
     * @return array<string, mixed>
     */
    protected function normalizeCompanyPage($value, int $index = 0, array $fallback = []): array
    {
        $page = is_array($value) ? $value : [];
        $fallbackName = trim((string) ($fallback['name'] ?? '')) ?: ($index === 0 ? 'Mame Pilot' : 'Page ' . ($index + 1));
        $id = trim((string) ($page['id'] ?? $fallback['id'] ?? ''));

        if ($id === '') {
            $id = $index === 0 ? 'company-default-page' : 'company-page-' . ($index + 1);
        }

        return [
            'id' => $id,
            'name' => trim((string) ($page['name'] ?? $fallback['name'] ?? '')) ?: $fallbackName,
            'tagline' => (string) ($page['tagline'] ?? $fallback['tagline'] ?? ''),
            'logo' => $this->normalizeUploadedFileValue($page['logo'] ?? $fallback['logo'] ?? null, 'logos', null) ?? '',
            'phone' => $page['phone'] ?? ($fallback['phone'] ?? '+880'),
            'email' => $page['email'] ?? ($fallback['email'] ?? 'info@company.com'),
            'address' => (string) ($page['address'] ?? $fallback['address'] ?? ''),
            'isGlobalBranding' => (bool) ($page['isGlobalBranding'] ?? $page['is_global_branding'] ?? $fallback['isGlobalBranding'] ?? $fallback['is_global_branding'] ?? false),
        ];
    }

    /**
     * @param array<string, mixed> $legacyRow
     * @return array<int, array<string, mixed>>
     */
    protected function normalizeCompanyPages($value, array $legacyRow = []): array
    {
        $fallbackPage = $this->normalizeCompanyPage(
            [
                'id' => $legacyRow['id'] ?? 'company-default-page',
                'name' => $legacyRow['name'] ?? 'Mame Pilot',
                'tagline' => $legacyRow['tagline'] ?? '',
                'logo' => $legacyRow['logo'] ?? '/uploads/Avatar.png',
                'phone' => $legacyRow['phone'] ?? '+880',
                'email' => $legacyRow['email'] ?? 'info@company.com',
                'address' => $legacyRow['address'] ?? '',
                'isGlobalBranding' => true,
            ],
            0
        );

        $rawPages = $this->jsonDecodeList($value);
        $pages = [];

        foreach ($rawPages as $index => $page) {
            if (!is_array($page)) {
                continue;
            }

            $pages[] = $this->normalizeCompanyPage($page, $index, $index === 0 ? $fallbackPage : []);
        }

        if ($pages === []) {
            $pages[] = $fallbackPage;
        }

        $foundGlobal = false;
        foreach ($pages as $index => $page) {
            $isGlobal = (bool) ($page['isGlobalBranding'] ?? false) && !$foundGlobal;
            if ($isGlobal) {
                $foundGlobal = true;
            }
            $pages[$index]['isGlobalBranding'] = $isGlobal;
        }

        if (!$foundGlobal && isset($pages[0])) {
            $pages[0]['isGlobalBranding'] = true;
        }

        return array_values($pages);
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @return array<string, mixed>
     */
    protected function getGlobalCompanyPage(array $pages): array
    {
        foreach ($pages as $index => $page) {
            if (!is_array($page)) {
                continue;
            }

            if ((bool) ($page['isGlobalBranding'] ?? false)) {
                return $this->normalizeCompanyPage($page, $index);
            }
        }

        return isset($pages[0]) && is_array($pages[0])
            ? $this->normalizeCompanyPage($pages[0], 0)
            : $this->normalizeCompanyPage([], 0);
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapCustomer(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'phone' => (string) ($row['phone'] ?? ''),
            'address' => (string) ($row['address'] ?? ''),
            'age' => isset($row['age']) ? (int) $row['age'] : null,
            'gender' => $this->nullableString($row['gender'] ?? null),
            'dateOfBirth' => $this->toIso($row['date_of_birth'] ?? null),
            'weight' => isset($row['weight']) ? (float) $row['weight'] : null,
            'height' => isset($row['height']) ? (float) $row['height'] : null,
            'bloodGroup' => $this->nullableString($row['blood_group'] ?? null),
            'guardianName' => $this->nullableString($row['guardian_name'] ?? null),
            'emergencyContact' => $this->nullableString($row['emergency_contact'] ?? null),
            'additionalNotes' => $this->nullableString($row['additional_notes'] ?? null),
            'totalOrders' => (int) ($row['total_orders'] ?? 0),
            'dueAmount' => (float) ($row['due_amount'] ?? 0),
            'createdBy' => $this->nullableString($row['created_by'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? null),
            'fraudCheckResult' => $this->jsonDecodeAssoc($row['fraud_check_result'] ?? null) ?: null,
            'fraudCheckPercentage' => isset($row['fraud_check_percentage']) ? (float) $row['fraud_check_percentage'] : null,
            'fraudCheckPhone' => $this->nullableString($row['fraud_check_phone'] ?? null),
            'fraudCheckedAt' => $this->toIso($row['fraud_checked_at'] ?? null),
            'deletedAt' => $this->toIso($row['deleted_at'] ?? null),
            'deletedBy' => $this->nullableString($row['deleted_by'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapVendor(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'phone' => (string) ($row['phone'] ?? ''),
            'address' => (string) ($row['address'] ?? ''),
            'totalPurchases' => (int) ($row['total_purchases'] ?? 0),
            'dueAmount' => (float) ($row['due_amount'] ?? 0),
            'createdBy' => $this->nullableString($row['created_by'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? null),
            'deletedAt' => $this->toIso($row['deleted_at'] ?? null),
            'deletedBy' => $this->nullableString($row['deleted_by'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapProduct(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'slug' => $this->nullableString($row['slug'] ?? null),
            'sku' => $this->nullableString($row['sku'] ?? null),
            'image' => $this->ensurePublicUploadedFileValue((string) ($row['image'] ?? '')),
            'category' => (string) ($row['category'] ?? ''),
            'unitId' => $this->nullableString($row['unit_id'] ?? null),
            'salePrice' => (float) ($row['sale_price'] ?? $row['salePrice'] ?? 0),
            'purchasePrice' => (float) ($row['purchase_price'] ?? $row['purchasePrice'] ?? 0),
            'stock' => (int) ($row['stock'] ?? 0),
            'dynamicPricing' => $this->nullableString($row['dynamic_pricing'] ?? null),
            'manufacturer' => $this->nullableString($row['manufacturer'] ?? null),
            'batchLotNumber' => $this->nullableString($row['batch_lot_number'] ?? null),
            'expiryDate' => $this->toIso($row['expiry_date'] ?? null),
            'recommendedDoseSequence' => $this->nullableString($row['recommended_dose_sequence'] ?? null),
            'notes' => $this->nullableString($row['notes'] ?? null),
            'createdBy' => $this->nullableString($row['created_by'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? null),
            'deletedAt' => $this->toIso($row['deleted_at'] ?? null),
            'deletedBy' => $this->nullableString($row['deleted_by'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapAccount(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'type' => (string) ($row['type'] ?? 'Bank'),
            'openingBalance' => (float) ($row['opening_balance'] ?? 0),
            'currentBalance' => (float) ($row['current_balance'] ?? 0),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapUser(array $row): array
    {
        $fixedSalary = isset($row['fixed_salary']) || isset($row['fixedSalary'])
            ? (float) ($row['fixed_salary'] ?? $row['fixedSalary'] ?? 0)
            : null;
        $unitAmount = isset($row['unit_amount']) || isset($row['unitAmount'])
            ? (float) ($row['unit_amount'] ?? $row['unitAmount'] ?? 0)
            : null;
        // Historic employee rows defaulted is_commission_based to false while
        // leaving salary empty. Preserve their operational commission behavior;
        // fixed salary is authoritative only when a positive salary exists.
        $isCommissionBased = !empty($row['is_commission_based'] ?? $row['isCommissionBased'] ?? false)
            || $fixedSalary === null
            || $fixedSalary <= 0;

        // Hybrid: commission-based with a positive fixed salary set
        if ($isCommissionBased && $fixedSalary !== null && $fixedSalary > 0) {
            $compensationType = 'hybrid';
        } elseif ($isCommissionBased) {
            $compensationType = 'commission';
        } else {
            $compensationType = 'fixed';
        }

        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'phone' => (string) ($row['phone'] ?? ''),
            'role' => (string) ($row['role'] ?? ''),
            'image' => $this->normalizeUserProfileImageValue(
                (string) ($row['image'] ?? ''),
                isset($row['id']) ? (string) $row['id'] : null
            ),
            'email' => $this->nullableString($row['email'] ?? null),
            'address' => $this->nullableString($row['address'] ?? null),
            'birthday' => $this->nullableString($row['birthday'] ?? null),
            'nidPassportCopy' => $this->nullableString($row['nid_passport_copy'] ?? $row['nidPassportCopy'] ?? null),
            'gender' => $this->nullableString($row['gender'] ?? null),
            'bloodGroup' => $this->nullableString($row['blood_group'] ?? $row['bloodGroup'] ?? null),
            'nationality' => $this->nullableString($row['nationality'] ?? null),
            'cv' => $this->nullableString($row['cv'] ?? null),
            'isCommissionBased' => $isCommissionBased,
            'compensationType' => $compensationType,
            'fixedSalary' => $fixedSalary,
            'unitAmount' => $unitAmount,
            'createdAt' => $this->toIso($row['created_at'] ?? null),
            'deletedAt' => $this->toIso($row['deleted_at'] ?? null),
            'deletedBy' => $this->nullableString($row['deleted_by'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function canonicalOrderStatus(string $status, array $history = []): string
    {
        $normalized = trim($status);
        if ($normalized === 'Created') {
            return 'On Hold';
        }

        $exchangeStatuses = [
            'Processing' => ['exchangeProcessing', 'Exchange processing'],
            'Picked' => ['exchangePicked', 'Exchange picked'],
            'Completed' => ['exchangeDelivered', 'Exchange delivered'],
            'Returned' => ['exchangeReturned', 'Exchange returned'],
            'Cancelled' => ['exchangeCancelled', 'Exchange cancelled'],
        ];
        if (isset($exchangeStatuses[$normalized])) {
            [$historyKey, $exchangeStatus] = $exchangeStatuses[$normalized];
            if (trim((string) ($history[$historyKey] ?? '')) !== '') {
                return $exchangeStatus;
            }
        }

        return $normalized;
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapOrder(array $row): array
    {
        $pageSnapshot = $this->jsonDecodeAssoc($row['page_snapshot'] ?? $row['pageSnapshot'] ?? []);
        $history = $this->jsonDecodeAssoc($row['history'] ?? []);

        return [
            'id' => (string) $row['id'],
            'orderNumber' => (string) ($row['order_number'] ?? $row['orderNumber'] ?? ''),
            'orderDate' => (string) ($row['order_date'] ?? $row['orderDate'] ?? ''),
            'customerId' => (string) ($row['customer_id'] ?? $row['customerId'] ?? ''),
            'createdBy' => (string) ($row['created_by'] ?? $row['createdBy'] ?? ''),
            'status' => $this->canonicalOrderStatus((string) ($row['status'] ?? ''), $history),
            'items' => $this->jsonDecodeList($row['items'] ?? []),
            'subtotal' => (float) ($row['subtotal'] ?? 0),
            'discount' => (float) ($row['discount'] ?? 0),
            'vatRate' => (float) ($row['vat_rate'] ?? $row['vatRate'] ?? 0),
            'vatAmount' => (float) ($row['vat_amount'] ?? $row['vatAmount'] ?? 0),
            'isPos' => (bool) ($row['is_pos'] ?? $row['isPos'] ?? false),
            'shipping' => (float) ($row['shipping'] ?? 0),
            'total' => (float) ($row['total'] ?? $row['amount'] ?? 0),
            'notes' => $this->nullableString($row['notes'] ?? null),
            'pageId' => $this->nullableString($row['page_id'] ?? $row['pageId'] ?? null),
            'pageSnapshot' => $pageSnapshot !== [] ? $pageSnapshot : null,
            'carrybeeConsignmentId' => $this->nullableString($row['carrybee_consignment_id'] ?? $row['carrybeeConsignmentId'] ?? null),
            'steadfastConsignmentId' => $this->nullableString($row['steadfast_consignment_id'] ?? $row['steadfastConsignmentId'] ?? null),
            'steadfastInvoice' => $this->nullableString($row['steadfast_invoice'] ?? $row['steadfastInvoice'] ?? null),
            'steadfastTrackingLink' => $this->nullableString($row['steadfast_tracking_link'] ?? $row['steadfastTrackingLink'] ?? null),
            'paperflyTrackingNumber' => $this->nullableString($row['paperfly_tracking_number'] ?? $row['paperflyTrackingNumber'] ?? null),
            'pathaoConsignmentId' => $this->nullableString($row['pathao_consignment_id'] ?? $row['pathaoConsignmentId'] ?? null),
            'exchangeCourier' => $this->nullableString($row['exchange_courier'] ?? $row['exchangeCourier'] ?? null),
            'exchangeSteadfastConsignmentId' => $this->nullableString($row['exchange_steadfast_consignment_id'] ?? $row['exchangeSteadfastConsignmentId'] ?? null),
            'exchangeCarrybeeConsignmentId' => $this->nullableString($row['exchange_carrybee_consignment_id'] ?? $row['exchangeCarrybeeConsignmentId'] ?? null),
            'exchangePaperflyTrackingNumber' => $this->nullableString($row['exchange_paperfly_tracking_number'] ?? $row['exchangePaperflyTrackingNumber'] ?? null),
            'exchangePathaoConsignmentId' => $this->nullableString($row['exchange_pathao_consignment_id'] ?? $row['exchangePathaoConsignmentId'] ?? null),
            'exchangeCourierHistory' => $this->nullableString($row['exchange_courier_history'] ?? $row['exchangeCourierHistory'] ?? null),
            'sourceAd' => $this->nullableString($row['source_ad'] ?? $row['sourceAd'] ?? null),
            'history' => $history,
            'paidAmount' => (float) ($row['paid_amount'] ?? $row['paidAmount'] ?? 0),
            'customerName' => $this->nullableString($row['customer_name'] ?? $row['customerName'] ?? null),
            'customerPhone' => $this->nullableString($row['customer_phone'] ?? $row['customerPhone'] ?? null),
            'customerAddress' => $this->nullableString($row['customer_address'] ?? $row['customerAddress'] ?? null),
            'creatorName' => $this->nullableString($row['creator_name'] ?? $row['creatorName'] ?? null),
            'pendingTransactionCount' => (int) ($row['pending_transaction_count'] ?? $row['pendingTransactionCount'] ?? 0),
            'pendingTransactionIds' => $this->jsonDecodeList($row['pending_transaction_ids'] ?? $row['pendingTransactionIds'] ?? []),
            'partialDeliveryActionRequired' => (bool) ($row['partial_delivery_action_required'] ?? $row['partialDeliveryActionRequired'] ?? false),
            'courierReturnActionRequired' => (bool) ($row['courier_return_action_required'] ?? $row['courierReturnActionRequired'] ?? false),
            'deliveryActionRequired' => (bool) ($row['delivery_action_required'] ?? $row['deliveryActionRequired'] ?? false),
            'partialCogsAmount' => (float) ($row['partial_cogs_amount'] ?? $row['partialCogsAmount'] ?? 0),
            'partialShippingAmount' => (float) ($row['partial_shipping_amount'] ?? $row['partialShippingAmount'] ?? 0),
            'partialCodAmount' => (float) ($row['partial_cod_amount'] ?? $row['partialCodAmount'] ?? 0),
            'surveyId' => $this->nullableString($row['survey_id'] ?? $row['surveyId'] ?? null),
            'surveyStatus' => $this->nullableString($row['survey_status'] ?? $row['surveyStatus'] ?? null),
            'surveyResponse' => $this->nullableString($row['survey_response'] ?? $row['surveyResponse'] ?? null),
            'surveyCallStatus' => $this->nullableString($row['survey_call_status'] ?? $row['surveyCallStatus'] ?? null),
            'confirmationStatus' => $this->nullableString($row['confirmation_status'] ?? $row['confirmationStatus'] ?? null),
            'surveyRetryCount' => (int) ($row['survey_retry_count'] ?? $row['surveyRetryCount'] ?? 0),
            'surveyNextRetryAt' => $this->toIso($row['survey_next_retry_at'] ?? $row['surveyNextRetryAt'] ?? null),
            'surveyTriggeredAt' => $this->toIso($row['survey_triggered_at'] ?? $row['surveyTriggeredAt'] ?? null),
            'surveyLastRetryReason' => $this->nullableString($row['survey_last_retry_reason'] ?? $row['surveyLastRetryReason'] ?? null),
            'surveyLastRetryAt' => $this->toIso($row['survey_last_retry_at'] ?? $row['surveyLastRetryAt'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null),
            'deletedAt' => $this->toIso($row['deleted_at'] ?? $row['deletedAt'] ?? null),
            'deletedBy' => $this->nullableString($row['deleted_by'] ?? $row['deletedBy'] ?? null),
            'processedAt' => $this->toIso($row['processed_at'] ?? $row['processedAt'] ?? null),
            'courierAssignedAt' => $this->toIso($row['courier_assigned_at'] ?? $row['courierAssignedAt'] ?? null),
            'pickedAt' => $this->toIso($row['picked_at'] ?? $row['pickedAt'] ?? null),
            'completedAt' => $this->toIso($row['completed_at'] ?? $row['completedAt'] ?? null),
            'returnedAt' => $this->toIso($row['returned_at'] ?? $row['returnedAt'] ?? null),
            'cancelledAt' => $this->toIso($row['cancelled_at'] ?? $row['cancelledAt'] ?? null),
            'partialDeliveredAt' => $this->toIso($row['partial_delivered_at'] ?? $row['partialDeliveredAt'] ?? null),
            'exchangeProcessingAt' => $this->toIso($row['exchange_processing_at'] ?? $row['exchangeProcessingAt'] ?? null),
            'exchangePickedAt' => $this->toIso($row['exchange_picked_at'] ?? $row['exchangePickedAt'] ?? null),
            'exchangeDeliveredAt' => $this->toIso($row['exchange_delivered_at'] ?? $row['exchangeDeliveredAt'] ?? null),
            'exchangeReturnedAt' => $this->toIso($row['exchange_returned_at'] ?? $row['exchangeReturnedAt'] ?? null),
            'exchangeCancelledAt' => $this->toIso($row['exchange_cancelled_at'] ?? $row['exchangeCancelledAt'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapBill(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'billNumber' => (string) ($row['bill_number'] ?? $row['billNumber'] ?? ''),
            'billDate' => (string) ($row['bill_date'] ?? $row['billDate'] ?? ''),
            'vendorId' => (string) ($row['vendor_id'] ?? $row['vendorId'] ?? ''),
            'createdBy' => (string) ($row['created_by'] ?? $row['createdBy'] ?? ''),
            'status' => (string) ($row['status'] ?? ''),
            'items' => $this->jsonDecodeList($row['items'] ?? []),
            'subtotal' => (float) ($row['subtotal'] ?? 0),
            'discount' => (float) ($row['discount'] ?? 0),
            'shipping' => (float) ($row['shipping'] ?? 0),
            'total' => (float) ($row['total'] ?? 0),
            'notes' => $this->nullableString($row['notes'] ?? null),
            'paidAmount' => (float) ($row['paid_amount'] ?? $row['paidAmount'] ?? 0),
            'history' => $this->jsonDecodeAssoc($row['history'] ?? []),
            'vendorName' => $this->nullableString($row['vendor_name'] ?? $row['vendorName'] ?? null),
            'vendorPhone' => $this->nullableString($row['vendor_phone'] ?? $row['vendorPhone'] ?? null),
            'vendorAddress' => $this->nullableString($row['vendor_address'] ?? $row['vendorAddress'] ?? null),
            'creatorName' => $this->nullableString($row['creator_name'] ?? $row['creatorName'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null),
            'deletedAt' => $this->toIso($row['deleted_at'] ?? $row['deletedAt'] ?? null),
            'deletedBy' => $this->nullableString($row['deleted_by'] ?? $row['deletedBy'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapTransaction(array $row): array
    {
        $dateValue = $row['date'] ?? $row['date_string'] ?? $row['created_at'] ?? $row['createdAt'] ?? null;

        return [
            'id' => (string) $row['id'],
            'date' => $this->toIso($dateValue) ?? (string) ($dateValue ?? ''),
            'type' => (string) ($row['type'] ?? ''),
            'category' => (string) ($row['category'] ?? ''),
            'accountId' => (string) ($row['account_id'] ?? $row['accountId'] ?? ''),
            'toAccountId' => $this->nullableString($row['to_account_id'] ?? $row['toAccountId'] ?? null),
            'amount' => (float) ($row['amount'] ?? 0),
            'description' => (string) ($row['description'] ?? ''),
            'referenceId' => $this->nullableString($row['reference_id'] ?? $row['referenceId'] ?? null),
            'recurringTransactionId' => $this->nullableString($row['recurring_transaction_id'] ?? $row['recurringTransactionId'] ?? null),
            'recurringScheduledFor' => $this->toIso($row['recurring_scheduled_for'] ?? $row['recurringScheduledFor'] ?? null),
            'contactId' => $this->nullableString($row['contact_id'] ?? $row['contactId'] ?? null),
            'paymentMethod' => (string) ($row['payment_method'] ?? $row['paymentMethod'] ?? ''),
            'attachmentName' => $this->nullableString($row['attachment_name'] ?? $row['attachmentName'] ?? null),
            'attachmentUrl' => $this->nullableString($row['attachment_url'] ?? $row['attachmentUrl'] ?? null),
            'createdBy' => (string) ($row['created_by'] ?? $row['createdBy'] ?? ''),
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null),
            'accountName' => $this->nullableString($row['account_name'] ?? $row['accountName'] ?? null),
            'contactName' => $this->nullableString($row['contact_name'] ?? $row['contactName'] ?? null),
            'contactType' => $this->nullableString($row['contact_type'] ?? $row['contactType'] ?? null),
            'creatorName' => $this->nullableString($row['creator_name'] ?? $row['creatorName'] ?? null),
            'approvalStatus' => (string) ($row['approval_status'] ?? $row['approvalStatus'] ?? 'approved'),
            'accountEffectApplied' => ((int) ($row['account_effect_applied'] ?? $row['accountEffectApplied'] ?? 1)) === 1,
            'approvalRequestedAt' => $this->toIso($row['approval_requested_at'] ?? $row['approvalRequestedAt'] ?? null),
            'approvedAt' => $this->toIso($row['approved_at'] ?? $row['approvedAt'] ?? null),
            'declinedAt' => $this->toIso($row['declined_at'] ?? $row['declinedAt'] ?? null),
            'approvalNote' => $this->nullableString($row['approval_note'] ?? $row['approvalNote'] ?? null),
            'deletedAt' => $this->toIso($row['deleted_at'] ?? $row['deletedAt'] ?? null),
            'deletedBy' => $this->nullableString($row['deleted_by'] ?? $row['deletedBy'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapCategory(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'type' => (string) ($row['type'] ?? ''),
            'color' => (string) ($row['color'] ?? '#3B82F6'),
            'isSystem' => (bool) ($row['is_system'] ?? $row['isSystem'] ?? false),
            'parentId' => $this->nullableString($row['parent_id'] ?? $row['parentId'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null),
            'updatedAt' => $this->toIso($row['updated_at'] ?? $row['updatedAt'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapPaymentMethod(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'description' => $this->nullableString($row['description'] ?? null),
            'isActive' => (bool) ($row['is_active'] ?? $row['isActive'] ?? false),
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null),
            'updatedAt' => $this->toIso($row['updated_at'] ?? $row['updatedAt'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapUnit(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'name' => (string) ($row['name'] ?? ''),
            'shortName' => (string) ($row['short_name'] ?? $row['shortName'] ?? ''),
            'description' => $this->nullableString($row['description'] ?? null),
            'isFraction' => (bool) ($row['is_fraction'] ?? false),
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null),
            'updatedAt' => $this->toIso($row['updated_at'] ?? $row['updatedAt'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function defaultPayrollSettings(): array
    {
        return [
            'unitAmount' => 0.0,
            'countedStatuses' => self::DEFAULT_PAYROLL_STATUSES,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapPayrollSettings(array $row): array
    {
        return [
            'unitAmount' => (float) ($row['unit_amount'] ?? $row['unitAmount'] ?? 0),
            'countedStatuses' => $this->normalizePayrollStatuses(
                $this->jsonDecodeList($row['counted_statuses'] ?? $row['countedStatuses'] ?? []),
                true
            ),
        ];
    }

    /**
     * @param array<string, array<string, mixed>> $userMap
     * @return array<string, mixed>
     */
    protected function mapPayrollPayment(array $row, array $userMap = []): array
    {
        $employee = $userMap[(string) ($row['employee_id'] ?? '')] ?? null;
        $payer = $userMap[(string) ($row['paid_by'] ?? '')] ?? null;
        $compensationType = trim((string) ($row['compensation_type'] ?? $row['compensationType'] ?? ''));
        if (!in_array($compensationType, ['commission', 'fixed', 'hybrid'], true)) {
            $employeeFixedSalary = ($employee['fixed_salary'] ?? $employee['fixedSalary'] ?? null) !== null
                ? (float) ($employee['fixed_salary'] ?? $employee['fixedSalary'])
                : null;
            $isCommissionBased = !empty($employee['is_commission_based'] ?? $employee['isCommissionBased'] ?? false)
                || $employeeFixedSalary === null
                || $employeeFixedSalary <= 0;
            if ($isCommissionBased && $employeeFixedSalary !== null && $employeeFixedSalary > 0) {
                $compensationType = 'hybrid';
            } else {
                $compensationType = $isCommissionBased ? 'commission' : 'fixed';
            }
        }
        $netAmount = (float) ($row['amount_snapshot'] ?? $row['amountSnapshot'] ?? 0);
        $baseAmount = array_key_exists('base_amount_snapshot', $row) || array_key_exists('baseAmountSnapshot', $row)
            ? (float) ($row['base_amount_snapshot'] ?? $row['baseAmountSnapshot'] ?? 0)
            : $netAmount;
        $isLegacySnapshot = $baseAmount === 0.0
            && $netAmount > 0
            && (float) ($row['bonus_amount'] ?? $row['bonusAmount'] ?? 0) === 0.0
            && (float) ($row['deduction_amount'] ?? $row['deductionAmount'] ?? 0) === 0.0
            && trim((string) ($row['wallet_payout_id'] ?? $row['walletPayoutId'] ?? '')) === ''
            && trim((string) ($row['transaction_id'] ?? $row['transactionId'] ?? '')) === '';
        if ($isLegacySnapshot) {
            $baseAmount = $netAmount;
        }

        return [
            'id' => (string) $row['id'],
            'employeeId' => (string) ($row['employee_id'] ?? ''),
            'employeeName' => $this->nullableString($row['employee_name'] ?? ($employee['name'] ?? null)),
            'employeeRole' => $this->nullableString($row['employee_role'] ?? ($employee['role'] ?? null)),
            'periodStart' => (string) ($row['period_start'] ?? ''),
            'periodEnd' => (string) ($row['period_end'] ?? ''),
            'periodKind' => (string) ($row['period_kind'] ?? ''),
            'periodLabel' => (string) ($row['period_label'] ?? (($row['period_start'] ?? '') . ' - ' . ($row['period_end'] ?? ''))),
            'unitAmountSnapshot' => (float) ($row['unit_amount_snapshot'] ?? 0),
            'countedStatusesSnapshot' => $this->normalizePayrollStatuses(
                $this->jsonDecodeList($row['counted_statuses_snapshot'] ?? []),
                true
            ),
            'orderCountSnapshot' => (int) ($row['order_count_snapshot'] ?? 0),
            'compensationType' => $compensationType,
            'isCommissionBased' => in_array($compensationType, ['commission', 'hybrid'], true),
            'fixedSalarySnapshot' => ($row['fixed_salary_snapshot'] ?? $row['fixedSalarySnapshot'] ?? null) !== null
                ? (float) ($row['fixed_salary_snapshot'] ?? $row['fixedSalarySnapshot'])
                : null,
            'baseAmountSnapshot' => $baseAmount,
            'bonusAmount' => (float) ($row['bonus_amount'] ?? $row['bonusAmount'] ?? 0),
            'deductionAmount' => (float) ($row['deduction_amount'] ?? $row['deductionAmount'] ?? 0),
            'amountSnapshot' => $netAmount,
            'netAmount' => $netAmount,
            'isPartial' => (int) ($row['is_partial'] ?? 0) === 1,
            'walletPayoutId' => $this->nullableString($row['wallet_payout_id'] ?? $row['walletPayoutId'] ?? null),
            'transactionId' => $this->nullableString($row['transaction_id'] ?? $row['transactionId'] ?? null),
            'accountId' => $this->nullableString($row['account_id'] ?? $row['accountId'] ?? null),
            'accountName' => $this->nullableString($row['account_name'] ?? $row['accountName'] ?? null),
            'paymentMethod' => $this->nullableString($row['payment_method'] ?? $row['paymentMethod'] ?? null),
            'categoryId' => $this->nullableString($row['category_id'] ?? $row['categoryId'] ?? null),
            'categoryName' => $this->nullableString($row['category_name'] ?? $row['categoryName'] ?? null),
            'paidAt' => $this->toIso($row['paid_at'] ?? null) ?? (string) ($row['paid_at'] ?? ''),
            'paidBy' => (string) ($row['paid_by'] ?? ''),
            'paidByName' => $this->nullableString($row['paid_by_name'] ?? ($payer['name'] ?? null)),
            'note' => $this->nullableString($row['note'] ?? null) ?? '',
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapWalletBalanceCard(array $row): array
    {
        return [
            'employeeId' => (string) ($row['employee_id'] ?? $row['employeeId'] ?? ''),
            'employeeName' => (string) ($row['employee_name'] ?? $row['employeeName'] ?? 'Unknown Employee'),
            'employeeRole' => (string) ($row['employee_role'] ?? $row['employeeRole'] ?? 'Employee'),
            'compensationType' => (string) ($row['compensation_type'] ?? $row['compensationType'] ?? 'commission'),
            'isCommissionBased' => !empty($row['is_commission_based'] ?? $row['isCommissionBased'] ?? true),
            'fixedSalary' => ($row['fixed_salary'] ?? $row['fixedSalary'] ?? null) !== null
                ? (float) ($row['fixed_salary'] ?? $row['fixedSalary'])
                : null,
            'unitAmount' => ($row['unit_amount'] ?? $row['unitAmount'] ?? null) !== null
                ? (float) ($row['unit_amount'] ?? $row['unitAmount'])
                : null,
            'balancePeriodStart' => $this->nullableString($row['balance_period_start'] ?? $row['balancePeriodStart'] ?? null),
            'balancePeriodEnd' => $this->nullableString($row['balance_period_end'] ?? $row['balancePeriodEnd'] ?? null),
            'baseEarned' => (float) ($row['base_earned'] ?? $row['baseEarned'] ?? $row['total_earned'] ?? $row['totalEarned'] ?? 0),
            'basePaid' => (float) ($row['base_paid'] ?? $row['basePaid'] ?? 0),
            'totalBonuses' => (float) ($row['total_bonuses'] ?? $row['totalBonuses'] ?? 0),
            'totalDeductions' => (float) ($row['total_deductions'] ?? $row['totalDeductions'] ?? 0),
            'currentBalance' => (float) ($row['current_balance'] ?? $row['currentBalance'] ?? 0),
            'totalEarned' => (float) ($row['total_earned'] ?? $row['totalEarned'] ?? 0),
            'totalPaid' => (float) ($row['total_paid'] ?? $row['totalPaid'] ?? 0),
            'creditedOrders' => (int) ($row['credited_orders'] ?? $row['creditedOrders'] ?? 0),
            'lastActivityAt' => $this->toIso($row['last_activity_at'] ?? $row['lastActivityAt'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapWalletActivityEntry(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'employeeId' => (string) ($row['employee_id'] ?? $row['employeeId'] ?? ''),
            'employeeName' => $this->nullableString($row['employee_name'] ?? $row['employeeName'] ?? null),
            'employeeRole' => $this->nullableString($row['employee_role'] ?? $row['employeeRole'] ?? null),
            'entryType' => (string) ($row['entry_type'] ?? $row['entryType'] ?? 'order_credit'),
            'amountDelta' => (float) ($row['amount_delta'] ?? $row['amountDelta'] ?? 0),
            'unitAmountSnapshot' => ($row['unit_amount_snapshot'] ?? $row['unitAmountSnapshot'] ?? null) !== null
                ? (float) ($row['unit_amount_snapshot'] ?? $row['unitAmountSnapshot'])
                : null,
            'orderId' => $this->nullableString($row['order_id'] ?? $row['orderId'] ?? null),
            'orderNumber' => $this->nullableString($row['order_number'] ?? $row['orderNumber'] ?? null),
            'payoutId' => $this->nullableString($row['payout_id'] ?? $row['payoutId'] ?? null),
            'payrollPaymentId' => $this->nullableString($row['payroll_payment_id'] ?? $row['payrollPaymentId'] ?? null),
            'transactionId' => $this->nullableString($row['transaction_id'] ?? $row['transactionId'] ?? null),
            'accountId' => $this->nullableString($row['account_id'] ?? $row['accountId'] ?? null),
            'accountName' => $this->nullableString($row['account_name'] ?? $row['accountName'] ?? null),
            'paymentMethod' => $this->nullableString($row['payment_method'] ?? $row['paymentMethod'] ?? null),
            'categoryId' => $this->nullableString($row['category_id'] ?? $row['categoryId'] ?? null),
            'categoryName' => $this->nullableString($row['category_name'] ?? $row['categoryName'] ?? null),
            'compensationType' => $this->nullableString($row['compensation_type'] ?? $row['compensationType'] ?? null),
            'baseAmountSnapshot' => ($row['base_amount_snapshot'] ?? $row['baseAmountSnapshot'] ?? null) !== null
                ? (float) ($row['base_amount_snapshot'] ?? $row['baseAmountSnapshot'])
                : null,
            'bonusAmount' => (float) ($row['bonus_amount'] ?? $row['bonusAmount'] ?? 0),
            'deductionAmount' => (float) ($row['deduction_amount'] ?? $row['deductionAmount'] ?? 0),
            'netAmount' => ($row['net_amount'] ?? $row['netAmount'] ?? null) !== null
                ? (float) ($row['net_amount'] ?? $row['netAmount'])
                : null,
            'periodStart' => $this->nullableString($row['period_start'] ?? $row['periodStart'] ?? null),
            'periodEnd' => $this->nullableString($row['period_end'] ?? $row['periodEnd'] ?? null),
            'note' => $this->nullableString($row['note'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? $row['createdAt'] ?? null) ?? (string) ($row['created_at'] ?? ''),
            'createdBy' => $this->nullableString($row['created_by'] ?? $row['createdBy'] ?? null),
            'createdByName' => $this->nullableString($row['created_by_name'] ?? $row['createdByName'] ?? null),
            'paidAt' => $this->toIso($row['paid_at'] ?? $row['paidAt'] ?? null),
            'paidBy' => $this->nullableString($row['paid_by'] ?? $row['paidBy'] ?? null),
            'paidByName' => $this->nullableString($row['paid_by_name'] ?? $row['paidByName'] ?? null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    protected function mapWalletPayout(array $row): array
    {
        return [
            'id' => (string) $row['id'],
            'employeeId' => (string) ($row['employee_id'] ?? $row['employeeId'] ?? ''),
            'amount' => (float) ($row['amount'] ?? 0),
            'accountId' => (string) ($row['account_id'] ?? $row['accountId'] ?? ''),
            'accountName' => $this->nullableString($row['account_name'] ?? $row['accountName'] ?? null),
            'paymentMethod' => (string) ($row['payment_method'] ?? $row['paymentMethod'] ?? ''),
            'categoryId' => (string) ($row['category_id'] ?? $row['categoryId'] ?? ''),
            'categoryName' => $this->nullableString($row['category_name'] ?? $row['categoryName'] ?? null),
            'transactionId' => (string) ($row['transaction_id'] ?? $row['transactionId'] ?? ''),
            'payrollPaymentId' => $this->nullableString($row['payroll_payment_id'] ?? $row['payrollPaymentId'] ?? null),
            'compensationType' => $this->nullableString($row['compensation_type'] ?? $row['compensationType'] ?? null),
            'baseAmount' => (float) ($row['base_amount'] ?? $row['baseAmount'] ?? 0),
            'bonusAmount' => (float) ($row['bonus_amount'] ?? $row['bonusAmount'] ?? 0),
            'deductionAmount' => (float) ($row['deduction_amount'] ?? $row['deductionAmount'] ?? 0),
            'netAmount' => (float) ($row['net_amount'] ?? $row['netAmount'] ?? $row['amount'] ?? 0),
            'periodStart' => $this->nullableString($row['period_start'] ?? $row['periodStart'] ?? null),
            'periodEnd' => $this->nullableString($row['period_end'] ?? $row['periodEnd'] ?? null),
            'paidAt' => $this->toIso($row['paid_at'] ?? $row['paidAt'] ?? null) ?? (string) ($row['paid_at'] ?? ''),
            'paidBy' => (string) ($row['paid_by'] ?? $row['paidBy'] ?? ''),
            'paidByName' => $this->nullableString($row['paid_by_name'] ?? $row['paidByName'] ?? null),
            'note' => $this->nullableString($row['note'] ?? null),
        ];
    }

    protected function tableExists(string $table): bool
    {
        if (array_key_exists($table, $this->tableExistsCache)) {
            return $this->tableExistsCache[$table];
        }

        $row = $this->database->fetchOne(
            'SELECT 1 AS present
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = :table
             LIMIT 1',
            [':table' => $table]
        );

        $this->tableExistsCache[$table] = $row !== null;
        return $this->tableExistsCache[$table];
    }

    protected function columnExists(string $table, string $column): bool
    {
        $cacheKey = $table . '.' . $column;
        if (array_key_exists($cacheKey, $this->columnExistsCache)) {
            return $this->columnExistsCache[$cacheKey];
        }

        $row = $this->database->fetchOne(
            'SELECT 1 AS present
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = :table
               AND COLUMN_NAME = :column
             LIMIT 1',
            [
                ':table' => $table,
                ':column' => $column,
            ]
        );

        // Cache only positive results. A service may add a column during its
        // own lazy schema initialization; retaining a cached `false` would
        // make the next call attempt the same ALTER TABLE again.
        $present = $row !== null;
        if ($present) {
            $this->columnExistsCache[$cacheKey] = true;
        }
        return $present;
    }

    /** Filter out columns that do not exist in the given table. */
    private function filterExistingColumns(string $table, array $payload): array
    {
        if (!$this->tableExists($table)) return $payload;

        $filtered = [];
        foreach ($payload as $column => $value) {
            if ($this->columnExists($table, $column)) {
                $filtered[$column] = $value;
            }
        }
        return $filtered;
    }

    protected function normalizeRoleName(string $role): string
    {
        $normalized = preg_replace('/\s+/', ' ', trim($role));
        return $normalized !== null ? trim($normalized) : trim($role);
    }

    protected function isReservedPermissionRole(string $role): bool
    {
        return in_array($this->normalizeRoleName($role), self::RESERVED_PERMISSION_ROLES, true);
    }

    protected function isBuiltInPermissionRole(string $role): bool
    {
        return in_array($this->normalizeRoleName($role), self::BUILT_IN_PERMISSION_ROLES, true);
    }

    protected function legacyPermissionGrantsAnyAccess(string $role): bool
    {
        return !$this->isBuiltInPermissionRole($role);
    }

    /**
     * @return array<string, bool>
     */
    protected function blankRolePermissions(): array
    {
        $permissions = [];
        foreach (self::ROLE_PERMISSION_KEYS as $key) {
            $permissions[$key] = false;
        }

        return $permissions;
    }

    /**
     * @return array<string, bool>
     */
    protected function allEnabledRolePermissions(): array
    {
        $permissions = [];
        foreach (self::ROLE_PERMISSION_KEYS as $key) {
            $permissions[$key] = true;
        }

        return $permissions;
    }

    /**
     * @return array<string, bool>
     */
    protected function defaultRolePermissions(string $role): array
    {
        $normalizedRole = $this->normalizeRoleName($role);
        if ($this->isReservedPermissionRole($normalizedRole)) {
            return $this->allEnabledRolePermissions();
        }

        $permissions = $this->blankRolePermissions();
        $defaults = self::DEFAULT_ROLE_PERMISSIONS[$normalizedRole] ?? [];
        foreach ($defaults as $key => $enabled) {
            if (in_array($key, self::ROLE_PERMISSION_KEYS, true)) {
                $permissions[$key] = (bool) $enabled;
            }
        }

        return $permissions;
    }

    /**
     * @param mixed $value
     * @param array<string, bool>|null $fallback
     * @return array<string, bool>
     */
    protected function normalizeRolePermissions($value, ?array $fallback = null, ?string $roleName = null): array
    {
        $raw = is_array($value) ? $value : $this->jsonDecodeAssoc($value);
        $permissions = $this->blankRolePermissions();
        $normalizedRole = $this->normalizeRoleName((string) ($roleName ?? ''));

        foreach (self::ROLE_PERMISSION_KEYS as $key) {
            if (array_key_exists($key, $raw)) {
                $permissions[$key] = (bool) $raw[$key];
                continue;
            }

            if ($fallback !== null && array_key_exists($key, $fallback)) {
                $permissions[$key] = (bool) $fallback[$key];
            }
        }

        foreach (self::LEGACY_SCOPED_PERMISSION_KEYS as $config) {
            $legacyKey = (string) ($config['legacy'] ?? '');
            $ownKey = (string) ($config['own'] ?? '');
            $anyKey = (string) ($config['any'] ?? '');

            if ($legacyKey === '' || !array_key_exists($legacyKey, $raw) || !is_bool($raw[$legacyKey])) {
                continue;
            }

            if ($ownKey !== '' && !array_key_exists($ownKey, $raw)) {
                $permissions[$ownKey] = (bool) $raw[$legacyKey];
            }

            if ($anyKey !== '' && !array_key_exists($anyKey, $raw)) {
                $permissions[$anyKey] = (bool) $raw[$legacyKey] && $this->legacyPermissionGrantsAnyAccess($normalizedRole);
            }
        }

        return $permissions;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    protected function fetchStoredRolePermissionRows(): array
    {
        if (!$this->tableExists('role_permissions')) {
            return [];
        }

        $dashboardColumn = $this->columnExists('role_permissions', 'dashboard_id')
            ? 'dashboard_id'
            : 'NULL AS dashboard_id';
        return $this->database->fetchAll(
            'SELECT role_name, permissions, ' . $dashboardColumn . ', is_custom, created_at, updated_at
             FROM role_permissions
             ORDER BY is_custom ASC, role_name ASC'
        );
    }

    /**
     * @param mixed $value
     */
    protected function normalizeOrderKpiTimeBasis($value): string
    {
        return in_array((string) $value, ['created_at', 'status_at'], true) ? (string) $value : 'created_at';
    }

    /**
     * @param mixed $value
     * @param array<string, string> $registry
     * @return array<int, array{key: string, enabled: bool}>
     */
    protected function normalizeDashboardItems($value, array $registry, ?string $systemKey = null): array
    {
        $raw = is_array($value) ? $value : $this->jsonDecodeList($value);
        $normalized = [];
        $seen = [];
        foreach ($raw as $item) {
            if (!is_array($item)) continue;
            $key = trim((string) ($item['key'] ?? ''));
            if ($key === '' || !isset($registry[$key]) || isset($seen[$key])) continue;
            $seen[$key] = true;
            $widthPercent = isset($item['widthPercent']) ? (int) $item['widthPercent'] : null;
            $entry = ['key' => $key, 'enabled' => !empty($item['enabled'])];
            if ($widthPercent !== null && $widthPercent >= 10 && $widthPercent <= 100) {
                $entry['widthPercent'] = $widthPercent;
            }
            $normalized[] = $entry;
        }

        $defaultKeys = [];
        if ($systemKey === 'admin') {
            $defaultKeys = $registry === self::DASHBOARD_KPI_SCOPES
                ? self::ADMIN_DEFAULT_DASHBOARD_KPIS
                : self::ADMIN_DEFAULT_DASHBOARD_WIDGETS;
        } elseif ($systemKey === 'employee') {
            $defaultKeys = $registry === self::DASHBOARD_KPI_SCOPES
                ? self::EMPLOYEE_DEFAULT_DASHBOARD_KPIS
                : self::EMPLOYEE_DEFAULT_DASHBOARD_WIDGETS;
        }

        foreach ($registry as $key => $_scope) {
            if (isset($seen[$key])) continue;
            $normalized[] = ['key' => $key, 'enabled' => in_array($key, $defaultKeys, true)];
        }
        return $normalized;
    }

    /** @return array<int, array{key: string, enabled: bool}> */
    protected function defaultDashboardItems(array $registry, string $systemKey): array
    {
        return $this->normalizeDashboardItems([], $registry, $systemKey);
    }

    protected function ensureSystemDashboardConfigurations(): void
    {
        if (!$this->tableExists('dashboard_configurations')) return;
        $now = $this->database->nowUtc();
        $rows = [
            [
                'id' => self::ADMIN_DEFAULT_DASHBOARD_ID,
                'name' => 'Admin Dashboard (Default)',
                'systemKey' => 'admin',
                'kpis' => $this->defaultDashboardItems(self::DASHBOARD_KPI_SCOPES, 'admin'),
                'widgets' => $this->defaultDashboardItems(self::DASHBOARD_WIDGET_SCOPES, 'admin'),
            ],
            [
                'id' => self::EMPLOYEE_DEFAULT_DASHBOARD_ID,
                'name' => 'Employee Dashboard (Default)',
                'systemKey' => 'employee',
                'kpis' => $this->defaultDashboardItems(self::DASHBOARD_KPI_SCOPES, 'employee'),
                'widgets' => $this->defaultDashboardItems(self::DASHBOARD_WIDGET_SCOPES, 'employee'),
            ],
        ];
        foreach ($rows as $row) {
            $this->database->execute(
                'INSERT IGNORE INTO dashboard_configurations
                    (id, name, is_system, system_key, kpi_cards, widgets, order_kpi_time_basis, created_at, updated_at)
                 VALUES
                    (:id, :name, 1, :system_key, :kpi_cards, :widgets, :order_kpi_time_basis, :created_at, :updated_at)',
                [
                    ':id' => $row['id'],
                    ':name' => $row['name'],
                    ':system_key' => $row['systemKey'],
                    ':kpi_cards' => $this->jsonEncode($row['kpis']),
                    ':widgets' => $this->jsonEncode($row['widgets']),
                    ':order_kpi_time_basis' => 'created_at',
                    ':created_at' => $now,
                    ':updated_at' => $now,
                ]
            );
        }
    }

    /** @return array<string, mixed> */
    protected function normalizeDashboardConfigurationRow(array $row): array
    {
        $id = trim((string) ($row['id'] ?? ''));
        $systemKey = match ($id) {
            self::ADMIN_DEFAULT_DASHBOARD_ID => 'admin',
            self::EMPLOYEE_DEFAULT_DASHBOARD_ID => 'employee',
            default => in_array(($row['system_key'] ?? null), ['admin', 'employee'], true)
                ? (string) $row['system_key']
                : null,
        };
        $name = match ($systemKey) {
            'admin' => 'Admin Dashboard (Default)',
            'employee' => 'Employee Dashboard (Default)',
            default => trim((string) ($row['name'] ?? '')),
        };
        return [
            'id' => $id,
            'name' => $name,
            'isSystem' => $systemKey !== null,
            'systemKey' => $systemKey,
            'kpiCards' => $this->normalizeDashboardItems($row['kpi_cards'] ?? null, self::DASHBOARD_KPI_SCOPES, $systemKey),
            'widgets' => $this->normalizeDashboardItems($row['widgets'] ?? null, self::DASHBOARD_WIDGET_SCOPES, $systemKey),
            'orderKpiTimeBasis' => $this->normalizeOrderKpiTimeBasis($row['order_kpi_time_basis'] ?? null),
            'createdAt' => $this->toIso($row['created_at'] ?? null),
            'updatedAt' => $this->toIso($row['updated_at'] ?? null),
        ];
    }

    /** @return array{dashboards: array<int, array<string, mixed>>} */
    protected function buildDashboardSettingsPayload(): array
    {
        if (!$this->tableExists('dashboard_configurations')) {
            return ['dashboards' => []];
        }
        $rows = $this->database->fetchAll(
            'SELECT id, name, is_system, system_key, kpi_cards, widgets, order_kpi_time_basis, created_at, updated_at
             FROM dashboard_configurations
             ORDER BY is_system DESC, CASE system_key WHEN \'admin\' THEN 0 WHEN \'employee\' THEN 1 ELSE 2 END, name ASC'
        );
        $dashboards = array_values(array_map(
            fn(array $row): array => $this->normalizeDashboardConfigurationRow($row),
            $rows
        ));
        $ids = array_fill_keys(array_map(static fn(array $dashboard): string => (string) $dashboard['id'], $dashboards), true);
        foreach ([
            [self::ADMIN_DEFAULT_DASHBOARD_ID, 'Admin Dashboard (Default)', 'admin'],
            [self::EMPLOYEE_DEFAULT_DASHBOARD_ID, 'Employee Dashboard (Default)', 'employee'],
        ] as [$id, $name, $systemKey]) {
            if (isset($ids[$id])) continue;
            $dashboards[] = $this->normalizeDashboardConfigurationRow([
                'id' => $id,
                'name' => $name,
                'is_system' => 1,
                'system_key' => $systemKey,
                'kpi_cards' => [],
                'widgets' => [],
                'created_at' => null,
                'updated_at' => null,
            ]);
        }
        usort($dashboards, static function (array $left, array $right): int {
            if ((bool) ($left['isSystem'] ?? false) !== (bool) ($right['isSystem'] ?? false)) {
                return !empty($left['isSystem']) ? -1 : 1;
            }
            $systemOrder = ['admin' => 0, 'employee' => 1];
            $leftOrder = $systemOrder[(string) ($left['systemKey'] ?? '')] ?? 2;
            $rightOrder = $systemOrder[(string) ($right['systemKey'] ?? '')] ?? 2;
            return $leftOrder !== $rightOrder
                ? $leftOrder <=> $rightOrder
                : strcmp((string) ($left['name'] ?? ''), (string) ($right['name'] ?? ''));
        });
        return ['dashboards' => $dashboards];
    }

    /** @return array<string, mixed>|null */
    protected function dashboardConfigurationById(string $dashboardId): ?array
    {
        $dashboardId = trim($dashboardId);
        if ($dashboardId === '') return null;
        foreach ($this->buildDashboardSettingsPayload()['dashboards'] as $dashboard) {
            if ((string) ($dashboard['id'] ?? '') === $dashboardId) return $dashboard;
        }
        return null;
    }

    /** @return array{admin: bool, employee: bool}|null */
    protected function dashboardScopesForId(string $dashboardId): ?array
    {
        $dashboard = $this->dashboardConfigurationById($dashboardId);
        if ($dashboard === null) return null;
        $scopes = ['admin' => false, 'employee' => false];
        foreach ([
            [$dashboard['kpiCards'] ?? [], self::DASHBOARD_KPI_SCOPES],
            [$dashboard['widgets'] ?? [], self::DASHBOARD_WIDGET_SCOPES],
        ] as [$items, $registry]) {
            foreach ((array) $items as $item) {
                if (!is_array($item) || empty($item['enabled'])) continue;
                $scope = $registry[(string) ($item['key'] ?? '')] ?? null;
                if ($scope !== null) $scopes[$scope] = true;
            }
        }
        return $scopes;
    }

    protected function fallbackDashboardIdForPermissions(array $permissions): string
    {
        return !empty($permissions['dashboard.viewAdmin'])
            ? self::ADMIN_DEFAULT_DASHBOARD_ID
            : self::EMPLOYEE_DEFAULT_DASHBOARD_ID;
    }

    /** @param array<string, bool> $permissions */
    protected function applyDashboardPermissions(array &$permissions, string $dashboardId): string
    {
        $scopes = $this->dashboardScopesForId($dashboardId);
        if ($scopes === null) {
            $dashboardId = $this->fallbackDashboardIdForPermissions($permissions);
            $scopes = $this->dashboardScopesForId($dashboardId);
        }
        if ($scopes !== null) {
            $permissions['dashboard.viewAdmin'] = $scopes['admin'];
            $permissions['dashboard.viewEmployee'] = $scopes['employee'];
        }
        return $dashboardId;
    }

    /**
     * @return array<string, mixed>
     */
    protected function buildPermissionsSettingsPayload(): array
    {
        if ($this->permissionsSettingsPayloadCache !== null) {
            return $this->permissionsSettingsPayloadCache;
        }

        $rolesByName = [];

        foreach (self::BUILT_IN_PERMISSION_ROLES as $roleName) {
            $defaultPermissions = $this->defaultRolePermissions($roleName);
            $dashboardId = $roleName === 'Admin'
                ? self::ADMIN_DEFAULT_DASHBOARD_ID
                : $this->applyDashboardPermissions($defaultPermissions, self::EMPLOYEE_DEFAULT_DASHBOARD_ID);
            $rolesByName[$roleName] = [
                'roleName' => $roleName,
                'isCustom' => false,
                'dashboardId' => $dashboardId,
                'permissions' => $defaultPermissions,
                'createdAt' => null,
                'updatedAt' => null,
            ];
        }

        foreach ($this->fetchStoredRolePermissionRows() as $row) {
            $roleName = $this->normalizeRoleName((string) ($row['role_name'] ?? ''));
            if ($roleName === '' || $roleName === 'Developer') {
                continue;
            }

            if ($roleName === 'Employee1') {
                // Employee1 was removed as a built-in role, so ignore any stale stored entries.
                continue;
            }

            $isCustomRow = (int) ($row['is_custom'] ?? 0) === 1;
            if (!$this->isBuiltInPermissionRole($roleName) && !$isCustomRow) {
                // Ignore stale stored rows for roles that used to be built-in but are no longer defined.
                continue;
            }

            $defaultPermissions = isset($rolesByName[$roleName]['permissions']) && is_array($rolesByName[$roleName]['permissions'])
                ? $rolesByName[$roleName]['permissions']
                : $this->defaultRolePermissions($roleName);

            $normalizedPermissions = $roleName === 'Admin'
                ? $this->allEnabledRolePermissions()
                : $this->normalizeRolePermissions($row['permissions'] ?? null, $defaultPermissions, $roleName);
            $dashboardId = trim((string) ($row['dashboard_id'] ?? ''));
            if ($dashboardId === '') $dashboardId = $this->fallbackDashboardIdForPermissions($normalizedPermissions);
            if ($this->dashboardConfigurationById($dashboardId) === null) {
                $dashboardId = $roleName === 'Admin' ? self::ADMIN_DEFAULT_DASHBOARD_ID : self::EMPLOYEE_DEFAULT_DASHBOARD_ID;
            }
            if ($roleName !== 'Admin') {
                $dashboardId = $this->applyDashboardPermissions($normalizedPermissions, $dashboardId);
            }
            $rolesByName[$roleName] = [
                'roleName' => $roleName,
                'isCustom' => !$this->isBuiltInPermissionRole($roleName),
                'dashboardId' => $dashboardId,
                'permissions' => $normalizedPermissions,
                'createdAt' => $this->toIso($row['created_at'] ?? null),
                'updatedAt' => $this->toIso($row['updated_at'] ?? null),
            ];
        }

        $roles = array_values($rolesByName);
        usort($roles, static function (array $left, array $right): int {
            if ((bool) ($left['isCustom'] ?? false) !== (bool) ($right['isCustom'] ?? false)) {
                return (bool) ($left['isCustom'] ?? false) ? 1 : -1;
            }

            return strcmp((string) ($left['roleName'] ?? ''), (string) ($right['roleName'] ?? ''));
        });

        $this->permissionsSettingsPayloadCache = ['roles' => $roles];
        return $this->permissionsSettingsPayloadCache;
    }

    protected function dashboardIdForRole(string $role): string
    {
        $normalizedRole = $this->normalizeRoleName($role);
        if ($normalizedRole === 'Developer') return self::ADMIN_DEFAULT_DASHBOARD_ID;
        foreach ($this->buildPermissionsSettingsPayload()['roles'] as $roleConfig) {
            if ((string) ($roleConfig['roleName'] ?? '') === $normalizedRole) {
                return (string) ($roleConfig['dashboardId'] ?? self::EMPLOYEE_DEFAULT_DASHBOARD_ID);
            }
        }
        return $normalizedRole === 'Admin' ? self::ADMIN_DEFAULT_DASHBOARD_ID : self::EMPLOYEE_DEFAULT_DASHBOARD_ID;
    }

    /**
     * @return array<string, bool>
     */
    protected function permissionsForRole(string $role): array
    {
        $normalizedRole = $this->normalizeRoleName($role);
        if ($normalizedRole === '') {
            return $this->blankRolePermissions();
        }

        if ($this->isReservedPermissionRole($normalizedRole)) {
            return $this->allEnabledRolePermissions();
        }

        $settings = $this->buildPermissionsSettingsPayload();
        $roles = is_array($settings['roles'] ?? null) ? $settings['roles'] : [];
        foreach ($roles as $roleConfig) {
            if ($this->normalizeRoleName((string) ($roleConfig['roleName'] ?? '')) === $normalizedRole) {
                return $this->normalizeRolePermissions(
                    $roleConfig['permissions'] ?? null,
                    $this->defaultRolePermissions($normalizedRole),
                    $normalizedRole
                );
            }
        }

        return $this->defaultRolePermissions($normalizedRole);
    }

    protected function roleHasPermission(string $role, string $permission): bool
    {
        if (!in_array($permission, self::ROLE_PERMISSION_KEYS, true)) {
            return false;
        }

        $permissions = $this->permissionsForRole($role);
        return (bool) ($permissions[$permission] ?? false);
    }

    protected function currentUserHasPermission(string $permission): bool
    {
        $user = $this->currentUser();
        return $this->roleHasPermission((string) ($user['role'] ?? ''), $permission);
    }

    /**
     * @param array<string, mixed> $user
     */
    protected function userHasScopedPermissionForRecord(array $user, ?string $createdBy, string $ownPermission, string $anyPermission): bool
    {
        $role = (string) ($user['role'] ?? '');
        if ($this->roleHasPermission($role, $anyPermission)) {
            return true;
        }

        $normalizedCreatedBy = trim((string) ($createdBy ?? ''));
        return $normalizedCreatedBy !== ''
            && $normalizedCreatedBy === (string) ($user['id'] ?? '')
            && $this->roleHasPermission($role, $ownPermission);
    }

    protected function currentUserHasScopedPermissionForRecord(?string $createdBy, string $ownPermission, string $anyPermission): bool
    {
        return $this->userHasScopedPermissionForRecord($this->currentUser(), $createdBy, $ownPermission, $anyPermission);
    }

    protected function isEmployeeRole(string $role): bool
    {
        return in_array($role, ['Employee'], true);
    }

    protected function hasAdminAccess(string $role): bool
    {
        return in_array($role, ['Admin', 'Developer'], true);
    }

    /**
     * @param array<int, mixed> $statuses
     * @return array<int, string>
     */
    protected function normalizePayrollStatuses(array $statuses, bool $fallbackToDefault): array
    {
        $allowed = self::ALL_ORDER_STATUSES;
        $normalized = [];
        foreach ($statuses as $status) {
            $statusText = $this->canonicalOrderStatus((string) $status);
            if ($statusText !== '' && in_array($statusText, $allowed, true) && !in_array($statusText, $normalized, true)) {
                $normalized[] = $statusText;
            }
        }

        if ($normalized !== []) {
            return $normalized;
        }

        return $fallbackToDefault ? self::DEFAULT_PAYROLL_STATUSES : [];
    }

    protected function isWalletEligibleOrderDate(string $orderDate, string $createdAt): bool
    {
        $activityDate = $this->walletEligibleLocalDate($orderDate, $createdAt);
        return $activityDate !== '' && $activityDate >= $this->walletCutoffDate();
    }

    protected function walletCutoffDate(): string
    {
        return $this->config->get('WALLET_CUTOFF_DATE', self::DEFAULT_WALLET_CUTOFF_DATE)
            ?? self::DEFAULT_WALLET_CUTOFF_DATE;
    }

    protected function walletCutoffAtUtc(): string
    {
        return $this->normalizeDateTimeInput(
            $this->config->get('WALLET_CUTOFF_AT_UTC', self::DEFAULT_WALLET_CUTOFF_AT_UTC)
            ?? self::DEFAULT_WALLET_CUTOFF_AT_UTC
        );
    }

    protected function localDateFromUtc(?string $value): string
    {
        $trimmed = trim((string) $value);
        if ($trimmed === '') {
            return '';
        }

        $date = $this->parseDateTimeValue($trimmed, $this->utcTimezone());
        if (!$date instanceof \DateTimeImmutable) {
            return '';
        }

        $timezone = new \DateTimeZone($this->config->timezone());
        return $date->setTimezone($timezone)->format('Y-m-d');
    }

    protected function walletEligibleLocalDate(string $orderDate, string $createdAt): string
    {
        $createdLocalDate = $this->localDateFromUtc($createdAt);
        if ($createdLocalDate !== '') {
            return $createdLocalDate;
        }

        return $this->normalizeDateOnly($orderDate);
    }

    protected function pipraPayApiUrl(string $configuredBaseUrl, string $endpoint): string
    {
        $baseUrl = trim($configuredBaseUrl);
        $path = '/' . ltrim(trim($endpoint), '/');

        // Settings historically accepted a host URL, a URL ending in /api, or
        // (for checkout) the complete provider endpoint. Normalize all three
        // forms to the PipraPay V3 API root so verification always resolves to
        // e.g. https://sandbox.piprapay.com/api/verify-payment exactly once.
        $baseUrl = preg_replace('#/(?:api/)?(?:checkout/redirect|verify-payment)/?$#i', '', $baseUrl) ?? $baseUrl;
        $baseUrl = rtrim($baseUrl, '/');
        if (preg_match('#/api$#i', $baseUrl) !== 1) {
            $baseUrl .= '/api';
        }

        return $baseUrl . $path;
    }

    protected function appendUrlQueryParameter(string $url, string $name, string $value): string
    {
        $fragment = '';
        $fragmentPosition = strpos($url, '#');
        if ($fragmentPosition !== false) {
            $fragment = substr($url, $fragmentPosition);
            $url = substr($url, 0, $fragmentPosition);
        }

        if ($fragment !== '') {
            $separator = str_contains($fragment, '?') ? '&' : '?';
            return $url . $fragment . $separator . rawurlencode($name) . '=' . rawurlencode($value);
        }

        $separator = str_contains($url, '?') ? '&' : '?';
        return $url . $separator . rawurlencode($name) . '=' . rawurlencode($value);
    }
}
