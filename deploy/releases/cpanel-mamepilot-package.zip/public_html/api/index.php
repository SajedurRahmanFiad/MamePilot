<?php

declare(strict_types=1);

use App\AppVersion;
use App\Auth;
use App\AutoCallApi;
use App\BusinessGrowthApi;
use App\Config;
use App\CourierApi;
use App\DataManagementApi;
use App\Database;
use App\ExternalDataApi;
use App\FeatureAccess;
use App\GitUpdateDispatcher;
use App\Http;
use App\LeadApi;
use App\MasterDataApi;
use App\MetaAdsApi;
use App\MessengerApi;
use App\OperationsApi;
use App\OrderPostCreateEffects;
use App\RecurringTransactionApi;
use App\RecurringTransactionScheduler;
use App\SmsApi;
use App\WhatsAppApi;
use App\WooCommerceApi;
use App\ShopifyApi;
use App\UpdateScheduler;

require_once __DIR__ . DIRECTORY_SEPARATOR . 'app-root.php';

$appRoot = mamepilotResolveAppRoot();

$bootstrapPath = $appRoot . DIRECTORY_SEPARATOR . 'backend' . DIRECTORY_SEPARATOR . 'bootstrap.php';
if (!is_file($bootstrapPath)) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'error' => 'Backend bootstrap not found.',
        'expected' => $bootstrapPath,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

require_once $bootstrapPath;

if (Http::method() === 'OPTIONS') {
    Http::ok(['ok' => true]);
    exit;
}

try {
    $body = Http::jsonBody();
    $action = trim((string) ($_GET['action'] ?? $body['action'] ?? ''));
    $externalApiRequest = ExternalDataApi::matchesPath(Http::path());
    if ($action === '' && !$externalApiRequest) {
        Http::error(400, 'Missing action.');
        exit;
    }

    $payload = $body;
    unset($payload['action']);
    foreach ($_GET as $key => $value) {
        if ($key === 'action') {
            continue;
        }
        $payload[$key] = $value;
    }

    $config = Config::load($appRoot);
    try {
        (new UpdateScheduler($config))->ensureInstalledIfDue();
    } catch (Throwable $exception) {
        error_log('MamePilot automatic update cron self-heal failed: ' . $exception->getMessage());
    }
    $database = new Database($config);
    $auth = new Auth($config, $database);
    if ($externalApiRequest) {
        $response = (new ExternalDataApi($database, $auth, $config))->handleRequest(
            Http::method(),
            Http::path(),
            $_GET,
            $body
        );
        if ($response === null) {
            Http::error(404, 'Unknown external API route.');
            exit;
        }
        Http::respond($response['status'], $response['body']);
        exit;
    }

    $recurringScheduler = new RecurringTransactionScheduler($database, $auth, $config);
    register_shutdown_function(static function () use ($recurringScheduler): void {
        $recurringScheduler->triggerIfNeeded();
    });
    $serviceLifecycle = new \App\ServiceLifecycle($database, $config);
    $featureAccess = new FeatureAccess($database, $auth);
    $master = new MasterDataApi($database, $auth, $config);
    $operations = new OperationsApi($database, $auth, $config);
    $courier = new CourierApi($database, $auth, $config, $operations);
    $dataManagement = new DataManagementApi($database, $auth, $config);
    $metaAds = new MetaAdsApi($database, $auth, $config);
    $whatsapp = new WhatsAppApi($database, $auth, $config);
    $messenger = new MessengerApi($database, $auth, $config);
    $businessGrowth = new BusinessGrowthApi($database, $auth, $config);
    $autoCall = new AutoCallApi($database, $auth, $config);
    $sms = new SmsApi($database, $auth, $config);
    $postCreateEffects = new OrderPostCreateEffects($featureAccess, $autoCall);
    $woocommerce = new WooCommerceApi($database, $auth, $config, $operations, $postCreateEffects);
    $shopify = new ShopifyApi($database, $auth, $config, $operations, $postCreateEffects);
    $recurringTransactions = new RecurringTransactionApi($database, $auth, $config);
    $lead = new LeadApi($database, $auth, $config, $master, $operations);

    if ($action === 'health') {
        Http::ok(array_merge([
            'ok' => true,
            'time' => gmdate('c'),
            'db' => $database->fetchOne('SELECT 1 AS ok'),
            'appRoot' => $appRoot,
        ], AppVersion::info($appRoot)));
        exit;
    }

    if ($action === 'metaAdsOAuthCallback') {
        $metaAds->redirectAfterOAuth($payload);
        exit;
    }

    // Keep signed central notification delivery available even when normal
    // write actions are restricted by maintenance/subscription state.
    if ($action === 'receiveCentralNotification') {
        Http::ok($master->receiveCentralNotification($payload));
        exit;
    }

    if ($action === 'triggerGitUpdate') {
        $auth->requireUser();
        Http::ok((new GitUpdateDispatcher($config))->dispatch());
        exit;
    }

    $serviceLifecycle->assertActionAllowed($action);
    $featureAccess->assertActionAllowed($action, $payload);

    if ($action === 'batchUpdateSettings') {
        $updates = is_array($payload['updates'] ?? null) ? $payload['updates'] : $payload;
        if (isset($updates['courier']) && is_array($updates['courier'])) {
            $featureAccess->assertActionAllowed('updateCourierSettings', $updates['courier']);
        }
        if (isset($updates['permissions'])) {
            $featureAccess->assertActionAllowed('updatePermissionsSettings', []);
        }
        $walletPayload = $updates['wallet'] ?? (isset($updates['payroll']) ? [
            'unitAmount' => $updates['payroll']['unitAmount'] ?? null,
            'countedStatuses' => $updates['payroll']['countedStatuses'] ?? null,
        ] : null);

        Http::ok([
            'company' => isset($updates['company']) ? $master->updateCompanySettings($updates['company']) : $master->fetchCompanySettings(),
            'order' => isset($updates['order']) ? $master->updateOrderSettings($updates['order']) : $master->fetchOrderSettings(),
            'invoice' => isset($updates['invoice']) ? $master->updateInvoiceSettings($updates['invoice']) : $master->fetchInvoiceSettings(),
            'defaults' => isset($updates['defaults']) ? $master->updateSystemDefaults($updates['defaults']) : $master->fetchSystemDefaults(),
            'courier' => isset($updates['courier']) ? $master->updateCourierSettings($updates['courier']) : $master->fetchCourierSettings(),
            'permissions' => isset($updates['permissions']) ? $master->updatePermissionsSettings($updates['permissions']) : $master->fetchPermissionsSettings(),
            'wallet' => $walletPayload !== null ? $operations->updateWalletSettings($walletPayload) : $operations->fetchWalletSettings(),
        ]);
        exit;
    }

    $services = [$master, $operations, $courier, $dataManagement, $metaAds, $businessGrowth, $autoCall, $sms, $whatsapp, $messenger, $woocommerce, $shopify, $recurringTransactions, $lead];
    foreach ($services as $service) {
        if (!method_exists($service, $action)) {
            continue;
        }

        $result = $service->{$action}($payload);
        if ($action === 'createOrder' && is_array($result)) {
            $postCreateEffects->schedule($result);
        }
        Http::ok($result);
        exit;
    }

    Http::error(404, 'Unknown action.');
} catch (\App\ApiException $exception) {
    Http::error(
        $exception->httpStatus(),
        Http::safeErrorMessage($exception->getMessage()),
        array_merge(['code' => $exception->errorCode()], $exception->extra())
    );
} catch (Throwable $exception) {
    Http::unexpectedError($exception);
}
