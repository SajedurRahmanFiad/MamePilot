<?php

declare(strict_types=1);

namespace App;

use RuntimeException;

final class CourierApi extends BaseService
{
    private OperationsApi $operations;

    public function __construct(Database $database, Auth $auth, Config $config, OperationsApi $operations)
    {
        parent::__construct($database, $auth, $config);
        $this->operations = $operations;
    }

    /**
     * @return array<string, mixed>
     */
    private function courierSystemActor(): array
    {
        $actor = $this->database->fetchOne(
            "SELECT id, name, phone, role
             FROM users
             WHERE deleted_at IS NULL AND COALESCE(is_system, 0) = 0 AND role IN ('Admin', 'Developer')
             ORDER BY CASE WHEN role = 'Developer' THEN 0 ELSE 1 END, created_at ASC
             LIMIT 1"
        );

        if ($actor === null) {
            throw new RuntimeException('No admin-access user is available for courier sync.');
        }

        return $actor;
    }

    /**
     * @param array<string, mixed> $params
     * @return array<string, mixed>|null
     */
    private function updateOrderAsCourierSystem(array $params): ?array
    {
        $actor = $this->courierSystemActor();
        $token = $this->auth->issueToken($actor);
        $previousAuthorization = $_SERVER['HTTP_AUTHORIZATION'] ?? null;
        $previousAuthorizationAlt = $_SERVER['Authorization'] ?? null;
        $headerValue = 'Bearer ' . $token;

        $_SERVER['HTTP_AUTHORIZATION'] = $headerValue;
        $_SERVER['Authorization'] = $headerValue;

        try {
            return $this->operations->updateOrder($params);
        } finally {
            if ($previousAuthorization !== null) {
                $_SERVER['HTTP_AUTHORIZATION'] = $previousAuthorization;
            } else {
                unset($_SERVER['HTTP_AUTHORIZATION']);
            }

            if ($previousAuthorizationAlt !== null) {
                $_SERVER['Authorization'] = $previousAuthorizationAlt;
            } else {
                unset($_SERVER['Authorization']);
            }
        }
    }

    /**
     * @return array{status:int, body:string, json:mixed}
     */
    private function request(string $method, string $url, array $headers = [], array|string|null $jsonBody = null, int $timeoutSeconds = 30): array
    {
        $timeoutSeconds = max(3, min(30, $timeoutSeconds));
        $body = is_array($jsonBody) ? json_encode($jsonBody, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $jsonBody;

        if (function_exists('curl_init')) {
            $handle = curl_init($url);
            if ($handle === false) {
                throw new RuntimeException('Failed to initialize HTTP request.');
            }

            $headerList = [];
            foreach ($headers as $name => $value) {
                $headerList[] = $name . ': ' . $value;
            }
            if (is_array($jsonBody)) {
                $headerList[] = 'Content-Type: application/json';
            } elseif (is_string($jsonBody)) {
                $headerList[] = 'Content-Type: application/x-www-form-urlencoded';
            }

            curl_setopt_array($handle, [
                CURLOPT_CUSTOMREQUEST => strtoupper($method),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => $headerList,
                CURLOPT_TIMEOUT => $timeoutSeconds,
                CURLOPT_CONNECTTIMEOUT => min(10, $timeoutSeconds),
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ]);

            if ($body !== null) {
                curl_setopt($handle, CURLOPT_POSTFIELDS, $body);
            }

            $responseBody = curl_exec($handle);
            if ($responseBody === false) {
                $message = curl_error($handle) ?: 'Unknown cURL error';
                curl_close($handle);
                throw new RuntimeException($message);
            }

            $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
            curl_close($handle);
        } else {
            $headerList = [];
            foreach ($headers as $name => $value) {
                $headerList[] = $name . ': ' . $value;
            }
            if (is_array($jsonBody)) {
                $headerList[] = 'Content-Type: application/json';
            } elseif (is_string($jsonBody)) {
                $headerList[] = 'Content-Type: application/x-www-form-urlencoded';
            }

            $context = stream_context_create([
                'http' => [
                    'method' => strtoupper($method),
                    'header' => implode("\r\n", $headerList),
                    'content' => $body ?? '',
                    'timeout' => $timeoutSeconds,
                    'ignore_errors' => true,
                ],
            ]);

            $responseBody = file_get_contents($url, false, $context);
            if ($responseBody === false) {
                throw new RuntimeException('HTTP request failed.');
            }

            $status = 200;
            foreach (($http_response_header ?? []) as $headerLine) {
                if (preg_match('/^HTTP\/\S+\s+(\d{3})/', $headerLine, $matches) === 1) {
                    $status = (int) $matches[1];
                    break;
                }
            }
        }

        $decoded = json_decode($responseBody, true);
        return [
            'status' => $status,
            'body' => $responseBody,
            'json' => $decoded,
        ];
    }

    private function carryBeeHeaders(array $params): array
    {
        return [
            'Client-ID' => trim((string) ($params['clientId'] ?? '')),
            'Client-Secret' => trim((string) ($params['clientSecret'] ?? '')),
            'Client-Context' => trim((string) ($params['clientContext'] ?? '')),
        ];
    }

    /** @param array<string, mixed> $entry */
    private function appendCourierPollingApiLog(array $entry): void
    {
        try {
            $directory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'logs';
            if (!is_dir($directory) && !@mkdir($directory, 0700, true) && !is_dir($directory)) {
                throw new RuntimeException('Could not create courier polling log directory.');
            }
            @chmod($directory, 0700);

            $line = json_encode(
                $entry,
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
            );
            if (!is_string($line)) {
                throw new RuntimeException('Could not encode courier polling API response.');
            }

            $path = $directory . DIRECTORY_SEPARATOR . 'courier-polling-api.jsonl';
            if (file_put_contents($path, $line . PHP_EOL, FILE_APPEND | LOCK_EX) === false) {
                throw new RuntimeException('Could not write courier polling API log.');
            }
            @chmod($path, 0600);
        } catch (\Throwable $exception) {
            error_log('Courier polling API response log failed: ' . $exception->getMessage());
        }
    }

    /** @param array<string, string> $headers */
    private function courierPollingRequest(
        array $params,
        string $provider,
        string $reference,
        string $method,
        string $url,
        array $headers,
        array|string|null $jsonBody = null,
        int $timeoutSeconds = 30
    ): array {
        if (empty($params['logPollingResponse'])) {
            return $this->request($method, $url, $headers, $jsonBody, $timeoutSeconds);
        }

        $entry = [
            'timestamp' => gmdate('c'),
            'provider' => $provider,
            'reference' => $reference,
            'method' => strtoupper($method),
            'url' => $url,
        ];
        try {
            $response = $this->request($method, $url, $headers, $jsonBody, $timeoutSeconds);
            $entry['httpStatus'] = $response['status'] ?? null;
            $entry['response'] = $response;
            $this->appendCourierPollingApiLog($entry);
            return $response;
        } catch (\Throwable $exception) {
            $entry['exception'] = get_class($exception);
            $entry['error'] = $exception->getMessage();
            $this->appendCourierPollingApiLog($entry);
            throw $exception;
        }
    }

    private function trimBaseUrl(array $params, string $field = 'baseUrl'): string
    {
        return rtrim(trim((string) ($params[$field] ?? '')), '/');
    }

    private function requestTimeout(array $params): int
    {
        return max(3, min(30, (int) ($params['timeoutSeconds'] ?? 30)));
    }

    private function normalizeBanglaDigits(string $value): string
    {
        return strtr($value, [
            '০' => '0',
            '১' => '1',
            '২' => '2',
            '৩' => '3',
            '৪' => '4',
            '৫' => '5',
            '৬' => '6',
            '৭' => '7',
            '৮' => '8',
            '৯' => '9',
        ]);
    }

    private function normalizeFraudCheckerPhone(string $value): string
    {
        $normalized = $this->normalizeBanglaDigits(trim($value));
        return preg_replace('/[^0-9]/', '', $normalized) ?? '';
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function mapFraudCheckResponse(array $payload, string $phone): array
    {
        $data = is_array($payload['data'] ?? null) ? $payload['data'] : [];
        $couriers = [];

        foreach ($data as $key => $value) {
            if ($key === 'summary' || !is_array($value)) {
                continue;
            }

            $couriers[] = [
                'key' => (string) $key,
                'name' => (string) ($value['name'] ?? $key),
                'logo' => (string) ($value['logo'] ?? ''),
                'totalParcel' => (int) ($value['total_parcel'] ?? 0),
                'successParcel' => (int) ($value['success_parcel'] ?? 0),
                'cancelledParcel' => (int) ($value['cancelled_parcel'] ?? 0),
                'successRatio' => round((float) ($value['success_ratio'] ?? 0), 2),
            ];
        }

        usort($couriers, static function (array $left, array $right): int {
            return ($right['totalParcel'] <=> $left['totalParcel']) ?: strcmp((string) $left['name'], (string) $right['name']);
        });

        $summaryPayload = is_array($data['summary'] ?? null) ? $data['summary'] : [];
        $summary = [
            'totalParcel' => (int) ($summaryPayload['total_parcel'] ?? array_sum(array_map(static fn (array $row): int => (int) ($row['totalParcel'] ?? 0), $couriers))),
            'successParcel' => (int) ($summaryPayload['success_parcel'] ?? array_sum(array_map(static fn (array $row): int => (int) ($row['successParcel'] ?? 0), $couriers))),
            'cancelledParcel' => (int) ($summaryPayload['cancelled_parcel'] ?? array_sum(array_map(static fn (array $row): int => (int) ($row['cancelledParcel'] ?? 0), $couriers))),
            'successRatio' => round((float) ($summaryPayload['success_ratio'] ?? 0), 2),
        ];

        if ($summary['totalParcel'] > 0) {
            $summary['successRatio'] = round(($summary['successParcel'] / $summary['totalParcel']) * 100, 2);
        }

        $reports = [];
        foreach ((is_array($payload['reports'] ?? null) ? $payload['reports'] : []) as $report) {
            if (!is_array($report)) {
                continue;
            }

            $reports[] = [
                'id' => (string) ($report['id'] ?? ''),
                'name' => (string) ($report['name'] ?? ''),
                'details' => (string) ($report['details'] ?? ''),
                'createdAt' => $this->toIso($report['created_at'] ?? null) ?? (string) ($report['created_at'] ?? ''),
                'courierLogo' => (string) ($report['courierLogo'] ?? ''),
                'courierName' => (string) ($report['courierName'] ?? ''),
            ];
        }

        usort($reports, static function (array $left, array $right): int {
            return strcmp((string) ($right['createdAt'] ?? ''), (string) ($left['createdAt'] ?? ''));
        });

        return [
            'status' => (string) ($payload['status'] ?? 'success'),
            'phone' => $phone,
            'couriers' => $couriers,
            'summary' => $summary,
            'reports' => $reports,
        ];
    }

    /**
     * @return array<int, array{id:string, name:string}>
     */
    private function carryBeeCollectionResponse(array $response, string $collectionKey): array
    {
        if ($response['status'] < 200 || $response['status'] >= 300) {
            return [];
        }

        $payload = $response['json'];
        $collection = [];
        if (is_array($payload['data'][$collectionKey] ?? null)) {
            $collection = $payload['data'][$collectionKey];
        } elseif (is_array($payload[$collectionKey] ?? null)) {
            $collection = $payload[$collectionKey];
        } elseif (is_array($payload)) {
            $collection = $payload;
        }

        $mapped = [];
        foreach ($collection as $row) {
            if (!is_array($row)) {
                continue;
            }
            $mapped[] = [
                'id' => (string) ($row['id'] ?? ''),
                'name' => (string) ($row['name'] ?? ''),
            ];
        }

        return $mapped;
    }

    public function fetchCarryBeeStores(array $params): array
    {
        if ($this->trimBaseUrl($params) === '' || trim((string) ($params['clientId'] ?? '')) === '' || trim((string) ($params['clientSecret'] ?? '')) === '' || trim((string) ($params['clientContext'] ?? '')) === '') {
            return [];
        }

        $response = $this->request(
            'GET',
            $this->trimBaseUrl($params) . '/api/v2/stores',
            $this->carryBeeHeaders($params)
        );

        return $this->carryBeeCollectionResponse($response, 'stores');
    }

    public function checkFraudCourierHistory(array $params): array
    {
        $user = $this->currentUser();
        if (!$this->roleHasPermission((string) ($user['role'] ?? ''), 'fraudChecker.check')) {
            throw new RuntimeException('You do not have permission to use the Fraud Checker.');
        }

        if (!$this->columnExists('courier_settings', 'fraud_checker_api_key')) {
            throw new RuntimeException('Fraud Checker settings are missing. Run the fraud checker migration first.');
        }

        $phone = $this->normalizeFraudCheckerPhone((string) ($params['phone'] ?? ''));
        if (preg_match('/^0\d{10}$/', $phone) !== 1) {
            throw new RuntimeException('Enter a valid 11-digit phone number starting with 0.');
        }

        $result = $this->performFraudCheck($phone);
        $this->persistCustomerFraudSnapshot(
            trim((string) ($params['customerId'] ?? '')),
            $phone,
            $result
        );

        return $result;
    }

    /**
     * CLI-only entry point used by the post-order background worker.
     */
    public function processCustomerFraudCheck(array $params): array
    {
        if (PHP_SAPI !== 'cli') {
            throw new RuntimeException('Background fraud checks are available only from CLI.');
        }

        return $this->processFraudCheckForCustomer((string) ($params['customerId'] ?? ''));
    }

    /**
     * Runs the post-order fraud check without requiring a web session.
     */
    public function processFraudCheckForCustomer(string $customerId): array
    {
        $customerId = trim($customerId);
        if ($customerId === '') {
            throw new RuntimeException('Customer ID is required.');
        }

        $customer = $this->database->fetchOne(
            'SELECT id, phone FROM customers WHERE id = :id AND deleted_at IS NULL LIMIT 1',
            [':id' => $customerId]
        );
        if ($customer === null) {
            throw new RuntimeException('Customer not found.');
        }

        $phone = $this->normalizeFraudCheckerPhone((string) ($customer['phone'] ?? ''));
        if (preg_match('/^0\d{10}$/', $phone) !== 1) {
            throw new RuntimeException('Customer phone is not valid for a fraud check.');
        }

        $result = $this->performFraudCheck($phone);
        $this->persistCustomerFraudSnapshot($customerId, $phone, $result);
        return $result;
    }

    public function connectFraudspySteadfast(array $params = []): array
    {
        $user = $this->currentUser();
        if (!hasAdminAccess($user['role'] ?? null)) {
            throw new RuntimeException('Developer or Admin permission required.');
        }

        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1') ?? [];
        $fraudspyApiKey = trim((string) ($settings['fraudspy_api_key'] ?? $settings['fraud_checker_api_key'] ?? ''));
        if ($fraudspyApiKey === '') {
            throw new RuntimeException('FraudSpy API key is not configured in Developer Settings.');
        }

        $steadfastApiKey = trim((string) ($settings['steadfast_api_key'] ?? ''));
        $steadfastSecretKey = trim((string) ($settings['steadfast_secret_key'] ?? ''));
        if ($steadfastApiKey === '' || $steadfastSecretKey === '') {
            throw new RuntimeException('Steadfast API key and Secret key must be configured in Courier Settings.');
        }

        $origin = $this->getAppOrigin();
        $response = $this->request(
            'POST',
            'https://fraudspy.com.bd/api/v1/steadfast/connect',
            [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Origin' => $origin,
                'Authorization' => 'Bearer ' . $fraudspyApiKey,
            ],
            [
                'api_key' => $steadfastApiKey,
                'secret_key' => $steadfastSecretKey,
            ]
        );

        $payload = is_array($response['json']) ? $response['json'] : [];
        if ($response['status'] < 200 || $response['status'] >= 300) {
            $errorMsg = (string) ($payload['message'] ?? $payload['error'] ?? '');
            if ($errorMsg === '') {
                $errorMsg = match ($response['status']) {
                    401 => 'Invalid, expired, or missing FraudSpy API key.',
                    403 => 'No active FraudSpy subscription or subscription expired.',
                    422 => 'Invalid API key or Secret key for Steadfast.',
                    429 => 'FraudSpy daily limit exceeded.',
                    default => 'Steadfast connection failed with HTTP ' . $response['status'] . '.',
                };
            }
            throw new RuntimeException($errorMsg);
        }

        return [
            'ok' => (bool) ($payload['ok'] ?? true),
            'message' => (string) ($payload['message'] ?? 'Steadfast API credentials connected successfully.'),
            'credential' => $payload['credential'] ?? null,
        ];
    }

    private function getAppOrigin(): string
    {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? ''));
        if ($host !== '') {
            return $scheme . '://' . $host;
        }

        $configuredOrigin = trim((string) (Config::load(dirname(__DIR__, 2))->get('APP_FRONTEND_URL', '') ?? ''));
        if ($configuredOrigin !== '') {
            return rtrim($configuredOrigin, '/');
        }

        return 'http://localhost';
    }

    private function performFraudCheck(string $phone): array
    {
        $hasProviderCol = $this->columnExists('courier_settings', 'fraud_checker_provider');
        $hasFraudspyCol = $this->columnExists('courier_settings', 'fraudspy_api_key');

        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1') ?? [];
        $provider = $hasProviderCol ? trim((string) ($settings['fraud_checker_provider'] ?? 'bdcourier')) : 'bdcourier';

        if ($provider === 'fraudspy') {
            $apiKey = $hasFraudspyCol ? trim((string) ($settings['fraudspy_api_key'] ?? '')) : '';
            if ($apiKey === '') {
                $apiKey = trim((string) ($settings['fraud_checker_api_key'] ?? ''));
            }
            if ($apiKey === '') {
                throw new RuntimeException('FraudSpy API key is not configured in Developer Settings.');
            }

            $response = $this->request(
                'POST',
                'https://fraudspy.com.bd/api/v1/search',
                [
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                    'Origin' => $this->getAppOrigin(),
                    'Authorization' => 'Bearer ' . $apiKey,
                ],
                ['phone' => $phone]
            );

            $payload = is_array($response['json']) ? $response['json'] : [];
            if ($response['status'] < 200 || $response['status'] >= 300) {
                $errorMsg = (string) ($payload['message'] ?? $payload['error'] ?? '');
                if ($errorMsg === '') {
                    $errorMsg = match ($response['status']) {
                        401 => 'Invalid, expired, or missing FraudSpy API key.',
                        422 => 'Invalid phone number format.',
                        403 => 'No active FraudSpy subscription or subscription expired.',
                        429 => 'FraudSpy daily limit exceeded.',
                        default => 'FraudSpy request failed with HTTP ' . $response['status'] . '.',
                    };
                }
                throw new RuntimeException($errorMsg);
            }

            return $this->mapFraudSpyResponse($payload, $phone);
        }

        // Default: BDCourier
        $apiKey = trim((string) ($settings['fraud_checker_api_key'] ?? ''));
        if ($apiKey === '') {
            throw new RuntimeException('Fraud Checker API key is not configured in Settings.');
        }

        $response = $this->request(
            'POST',
            'https://api.bdcourier.com/courier-check',
            [
                'Authorization' => 'Bearer ' . $apiKey,
                'Accept' => 'application/json',
            ],
            ['phone' => $phone]
        );

        $payload = is_array($response['json']) ? $response['json'] : [];
        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new RuntimeException((string) ($payload['message'] ?? $payload['error'] ?? ('Fraud Checker request failed with HTTP ' . $response['status'] . '.')));
        }
        if (($payload['status'] ?? 'success') !== 'success' && !is_array($payload['data'] ?? null)) {
            throw new RuntimeException((string) ($payload['message'] ?? $payload['error'] ?? 'Fraud Checker request failed.'));
        }

        return $this->mapFraudCheckResponse($payload, $phone);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function mapFraudSpyResponse(array $payload, string $phone): array
    {
        $rawCouriers = is_array($payload['couriers'] ?? null) ? $payload['couriers'] : [];
        $couriers = [];

        foreach ($rawCouriers as $key => $value) {
            if (!is_array($value)) {
                continue;
            }

            $total = (int) ($value['total'] ?? 0);
            $successful = (int) ($value['successful'] ?? 0);
            $returned = (int) ($value['returned'] ?? 0);
            $ratio = $total > 0 ? round(($successful / $total) * 100, 2) : 0;

            $couriers[] = [
                'key' => (string) $key,
                'name' => ucfirst((string) $key),
                'logo' => '',
                'totalParcel' => $total,
                'successParcel' => $successful,
                'cancelledParcel' => $returned,
                'successRatio' => $ratio,
            ];
        }

        usort($couriers, static function (array $left, array $right): int {
            return ($right['totalParcel'] <=> $left['totalParcel']) ?: strcmp((string) $left['name'], (string) $right['name']);
        });

        $overall = is_array($payload['overall'] ?? null) ? $payload['overall'] : [];
        $totalParcel = (int) ($overall['total'] ?? array_sum(array_column($couriers, 'totalParcel')));
        $successParcel = (int) ($overall['delivered'] ?? array_sum(array_column($couriers, 'successParcel')));
        $cancelledParcel = (int) ($overall['returned'] ?? array_sum(array_column($couriers, 'cancelledParcel')));
        $successRatio = isset($overall['success_ratio'])
            ? round((float) $overall['success_ratio'], 2)
            : ($totalParcel > 0 ? round(($successParcel / $totalParcel) * 100, 2) : 0);

        $summary = [
            'totalParcel' => $totalParcel,
            'successParcel' => $successParcel,
            'cancelledParcel' => $cancelledParcel,
            'successRatio' => $successRatio,
        ];

        $reports = [];
        $fraudReportsData = is_array($payload['fraud_reports']['reports'] ?? null) ? $payload['fraud_reports']['reports'] : [];
        foreach ($fraudReportsData as $report) {
            if (!is_array($report)) {
                continue;
            }

            $details = (string) ($report['complain'] ?? '');
            if (!empty($report['categories']) && is_array($report['categories'])) {
                $details .= ' [' . implode(', ', $report['categories']) . ']';
            }

            $reports[] = [
                'id' => (string) ($report['id'] ?? ''),
                'name' => (string) ($report['contact_name'] ?? ''),
                'details' => $details,
                'createdAt' => $this->toIso($report['reported_at'] ?? null) ?? (string) ($report['reported_at'] ?? ''),
                'courierLogo' => '',
                'courierName' => (string) ($report['courier'] ?? ''),
            ];
        }

        usort($reports, static function (array $left, array $right): int {
            return strcmp((string) ($right['createdAt'] ?? ''), (string) ($left['createdAt'] ?? ''));
        });

        return [
            'status' => 'success',
            'phone' => $phone,
            'couriers' => $couriers,
            'summary' => $summary,
            'reports' => $reports,
            'provider' => 'fraudspy',
        ];
    }

    private function persistCustomerFraudSnapshot(string $customerId, string $phone, array $result): void
    {
        foreach (['fraud_check_result', 'fraud_check_percentage', 'fraud_check_phone', 'fraud_checked_at'] as $column) {
            if ($this->columnExists('customers', $column)) {
                continue;
            }
            throw new RuntimeException('Customer fraud snapshot columns are missing. Run schema-only.sql first.');
        }

        $customer = null;
        if ($customerId !== '') {
            $customer = $this->database->fetchOne(
                'SELECT id FROM customers WHERE id = :id AND deleted_at IS NULL LIMIT 1',
                [':id' => $customerId]
            );
        }
        if ($customer === null) {
            $customer = $this->database->fetchOne(
                'SELECT id FROM customers WHERE phone = :phone AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1',
                [':phone' => $phone]
            );
        }
        if ($customer === null) {
            return;
        }

        $percentage = max(0, min(100, (float) ($result['summary']['successRatio'] ?? 0)));
        $this->touchUpdate('customers', (string) $customer['id'], [
            'fraud_check_result' => $this->jsonEncode($result),
            'fraud_check_percentage' => $percentage,
            'fraud_check_phone' => $phone,
            'fraud_checked_at' => $this->database->nowUtc(),
        ]);
    }

    public function fetchCarryBeeCities(array $params): array
    {
        if ($this->trimBaseUrl($params) === '' || trim((string) ($params['clientId'] ?? '')) === '' || trim((string) ($params['clientSecret'] ?? '')) === '' || trim((string) ($params['clientContext'] ?? '')) === '') {
            return [];
        }

        $response = $this->request(
            'GET',
            $this->trimBaseUrl($params) . '/api/v2/cities',
            $this->carryBeeHeaders($params)
        );

        return $this->carryBeeCollectionResponse($response, 'cities');
    }

    public function fetchCarryBeeAddressDetails(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $query = trim((string) ($params['query'] ?? ''));
        $queryLength = function_exists('mb_strlen')
            ? mb_strlen($query, 'UTF-8')
            : (preg_match_all('/./us', $query) ?: strlen($query));
        if (
            $baseUrl === '' ||
            trim((string) ($params['clientId'] ?? '')) === '' ||
            trim((string) ($params['clientSecret'] ?? '')) === '' ||
            trim((string) ($params['clientContext'] ?? '')) === ''
        ) {
            return ['error' => 'Missing CarryBee settings'];
        }
        if ($queryLength < 10) {
            return ['error' => 'Address query must be at least 10 characters'];
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/api/v2/address-details',
            $this->carryBeeHeaders($params),
            ['query' => $query]
        );
        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'CarryBee address lookup failed with HTTP ' . $response['status']];
        }

        $payload = is_array($response['json']) ? $response['json'] : [];
        $data = is_array($payload['data'] ?? null) ? $payload['data'] : [];
        if (!empty($payload['error'])) {
            return ['error' => (string) ($payload['message'] ?? 'CarryBee address lookup failed')];
        }

        return [
            'cityId' => isset($data['city_id']) ? (string) $data['city_id'] : null,
            'zoneId' => isset($data['zone_id']) ? (string) $data['zone_id'] : null,
        ];
    }

    public function fetchCarryBeeZones(array $params): array
    {
        $cityId = trim((string) ($params['cityId'] ?? ''));
        if ($this->trimBaseUrl($params) === '' || $cityId === '') {
            return [];
        }

        $response = $this->request(
            'GET',
            $this->trimBaseUrl($params) . '/api/v2/cities/' . rawurlencode($cityId) . '/zones',
            $this->carryBeeHeaders($params)
        );

        return $this->carryBeeCollectionResponse($response, 'zones');
    }

    public function fetchCarryBeeAreas(array $params): array
    {
        $cityId = trim((string) ($params['cityId'] ?? ''));
        $zoneId = trim((string) ($params['zoneId'] ?? ''));
        if ($this->trimBaseUrl($params) === '' || $cityId === '' || $zoneId === '') {
            return [];
        }

        $response = $this->request(
            'GET',
            $this->trimBaseUrl($params) . '/api/v2/cities/' . rawurlencode($cityId) . '/zones/' . rawurlencode($zoneId) . '/areas',
            $this->carryBeeHeaders($params)
        );

        return $this->carryBeeCollectionResponse($response, 'areas');
    }

    public function submitCarryBeeOrder(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        if (
            $baseUrl === '' ||
            trim((string) ($params['clientId'] ?? '')) === '' ||
            trim((string) ($params['clientSecret'] ?? '')) === '' ||
            trim((string) ($params['clientContext'] ?? '')) === '' ||
            trim((string) ($params['storeId'] ?? '')) === '' ||
            trim((string) ($params['recipientPhone'] ?? '')) === '' ||
            trim((string) ($params['recipientName'] ?? '')) === '' ||
            trim((string) ($params['recipientAddress'] ?? '')) === '' ||
            trim((string) ($params['cityId'] ?? '')) === '' ||
            trim((string) ($params['zoneId'] ?? '')) === ''
        ) {
            return ['error' => 'Missing required parameters'];
        }

        $payload = [
            'store_id' => trim((string) ($params['storeId'] ?? '')),
            'delivery_type' => (int) ($params['deliveryType'] ?? 0),
            'product_type' => (int) ($params['productType'] ?? 0),
            'recipient_phone' => trim((string) ($params['recipientPhone'] ?? '')),
            'recipient_name' => trim((string) ($params['recipientName'] ?? '')),
            'recipient_address' => trim((string) ($params['recipientAddress'] ?? '')),
            'city_id' => trim((string) ($params['cityId'] ?? '')),
            'zone_id' => trim((string) ($params['zoneId'] ?? '')),
            'item_weight' => (float) ($params['itemWeight'] ?? 0),
            'collectable_amount' => (float) ($params['collectableAmount'] ?? 0),
        ];
        $merchantOrderId = trim((string) ($params['merchantOrderId'] ?? ''));
        if ($merchantOrderId !== '') {
            $payload['merchant_order_id'] = $merchantOrderId;
        }
        if (!empty($params['areaId'])) {
            $payload['area_id'] = trim((string) $params['areaId']);
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/api/v2/orders',
            $this->carryBeeHeaders($params),
            $payload
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status']];
        }

        $payload = is_array($response['json']) ? $response['json'] : [];
        if (!empty($payload['error'])) {
            return ['error' => (string) $payload['error']];
        }

        return $payload;
    }

    /**
     * Create an exchange consignment under an existing CarryBee order.
     * POST /api/v2/orders/{consignment_id}/exchange
     */
    public function submitCarryBeeExchangeOrder(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $consignmentId = trim((string) ($params['consignmentId'] ?? ''));
        if (
            $baseUrl === '' ||
            trim((string) ($params['clientId'] ?? '')) === '' ||
            trim((string) ($params['clientSecret'] ?? '')) === '' ||
            trim((string) ($params['clientContext'] ?? '')) === '' ||
            $consignmentId === ''
        ) {
            return ['error' => 'Missing required parameters'];
        }

        $payload = [];
        if (isset($params['collectableAmount']) && (int) $params['collectableAmount'] > 0) {
            $payload['collectable_amount'] = (int) $params['collectableAmount'];
        }
        if (isset($params['itemQuantity']) && (int) $params['itemQuantity'] > 0) {
            $payload['item_quantity'] = (int) $params['itemQuantity'];
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/api/v2/orders/' . rawurlencode($consignmentId) . '/exchange',
            $this->carryBeeHeaders($params),
            $payload
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status']];
        }

        $result = is_array($response['json']) ? $response['json'] : [];
        if (!empty($result['error'])) {
            return ['error' => (string) $result['error']];
        }

        return $result;
    }

    public function fetchCarryBeeOrderDetails(array $params): array
    {
        $consignmentId = trim((string) ($params['consignmentId'] ?? ''));
        if ($this->trimBaseUrl($params) === '' || $consignmentId === '') {
            return ['error' => 'Missing required parameters'];
        }

        $response = $this->courierPollingRequest(
            $params,
            'carrybee',
            $consignmentId,
            'GET',
            $this->trimBaseUrl($params) . '/api/v2/orders/' . rawurlencode($consignmentId) . '/details',
            $this->carryBeeHeaders($params),
            null,
            $this->requestTimeout($params)
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status']];
        }

        return ['data' => $response['json']];
    }

    private function classifyCarryBeeStatus(array $payload): array
    {
        $rawStatus = '';
        foreach ([
            $payload['data']['data']['transfer_status'] ?? null,
            $payload['data']['transfer_status'] ?? null,
            $payload['transfer_status'] ?? null,
        ] as $candidate) {
            if ($candidate !== null && trim((string) $candidate) !== '') {
                $rawStatus = trim((string) $candidate);
                break;
            }
        }

        $normalized = strtolower($rawStatus);
        $isPickedOrBeyond = false;
        $mappedStatus = null;

        if ($normalized !== '') {
            if (strpos($normalized, 'delivered') !== false) {
                $mappedStatus = 'Delivered';
            } elseif (strpos($normalized, 'return') !== false || strpos($normalized, 'paid return') !== false) {
                $mappedStatus = 'Returned';
            } elseif (strpos($normalized, 'cancel') !== false) {
                $mappedStatus = 'Cancelled';
            }

            $pickedOrBeyond = [
                'at the sorting hub',
                'at central warehouse',
                'at the destination hub',
                'assigned for delivery',
                'out for delivery',
                'in transit',
                'on the way to central warehouse',
                'on the way to last mile hub',
                'received at last mile hub',
                'delivered',
                'exchange',
                'partial delivery',
                'return',
                'paid return',
            ];
            $isPickedOrBeyond = in_array($normalized, $pickedOrBeyond, true) || $mappedStatus !== null;

            if ($mappedStatus === null && $isPickedOrBeyond) {
                $mappedStatus = 'Picked';
            }
        }

        return [
            'rawStatus' => $rawStatus,
            'normalizedStatus' => $normalized,
            'status' => $mappedStatus,
            'isPickedOrBeyond' => $isPickedOrBeyond,
        ];
    }

    public function syncCarryBeeTransferStatuses(array $params = []): array
    {
        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1');
        $baseUrl = rtrim(trim((string) ($settings['carrybee_base_url'] ?? '')), '/');
        $clientId = trim((string) ($settings['carrybee_client_id'] ?? ''));
        $clientSecret = trim((string) ($settings['carrybee_client_secret'] ?? ''));
        $clientContext = trim((string) ($settings['carrybee_client_context'] ?? ''));
        if ($baseUrl === '' || $clientId === '' || $clientSecret === '' || $clientContext === '') {
            return ['checked' => 0, 'updated' => 0, 'hasMore' => false, 'nextCursorCreatedAt' => null, 'statusCounts' => [], 'errors' => [], 'updatedOrders' => []];
        }

        $mode = ($params['mode'] ?? '') === 'backfill' ? 'backfill' : 'incremental';
        $limit = max(1, min(500, (int) ($params['limit'] ?? ($mode === 'backfill' ? 100 : 250))));
        $offset = max(0, min(1000000, (int) ($params['offset'] ?? 0)));
        $sql = "SELECT id, order_number, status, history, items, carrybee_consignment_id, created_at
                FROM orders
                WHERE deleted_at IS NULL
                  AND carrybee_consignment_id IS NOT NULL
                  AND carrybee_consignment_id <> ''
                  AND status IN ('On Hold', 'Processing', 'Courier assigned', 'Picked')";
        $bindings = [];
        if (!empty($params['orderId'])) {
            $sql .= ' AND id = :id';
            $bindings[':id'] = trim((string) $params['orderId']);
        } elseif ($mode === 'backfill' && !empty($params['cursorCreatedAt'])) {
            $sql .= ' AND created_at > :cursor';
            $bindings[':cursor'] = $this->normalizeDateTimeInput((string) $params['cursorCreatedAt']);
        }
        $sql .= $mode === 'backfill' ? ' ORDER BY created_at ASC' : ' ORDER BY created_at DESC';
        $sql .= ' LIMIT ' . $limit . ' OFFSET ' . $offset;

        $rows = $this->database->fetchAll($sql, $bindings);
        $statusCounts = [];
        $errors = [];
        $updatedOrders = [];
        $updated = 0;

        foreach ($rows as $row) {
            try {
                $details = $this->fetchCarryBeeOrderDetails([
                    'baseUrl' => $baseUrl,
                    'clientId' => $clientId,
                    'clientSecret' => $clientSecret,
                    'clientContext' => $clientContext,
                    'consignmentId' => (string) ($row['carrybee_consignment_id'] ?? ''),
                    'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                    'logPollingResponse' => true,
                ]);
                if (!empty($details['error']) || !is_array($details['data'] ?? null)) {
                    $errors[] = ['orderId' => $row['id'], 'orderNumber' => $row['order_number'], 'error' => $details['error'] ?? 'Unknown error'];
                    continue;
                }

                $statusInfo = $this->classifyCarryBeeStatus($details['data']);
                $statusKey = (string) ($statusInfo['normalizedStatus'] ?? 'unknown');
                $statusCounts[$statusKey] = ($statusCounts[$statusKey] ?? 0) + 1;

                if (empty($statusInfo['rawStatus']) || $statusInfo['status'] === null) {
                    continue;
                }
                if ($statusInfo['status'] === 'Picked' && (string) ($row['status'] ?? '') === 'Picked') continue;

                $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
                $updates = [
                    'history' => $history,
                ];

                if ($statusInfo['status'] === 'Delivered') {
                    $deliveredTarget = $this->resolveDeliveredTargetStatus((string) ($row['status'] ?? ''), gmdate('c'));
                    $updates['status'] = $deliveredTarget['status'];
                    if (($deliveredTarget['pendingDelivered'] ?? false) === true) {
                        $updates['delivery_action_required'] = 1;
                        $updates['partial_delivered_at'] = gmdate('c');
                        $updates['history']['pendingDelivered'] = 'Marked pending delivered automatically from CarryBee transfer status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c') . '. Action required to confirm delivery.';
                    } else {
                        $updates['history']['completed'] = 'Marked delivered automatically from CarryBee transfer status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
                    }
                } elseif ($statusInfo['status'] === 'Returned') {
                    $updates['status'] = 'Returned';
                    $updates['history']['returned'] = 'Marked returned automatically from CarryBee transfer status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
                } elseif ($statusInfo['status'] === 'Cancelled') {
                    $updates['status'] = 'Cancelled';
                    $updates['history']['cancelled'] = 'Marked cancelled automatically from CarryBee transfer status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
                } else {
                    $updates['status'] = 'Picked';
                    $updates['history']['picked'] = $updates['history']['picked'] ?? ('Marked picked automatically from CarryBee transfer status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c'));
                }

                $this->attachSyncedCharge(
                    $updates,
                    'carrybee',
                    is_array($details['data'] ?? null) ? $details['data'] : [],
                    (string) ($row['carrybee_consignment_id'] ?? ''),
                    (string) ($row['order_number'] ?? ''),
                    (string) $row['id']
                );
                $this->updateOrderAsCourierSystem([
                    'id' => (string) $row['id'],
                    'updates' => $updates,
                ]);
                $updated += 1;
                $updatedOrders[] = [
                    'orderId' => $row['id'],
                    'orderNumber' => $row['order_number'],
                    'rawStatus' => $statusInfo['rawStatus'],
                ];
            } catch (\Throwable $exception) {
                $errors[] = [
                    'orderId' => $row['id'],
                    'orderNumber' => $row['order_number'],
                    'error' => $exception->getMessage(),
                ];
            }
        }

        $lastRow = $rows === [] ? null : $rows[count($rows) - 1];
        return [
            'checked' => count($rows),
            'updated' => $updated,
            'hasMore' => empty($params['orderId']) && count($rows) === $limit,
            'nextCursorCreatedAt' => $lastRow['created_at'] ?? null,
            'statusCounts' => $statusCounts,
            'errors' => $errors,
            'updatedOrders' => $updatedOrders,
        ];
    }

    public function submitSteadfastOrder(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $invoice = trim((string) ($params['invoice'] ?? ''));
        if ($baseUrl === '' || trim((string) ($params['apiKey'] ?? '')) === '' || trim((string) ($params['secretKey'] ?? '')) === '' || $invoice === '') {
            return ['error' => 'Missing required parameters', 'definitiveFailure' => true];
        }
        if (strlen($invoice) > 100 || preg_match('/^[A-Za-z0-9_-]+$/', $invoice) !== 1) {
            return ['error' => 'Invoice must be unique and can only contain letters, numbers, hyphens, and underscores', 'definitiveFailure' => true];
        }
        $orderId = trim((string) ($params['orderId'] ?? ''));
        if ($orderId !== '') {
            $duplicate = $this->database->fetchOne(
                'SELECT id FROM orders
                 WHERE steadfast_invoice = :invoice AND deleted_at IS NULL AND id <> :order_id
                 LIMIT 1',
                [':invoice' => $invoice, ':order_id' => $orderId]
            );
            if ($duplicate !== null) {
                return ['error' => 'Invoice must be unique; this value is already used by another order', 'definitiveFailure' => true];
            }
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/create_order',
            [
                'Api-Key' => trim((string) ($params['apiKey'] ?? '')),
                'Secret-Key' => trim((string) ($params['secretKey'] ?? '')),
            ],
            [
                'invoice' => $invoice,
                'recipient_name' => trim((string) ($params['recipientName'] ?? '')),
                'recipient_phone' => trim((string) ($params['recipientPhone'] ?? '')),
                'recipient_address' => trim((string) ($params['recipientAddress'] ?? '')),
                'cod_amount' => (float) ($params['codAmount'] ?? 0),
                'note' => trim((string) ($params['note'] ?? '')),
            ]
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            $detail = $response['json']['message'] ?? $response['json']['error'] ?? $response['body'] ?? '';
            return [
                'error' => 'HTTP ' . $response['status'] . ($detail !== '' ? ': ' . $detail : ''),
                'definitiveFailure' => $response['status'] >= 400 && $response['status'] < 500 && $response['status'] !== 409,
            ];
        }

        return is_array($response['json']) ? $response['json'] : ['error' => 'Invalid response'];
    }

    public function fetchSteadfastStatusByTrackingCode(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $trackingCode = trim((string) ($params['trackingCode'] ?? ''));
        if ($baseUrl === '' || trim((string) ($params['apiKey'] ?? '')) === '' || trim((string) ($params['secretKey'] ?? '')) === '' || $trackingCode === '') {
            return ['error' => 'Missing required parameters'];
        }

        $response = $this->request(
            'GET',
            $baseUrl . '/status_by_trackingcode/' . rawurlencode($trackingCode),
            [
                'Api-Key' => trim((string) ($params['apiKey'] ?? '')),
                'Secret-Key' => trim((string) ($params['secretKey'] ?? '')),
            ],
            null,
            $this->requestTimeout($params)
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            $detail = $response['json']['message'] ?? $response['json']['error'] ?? $response['body'] ?? '';
            return ['error' => 'HTTP ' . $response['status'] . ($detail !== '' ? ': ' . $detail : '')];
        }

        return ['data' => $response['json']];
    }

    public function fetchSteadfastStatusByConsignmentId(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $consignmentId = trim((string) ($params['consignmentId'] ?? ''));
        if ($baseUrl === '' || trim((string) ($params['apiKey'] ?? '')) === '' || trim((string) ($params['secretKey'] ?? '')) === '' || $consignmentId === '') {
            return ['error' => 'Missing required parameters'];
        }

        $response = $this->courierPollingRequest(
            $params,
            'steadfast',
            $consignmentId,
            'GET',
            $baseUrl . '/status_by_cid/' . rawurlencode($consignmentId),
            [
                'Api-Key' => trim((string) ($params['apiKey'] ?? '')),
                'Secret-Key' => trim((string) ($params['secretKey'] ?? '')),
            ],
            null,
            $this->requestTimeout($params)
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            $detail = $response['json']['message'] ?? $response['json']['error'] ?? $response['body'] ?? '';
            return ['error' => 'HTTP ' . $response['status'] . ($detail !== '' ? ': ' . $detail : '')];
        }

        return ['data' => $response['json']];
    }

    public function submitPaperflyOrder(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $username = trim((string) ($params['username'] ?? ''));
        $password = trim((string) ($params['password'] ?? ''));
        $paperflyKey = trim((string) ($params['paperflyKey'] ?? ''));
        if ($baseUrl === '' || $username === '' || $password === '' || $paperflyKey === '') {
            return ['error' => 'Missing required parameters'];
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/merchant/api/service/new_order_v2.php',
            [
                'Authorization' => 'Basic ' . base64_encode($username . ':' . $password),
                'paperflykey' => $paperflyKey,
            ],
            [
                'merchantOrderReference' => trim((string) ($params['merchantOrderReference'] ?? '')),
                'storeName' => trim((string) ($params['storeName'] ?? '')),
                'productBrief' => trim((string) ($params['productBrief'] ?? '')),
                'packagePrice' => (string) ($params['packagePrice'] ?? ''),
                'max_weight' => (string) ($params['maxWeightKg'] ?? ''),
                'customerName' => trim((string) ($params['customerName'] ?? '')),
                'customerAddress' => trim((string) ($params['customerAddress'] ?? '')),
                'customerPhone' => trim((string) ($params['customerPhone'] ?? '')),
            ]
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status']];
        }

        return is_array($response['json']) ? $response['json'] : ['error' => 'Invalid response'];
    }

    /**
     * Create an exchange order via Paperfly.
     * POST /merchant/api/service/new_order_v2.php with orderType=Exchange
     */
    public function submitPaperflyExchangeOrder(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $username = trim((string) ($params['username'] ?? ''));
        $password = trim((string) ($params['password'] ?? ''));
        $paperflyKey = trim((string) ($params['paperflyKey'] ?? ''));
        if ($baseUrl === '' || $username === '' || $password === '' || $paperflyKey === '') {
            return ['error' => 'Missing required parameters'];
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/merchant/api/service/new_order_v2.php',
            [
                'Authorization' => 'Basic ' . base64_encode($username . ':' . $password),
                'paperflykey' => $paperflyKey,
            ],
            [
                'merchantOrderReference' => trim((string) ($params['merchantOrderReference'] ?? '')),
                'storeName' => trim((string) ($params['storeName'] ?? '')),
                'productBrief' => trim((string) ($params['productBrief'] ?? '')),
                'packagePrice' => (string) ($params['packagePrice'] ?? ''),
                'max_weight' => (string) ($params['maxWeightKg'] ?? ''),
                'customerName' => trim((string) ($params['customerName'] ?? '')),
                'customerAddress' => trim((string) ($params['customerAddress'] ?? '')),
                'customerPhone' => trim((string) ($params['customerPhone'] ?? '')),
                'orderType' => 'Exchange',
                'exchangeDescription' => trim((string) ($params['exchangeDescription'] ?? 'Exchange product')),
                'exchangePrice' => (string) ($params['exchangePrice'] ?? '0'),
                'exchangeWeight' => (string) ($params['exchangeWeightKg'] ?? '0.5'),
            ]
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status']];
        }

        return is_array($response['json']) ? $response['json'] : ['error' => 'Invalid response'];
    }

    public function fetchPaperflyOrderTracking(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $username = trim((string) ($params['username'] ?? ''));
        $password = trim((string) ($params['password'] ?? ''));
        $paperflyKey = trim((string) ($params['paperflyKey'] ?? ''));
        $referenceNumber = trim((string) ($params['referenceNumber'] ?? ''));
        if ($baseUrl === '' || $username === '' || $password === '' || $paperflyKey === '' || $referenceNumber === '') {
            return ['error' => 'Missing required parameters'];
        }

        $response = $this->courierPollingRequest(
            $params,
            'paperfly',
            $referenceNumber,
            'POST',
            $baseUrl . '/API-Order-Tracking',
            [
                'Authorization' => 'Basic ' . base64_encode($username . ':' . $password),
                'paperflykey' => $paperflyKey,
            ],
            ['ReferenceNumber' => $referenceNumber],
            $this->requestTimeout($params)
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status']];
        }

        return ['data' => $response['json']];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function extractPaperflyTrackingEntries(array $payload): array
    {
        foreach ([
            $payload['success']['trackingStatus'] ?? null,
            $payload['trackingStatus'] ?? null,
            $payload['data']['trackingStatus'] ?? null,
            $payload['data']['success']['trackingStatus'] ?? null,
        ] as $candidate) {
            if (!is_array($candidate)) {
                continue;
            }

            $entries = array_values(array_filter($candidate, static fn ($entry): bool => is_array($entry)));
            if ($entries !== []) {
                /** @var array<int, array<string, mixed>> $entries */
                return $entries;
            }
        }

        return [];
    }

    private function extractPaperflyTrackingStatusEntry(array $payload): ?array
    {
        $entries = $this->extractPaperflyTrackingEntries($payload);
        return $entries[0] ?? null;
    }

    private function classifyPaperflyTrackingStatus(array $payload): array
    {
        $entries = $this->extractPaperflyTrackingEntries($payload);
        $rawStatus = '';
        $normalizedValues = [];
        $directPickupMarkers = [];

        foreach ($entries as $entry) {
            foreach ($entry as $key => $value) {
                if (!is_scalar($value)) {
                    continue;
                }

                $text = trim((string) $value);
                if ($text === '') {
                    continue;
                }

                $normalizedKey = strtolower(trim((string) $key));
                if (in_array($normalizedKey, ['pick', 'pickup', 'picked'], true)) {
                    $directPickupMarkers[] = $text;
                }

                $normalizedValues[] = strtolower($text);
                if ($rawStatus === '' && in_array($normalizedKey, ['status', 'currentstatus', 'current_status', 'remarks', 'remark', 'pickup', 'pick'], true)) {
                    $rawStatus = $text;
                }
            }
        }

        foreach ($directPickupMarkers as $marker) {
            $normalizedMarker = strtolower($marker);
            if (!in_array($normalizedMarker, ['0', 'false', 'no', 'n/a', 'na', 'null', 'none', 'pending'], true)) {
                $rawStatus = $rawStatus !== '' ? $rawStatus : $marker;
                break;
            }
        }

        if ($rawStatus === '') {
            foreach ($entries as $entry) {
                $parts = [];
                foreach ($entry as $value) {
                    if (!is_scalar($value)) {
                        continue;
                    }

                    $text = trim((string) $value);
                    if ($text !== '') {
                        $parts[] = $text;
                    }
                }

                if ($parts !== []) {
                    $rawStatus = implode(' | ', $parts);
                    break;
                }
            }
        }

        $normalized = strtolower($rawStatus);
        $status = null;

        if (strpos($normalized, 'delivered') !== false) {
            $status = 'Delivered';
        } elseif (strpos($normalized, 'returned') !== false || strpos($normalized, 'return') !== false) {
            $status = 'Returned';
        } elseif (strpos($normalized, 'cancel') !== false) {
            $status = 'Cancelled';
        }

        $hasPositiveSignal = false;
        $positivePatterns = [
            '/\bpicked\b/',
            '/\bpickup\b/',
            '/\bpicked up\b/',
            '/\bcollected\b/',
            '/\bin transit\b/',
            '/\bshipped\b/',
            '/\bdelivered\b/',
            '/\breturned\b/',
            '/\breturn\b/',
            '/\bdispatch(?:ed)?\b/',
            '/\breceived\b/',
        ];
        foreach ($positivePatterns as $pattern) {
            if (preg_match($pattern, $normalized) === 1) {
                $hasPositiveSignal = true;
                break;
            }
        }

        $hasNegativeSignal = false;
        $negativePatterns = [
            '/\bnot picked\b/',
            '/\bnot pickup\b/',
            '/\bpending\b/',
            '/\bbooked\b/',
            '/\border placed\b/',
            '/\bcreated\b/',
        ];
        foreach ($negativePatterns as $pattern) {
            if (preg_match($pattern, $normalized) === 1) {
                $hasNegativeSignal = true;
                break;
            }
        }

        if ($status === null && $hasPositiveSignal && !$hasNegativeSignal) {
            $status = 'Picked';
        }

        return [
            'rawStatus' => $rawStatus,
            'normalizedStatus' => $normalized,
            'status' => $status,
            'isPickedOrBeyond' => $status !== null && $status !== 'Cancelled',
        ];
    }

    private function classifySteadfastDeliveryStatus(array $payload): array
    {
        $rawStatus = '';
        foreach ([
            $payload['data']['delivery_status'] ?? null,
            $payload['delivery_status'] ?? null,
        ] as $candidate) {
            if ($candidate !== null && trim((string) $candidate) !== '') {
                $rawStatus = trim((string) $candidate);
                break;
            }
        }

        $normalized = strtolower($rawStatus);
        $status = null;

        $collectsNothing = false;
        if ($normalized !== '') {
            if ($normalized === 'partial_delivered') {
                $status = 'Partially Delivered';
            } elseif ($normalized === 'delivered') {
                $status = 'Delivered';
            } elseif ($normalized === 'cancelled') {
                $status = 'Returned';
                $collectsNothing = true;
            } elseif ($normalized === 'pending') {
                $status = 'Picked';
            }
        }

        return [
            'rawStatus' => $rawStatus,
            'normalizedStatus' => $normalized,
            'status' => $status,
            'collectsNothing' => $collectsNothing,
            'isPickedOrBeyond' => $status !== null && $status !== 'Returned',
        ];
    }

    public function syncPaperflyOrderStatuses(array $params = []): array
    {
        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1');
        $baseUrl = rtrim(trim((string) ($settings['paperfly_base_url'] ?? '')), '/');
        $username = trim((string) ($settings['paperfly_username'] ?? ''));
        $password = trim((string) ($settings['paperfly_password'] ?? ''));
        $paperflyKey = trim((string) ($settings['paperfly_key'] ?? ''));
        if ($baseUrl === '' || $username === '' || $password === '' || $paperflyKey === '') {
            return ['checked' => 0, 'updated' => 0];
        }
        $limit = max(1, min(1000000, (int) ($params['limit'] ?? 1000000)));
        $offset = max(0, min(1000000, (int) ($params['offset'] ?? 0)));

        $rows = $this->database->fetchAll(
            "SELECT id, order_number, status, history, paperfly_tracking_number
             FROM orders
             WHERE deleted_at IS NULL
               AND paperfly_tracking_number IS NOT NULL
               AND paperfly_tracking_number <> ''
               AND status IN ('On Hold', 'Processing', 'Courier assigned', 'Picked')
               ORDER BY created_at ASC
               LIMIT {$limit} OFFSET {$offset}"
        );

        $checked = 0;
        $updated = 0;
        $failed = 0;
        foreach ($rows as $row) {
            $referenceNumber = trim((string) ($row['paperfly_tracking_number'] ?? ''));
            if ($referenceNumber === '') {
                $referenceNumber = trim((string) ($row['order_number'] ?? ''));
            }

            if ($referenceNumber === '') {
                continue;
            }
            $checked += 1;

            $details = $this->fetchPaperflyOrderTracking([
                'baseUrl' => $baseUrl,
                'username' => $username,
                'password' => $password,
                'paperflyKey' => $paperflyKey,
                'referenceNumber' => $referenceNumber,
                'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                'logPollingResponse' => true,
            ]);

            if (!empty($details['error']) || !is_array($details['data'] ?? null)) {
                $failed += 1;
                continue;
            }

            $statusInfo = $this->classifyPaperflyTrackingStatus($details['data']);
            if (empty($statusInfo['status'])) {
                continue;
            }
            if ($statusInfo['status'] === 'Picked' && (string) ($row['status'] ?? '') === 'Picked') continue;

            $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
            $updates = ['history' => $history];

            if ($statusInfo['status'] === 'Delivered') {
                $deliveredTarget = $this->resolveDeliveredTargetStatus((string) ($row['status'] ?? ''), gmdate('c'));
                $updates['status'] = $deliveredTarget['status'];
                if (($deliveredTarget['pendingDelivered'] ?? false) === true) {
                    $updates['delivery_action_required'] = 1;
                    $updates['partial_delivered_at'] = gmdate('c');
                    $updates['history']['pendingDelivered'] = 'Marked pending delivered automatically from Paperfly tracking status "' . $statusInfo['rawStatus'] . '" using reference "' . $referenceNumber . '" on ' . gmdate('c') . '. Action required to confirm delivery.';
                } else {
                    $updates['history']['completed'] = 'Marked delivered automatically from Paperfly tracking status "' . $statusInfo['rawStatus'] . '" using reference "' . $referenceNumber . '" on ' . gmdate('c');
                }
            } elseif ($statusInfo['status'] === 'Returned') {
                $updates['status'] = 'Returned';
                $updates['history']['returned'] = 'Marked returned automatically from Paperfly tracking status "' . $statusInfo['rawStatus'] . '" using reference "' . $referenceNumber . '" on ' . gmdate('c');
            } elseif ($statusInfo['status'] === 'Cancelled') {
                $updates['status'] = 'Cancelled';
                $updates['history']['cancelled'] = 'Marked cancelled automatically from Paperfly tracking status "' . $statusInfo['rawStatus'] . '" using reference "' . $referenceNumber . '" on ' . gmdate('c');
            } else {
                $updates['status'] = 'Picked';
                $updates['history']['picked'] = 'Marked picked automatically from Paperfly tracking status "' . $statusInfo['rawStatus'] . '" using reference "' . $referenceNumber . '" on ' . gmdate('c');
            }

            $this->attachSyncedCharge(
                $updates,
                'paperfly',
                is_array($details['data'] ?? null) ? $details['data'] : [],
                (string) ($row['paperfly_tracking_number'] ?? ''),
                (string) ($row['order_number'] ?? ''),
                (string) $row['id']
            );
            $this->updateOrderAsCourierSystem([
                'id' => (string) $row['id'],
                'updates' => $updates,
            ]);
            $updated += 1;
        }

        return ['checked' => $checked, 'updated' => $updated, 'failed' => $failed];
    }

    public function syncSteadfastDeliveryStatuses(array $params = []): array
    {
        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1');
        $baseUrl = rtrim(trim((string) ($settings['steadfast_base_url'] ?? '')), '/');
        $apiKey = trim((string) ($settings['steadfast_api_key'] ?? ''));
        $secretKey = trim((string) ($settings['steadfast_secret_key'] ?? ''));
        if ($baseUrl === '' || $apiKey === '' || $secretKey === '') {
            return ['checked' => 0, 'updated' => 0];
        }
        $limit = max(1, min(1000000, (int) ($params['limit'] ?? 1000000)));
        $offset = max(0, min(1000000, (int) ($params['offset'] ?? 0)));

        $rows = $this->database->fetchAll(
            "SELECT id, status, history, steadfast_consignment_id
             FROM orders
             WHERE deleted_at IS NULL
               AND steadfast_consignment_id IS NOT NULL
               AND steadfast_consignment_id <> ''
               AND status IN ('On Hold', 'Processing', 'Courier assigned', 'Picked')
               ORDER BY created_at ASC
               LIMIT {$limit} OFFSET {$offset}"
        );

        $checked = 0;
        $updated = 0;
        $failed = 0;
        foreach ($rows as $row) {
            $consignmentId = trim((string) ($row['steadfast_consignment_id'] ?? ''));
            if ($consignmentId === '') {
                continue;
            }
            $checked += 1;

            $details = $this->fetchSteadfastStatusByConsignmentId([
                'baseUrl' => $baseUrl,
                'apiKey' => $apiKey,
                'secretKey' => $secretKey,
                'consignmentId' => $consignmentId,
                'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                'logPollingResponse' => true,
            ]);
            if (!empty($details['error']) || !is_array($details['data'] ?? null)) {
                $failed += 1;
                continue;
            }

            $statusInfo = $this->classifySteadfastDeliveryStatus($details['data']);
            if (empty($statusInfo['rawStatus']) || empty($statusInfo['status'])) {
                continue;
            }
            if ($statusInfo['status'] === 'Picked' && (string) ($row['status'] ?? '') === 'Picked') continue;

            $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
            $updates = ['history' => $history];

            if ($statusInfo['status'] === 'Partially Delivered') {
                $updates['status'] = 'pending_partial';
                $updates['history']['partiallyDelivered'] = 'Marked partially delivered automatically from Steadfast delivery status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c') . '. Action required to confirm delivered items.';
                $updates['partial_delivery_action_required'] = 1;
                $updates['partial_delivered_at'] = gmdate('c');
                $partialData = is_array($details['data']) ? $details['data'] : [];
                $updates['partial_cod_amount'] = round(max(0, (float) ($partialData['cod_amount'] ?? 0)), 2);
                $updates['partial_shipping_amount'] = round(max(0, (float) ($partialData['delivery_fee'] ?? 0)), 2);
                $orderItems = is_array(json_decode((string) ($row['items'] ?? '[]'), true))
                    ? json_decode((string) ($row['items'] ?? '[]'), true)
                    : [];
                $totalCogs = 0.0;
                foreach ($orderItems as $oi) {
                    if (!is_array($oi)) continue;
                    $qty = max(0, (float) ($oi['quantity'] ?? 0));
                    $pid = trim((string) ($oi['productId'] ?? ''));
                    if ($qty <= 0 || $pid === '') continue;
                    $prod = $this->database->fetchOne('SELECT purchase_price FROM products WHERE id = :id LIMIT 1', [':id' => $pid]);
                    $totalCogs += round(max(0.0, (float) ($prod['purchase_price'] ?? 0)) * $qty, 2);
                }
                $updates['partial_cogs_amount'] = round($totalCogs, 2);
            } elseif ($statusInfo['status'] === 'Delivered') {
                $deliveredTarget = $this->resolveDeliveredTargetStatus((string) ($row['status'] ?? ''), gmdate('c'));
                $updates['status'] = $deliveredTarget['status'];
                if (($deliveredTarget['pendingDelivered'] ?? false) === true) {
                    $updates['delivery_action_required'] = 1;
                    $updates['partial_delivered_at'] = gmdate('c');
                    $updates['history']['pendingDelivered'] = 'Marked pending delivered automatically from Steadfast delivery status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c') . '. Action required to confirm delivery.';
                } else {
                    $updates['history']['completed'] = 'Marked delivered automatically from Steadfast delivery status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
                }
            } elseif ($statusInfo['status'] === 'Returned') {
                $updates['status'] = 'Returned';
                $updates['history']['returned'] = 'Marked returned automatically from Steadfast delivery status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
            } else {
                $updates['status'] = 'Picked';
                $updates['history']['picked'] = $updates['history']['picked'] ?? ('Marked picked automatically from Steadfast delivery status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c'));
            }

            $this->attachSyncedCharge(
                $updates,
                'steadfast',
                is_array($details['data'] ?? null) ? $details['data'] : [],
                (string) ($row['steadfast_consignment_id'] ?? ''),
                (string) ($row['order_number'] ?? ''),
                (string) $row['id'],
                empty($statusInfo['collectsNothing']) ? null : 0.0
            );
            $this->updateOrderAsCourierSystem([
                'id' => (string) $row['id'],
                'updates' => $updates,
            ]);
            $updated += 1;
        }

        return ['checked' => $checked, 'updated' => $updated, 'failed' => $failed];
    }

    /**
     * Sync exchange consignment statuses for all couriers.
     * Multi-step exchange flow: Exchange processing → Exchange picked → Exchange delivered.
     */
    public function syncExchangeConsignmentStatuses(array $params = []): array
    {
        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1');
        $limit = max(1, min(10, (int) ($params['limit'] ?? 5)));
        $offset = max(0, min(1000000, (int) ($params['offset'] ?? 0)));
        $checked = 0;
        $updated = 0;

        // Steadfast exchange consignments
        $steadfastBaseUrl = rtrim(trim((string) ($settings['steadfast_base_url'] ?? '')), '/');
        $steadfastApiKey = trim((string) ($settings['steadfast_api_key'] ?? ''));
        $steadfastSecretKey = trim((string) ($settings['steadfast_secret_key'] ?? ''));
        if ($steadfastBaseUrl !== '' && $steadfastApiKey !== '' && $steadfastSecretKey !== '') {
            $rows = $this->database->fetchAll(
                "SELECT id, status, history, exchange_steadfast_consignment_id
                 FROM orders
                 WHERE deleted_at IS NULL
                   AND exchange_steadfast_consignment_id IS NOT NULL
                   AND exchange_steadfast_consignment_id <> ''
                   AND status IN ('Exchange processing', 'Exchange picked')
                   ORDER BY created_at ASC LIMIT {$limit} OFFSET {$offset}"
            );
            foreach ($rows as $row) {
                $consignmentId = trim((string) ($row['exchange_steadfast_consignment_id'] ?? ''));
                if ($consignmentId === '') continue;
                $checked += 1;

                $details = $this->fetchSteadfastStatusByConsignmentId([
                    'baseUrl' => $steadfastBaseUrl,
                    'apiKey' => $steadfastApiKey,
                    'secretKey' => $steadfastSecretKey,
                    'consignmentId' => $consignmentId,
                    'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                    'logPollingResponse' => true,
                ]);
                if (!empty($details['error']) || !is_array($details['data'] ?? null)) continue;

                $statusInfo = $this->classifySteadfastDeliveryStatus($details['data']);
                if (empty($statusInfo['rawStatus']) || empty($statusInfo['status'])) continue;

                $currentStatus = trim((string) ($row['status'] ?? ''));
                $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
                $updates = ['history' => $history];

                if ($statusInfo['status'] === 'Delivered') {
                    $updates['history']['exchangeDelivered'] = 'Exchange delivered via Steadfast (' . $statusInfo['rawStatus'] . ') on ' . gmdate('c');
                    $updates['status'] = 'Exchange delivered';
                    $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange delivered via Steadfast (' . $statusInfo['rawStatus'] . ') on ' . gmdate('c');
                } elseif ($statusInfo['status'] === 'Returned' || $statusInfo['status'] === 'Cancelled') {
                    $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange returned/cancelled via Steadfast (' . $statusInfo['rawStatus'] . ') on ' . gmdate('c');
                } elseif ($statusInfo['status'] === 'Picked' && $currentStatus === 'Exchange processing') {
                    $updates['status'] = 'Exchange picked';
                    $updates['history']['exchangePicked'] = 'Exchange picked up by Steadfast (' . $statusInfo['rawStatus'] . ') on ' . gmdate('c');
                } else {
                    continue;
                }

                $this->updateOrderAsCourierSystem(['id' => (string) $row['id'], 'updates' => $updates]);
                $updated += 1;
            }
        }

        // CarryBee exchange consignments
        $carrybeeBaseUrl = rtrim(trim((string) ($settings['carrybee_base_url'] ?? '')), '/');
        $carrybeeClientId = trim((string) ($settings['carrybee_client_id'] ?? ''));
        $carrybeeClientSecret = trim((string) ($settings['carrybee_client_secret'] ?? ''));
        $carrybeeClientContext = trim((string) ($settings['carrybee_client_context'] ?? ''));
        if ($carrybeeBaseUrl !== '' && $carrybeeClientId !== '' && $carrybeeClientSecret !== '') {
            $rows = $this->database->fetchAll(
                "SELECT id, status, history, exchange_carrybee_consignment_id
                 FROM orders
                 WHERE deleted_at IS NULL
                   AND exchange_carrybee_consignment_id IS NOT NULL
                   AND exchange_carrybee_consignment_id <> ''
                   AND status IN ('Exchange processing', 'Exchange picked')
                   ORDER BY created_at ASC LIMIT {$limit} OFFSET {$offset}"
            );
            foreach ($rows as $row) {
                $consignmentId = trim((string) ($row['exchange_carrybee_consignment_id'] ?? ''));
                if ($consignmentId === '') continue;
                $checked += 1;

                $details = $this->fetchCarryBeeOrderDetails([
                    'baseUrl' => $carrybeeBaseUrl,
                    'clientId' => $carrybeeClientId,
                    'clientSecret' => $carrybeeClientSecret,
                    'clientContext' => $carrybeeClientContext,
                    'consignmentId' => $consignmentId,
                    'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                    'logPollingResponse' => true,
                ]);
                if (!empty($details['error']) || !is_array($details['data'] ?? null)) continue;

                $rawStatus = strtolower(trim((string) (
                    $details['data']['order_status'] ??
                    $details['data']['data']['order_status'] ??
                    $details['data']['status'] ??
                    ''
                )));
                if ($rawStatus === '') continue;

                $currentStatus = trim((string) ($row['status'] ?? ''));
                $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
                $updates = ['history' => $history];

                if (strpos($rawStatus, 'delivered') !== false || strpos($rawStatus, 'complete') !== false) {
                    $updates['history']['exchangeDelivered'] = 'Exchange delivered via CarryBee (' . $rawStatus . ') on ' . gmdate('c');
                    $updates['status'] = 'Exchange delivered';
                    $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange delivered via CarryBee (' . $rawStatus . ') on ' . gmdate('c');
                } elseif (strpos($rawStatus, 'return') !== false || strpos($rawStatus, 'cancel') !== false) {
                    $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange returned/cancelled via CarryBee (' . $rawStatus . ') on ' . gmdate('c');
                } elseif ($currentStatus === 'Exchange processing') {
                    $updates['status'] = 'Exchange picked';
                    $updates['history']['exchangePicked'] = 'Exchange picked up by CarryBee (' . $rawStatus . ') on ' . gmdate('c');
                } else {
                    continue;
                }

                $this->updateOrderAsCourierSystem(['id' => (string) $row['id'], 'updates' => $updates]);
                $updated += 1;
            }
        }

        // Paperfly exchange consignments
        $paperflyBaseUrl = rtrim(trim((string) ($settings['paperfly_base_url'] ?? '')), '/');
        $paperflyUsername = trim((string) ($settings['paperfly_username'] ?? ''));
        $paperflyPassword = trim((string) ($settings['paperfly_password'] ?? ''));
        $paperflyKey = trim((string) ($settings['paperfly_key'] ?? ''));
        if ($paperflyBaseUrl !== '' && $paperflyUsername !== '' && $paperflyPassword !== '') {
            $rows = $this->database->fetchAll(
                "SELECT id, status, history, exchange_paperfly_tracking_number
                 FROM orders
                 WHERE deleted_at IS NULL
                   AND exchange_paperfly_tracking_number IS NOT NULL
                   AND exchange_paperfly_tracking_number <> ''
                   AND status IN ('Exchange processing', 'Exchange picked')
                   ORDER BY created_at ASC LIMIT {$limit} OFFSET {$offset}"
            );
            foreach ($rows as $row) {
                $referenceNumber = trim((string) ($row['exchange_paperfly_tracking_number'] ?? ''));
                if ($referenceNumber === '') continue;
                $checked += 1;

                $details = $this->fetchPaperflyOrderTracking([
                    'baseUrl' => $paperflyBaseUrl,
                    'username' => $paperflyUsername,
                    'password' => $paperflyPassword,
                    'paperflyKey' => $paperflyKey,
                    'referenceNumber' => $referenceNumber,
                    'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                    'logPollingResponse' => true,
                ]);
                if (!empty($details['error']) || !is_array($details['data'] ?? null)) continue;

                $trackingData = $details['data'];
                $entries = [];
                if (isset($trackingData['data']) && is_array($trackingData['data'])) {
                    $entries = $trackingData['data'];
                } elseif (isset($trackingData['success']) && is_array($trackingData['success'])) {
                    $entries = $trackingData['success'];
                }

                $isDelivered = false;
                $isReturned = false;
                $isPicked = false;
                foreach ($entries as $entry) {
                    $status = strtolower(trim((string) ($entry['status'] ?? $entry['delivery_status'] ?? '')));
                    if (strpos($status, 'delivered') !== false || strpos($status, 'complete') !== false) {
                        $isDelivered = true;
                    }
                    if (strpos($status, 'return') !== false) {
                        $isReturned = true;
                    }
                    if ($status !== '' && strpos($status, 'delivered') === false && strpos($status, 'complete') === false && strpos($status, 'return') === false) {
                        $isPicked = true;
                    }
                }

                if (!$isDelivered && !$isReturned && !$isPicked) continue;

                $currentStatus = trim((string) ($row['status'] ?? ''));
                $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
                $updates = ['history' => $history];

                if ($isDelivered) {
                    $updates['history']['exchangeDelivered'] = 'Exchange delivered via Paperfly on ' . gmdate('c');
                    $updates['status'] = 'Exchange delivered';
                    $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange delivered via Paperfly on ' . gmdate('c');
                } elseif ($isReturned) {
                    $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange returned via Paperfly on ' . gmdate('c');
                } elseif ($isPicked && $currentStatus === 'Exchange processing') {
                    $updates['status'] = 'Exchange picked';
                    $updates['history']['exchangePicked'] = 'Exchange picked up by Paperfly on ' . gmdate('c');
                } else {
                    continue;
                }

                $this->updateOrderAsCourierSystem(['id' => (string) $row['id'], 'updates' => $updates]);
                $updated += 1;
            }
        }

        // Pathao exchange consignments
        $pathaoBaseUrl = rtrim(trim((string) ($settings['pathao_base_url'] ?? '')), '/');
        $pathaoClientId = trim((string) ($settings['pathao_client_id'] ?? ''));
        $pathaoClientSecret = trim((string) ($settings['pathao_client_secret'] ?? ''));
        $pathaoUsername = trim((string) ($settings['pathao_username'] ?? ''));
        $pathaoPassword = trim((string) ($settings['pathao_password'] ?? ''));
        if ($pathaoBaseUrl !== '' && $pathaoClientId !== '' && $pathaoClientSecret !== '') {
            // Get or refresh the access token
            $pathaoAccessToken = trim((string) ($settings['pathao_access_token'] ?? ''));
            $pathaoTokenExpiresAt = trim((string) ($settings['pathao_token_expires_at'] ?? ''));
            $pathaoRefreshToken = trim((string) ($settings['pathao_refresh_token'] ?? ''));
            $pathaoTokenExpired = $pathaoTokenExpiresAt !== '' && strtotime($pathaoTokenExpiresAt) < time();

            if ($pathaoAccessToken === '' || $pathaoTokenExpired) {
                if ($pathaoRefreshToken !== '') {
                    $tokenResult = $this->refreshPathaoToken([
                        'baseUrl' => $pathaoBaseUrl, 'clientId' => $pathaoClientId,
                        'clientSecret' => $pathaoClientSecret, 'refreshToken' => $pathaoRefreshToken,
                    ]);
                } elseif ($pathaoUsername !== '' && $pathaoPassword !== '') {
                    $tokenResult = $this->generatePathaoToken([
                        'baseUrl' => $pathaoBaseUrl, 'clientId' => $pathaoClientId,
                        'clientSecret' => $pathaoClientSecret, 'username' => $pathaoUsername, 'password' => $pathaoPassword,
                    ]);
                } else {
                    $tokenResult = ['error' => 'No Pathao token available'];
                }

                if (!empty($tokenResult['error'])) {
                    // Skip Pathao exchange sync if token generation fails
                } else {
                    $pathaoAccessToken = $tokenResult['accessToken'];
                    $expiresIn = $tokenResult['expiresIn'] ?? 86400;
                    $this->saveSingletonQuiet('courier_settings', 'courier-default', [
                        'pathao_access_token' => $pathaoAccessToken,
                        'pathao_refresh_token' => $tokenResult['refreshToken'] ?? $pathaoRefreshToken,
                        'pathao_token_expires_at' => gmdate('c', time() + $expiresIn),
                    ]);
                }
            }

            if (isset($pathaoAccessToken) && $pathaoAccessToken !== '') {
                $rows = $this->database->fetchAll(
                    "SELECT id, status, history, exchange_pathao_consignment_id
                     FROM orders
                     WHERE deleted_at IS NULL
                       AND exchange_pathao_consignment_id IS NOT NULL
                       AND exchange_pathao_consignment_id <> ''
                       AND status IN ('Exchange processing', 'Exchange picked')
                       ORDER BY created_at ASC LIMIT {$limit} OFFSET {$offset}"
                );
                foreach ($rows as $row) {
                    $consignmentId = trim((string) ($row['exchange_pathao_consignment_id'] ?? ''));
                    if ($consignmentId === '') continue;
                    $checked += 1;

                    $details = $this->fetchPathaoOrderInfo([
                        'baseUrl' => $pathaoBaseUrl,
                        'accessToken' => $pathaoAccessToken,
                        'consignmentId' => $consignmentId,
                        'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                        'logPollingResponse' => true,
                    ]);
                    if (!empty($details['error']) || !is_array($details['data'] ?? null)) continue;

                    $responseData = $details['data'];
                    $orderData = is_array($responseData['data'] ?? null) ? $responseData['data'] : $responseData;
                    $orderStatusSlug = strtolower(trim((string) ($orderData['order_status_slug'] ?? $orderData['order_status'] ?? '')));
                    if ($orderStatusSlug === '') continue;

                    $currentStatus = trim((string) ($row['status'] ?? ''));
                    $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
                    $updates = ['history' => $history];

                    if (strpos($orderStatusSlug, 'delivered') !== false) {
                        $updates['history']['exchangeDelivered'] = 'Exchange delivered via Pathao (' . $orderStatusSlug . ') on ' . gmdate('c');
                        $updates['status'] = 'Exchange delivered';
                        $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange delivered via Pathao (' . $orderStatusSlug . ') on ' . gmdate('c');
                    } elseif (strpos($orderStatusSlug, 'return') !== false || strpos($orderStatusSlug, 'cancel') !== false) {
                        $updates['history']['exchangeCourier'] = ($updates['history']['exchangeCourier'] ?? '') . ' | Exchange returned/cancelled via Pathao (' . $orderStatusSlug . ') on ' . gmdate('c');
                    } elseif (strpos($orderStatusSlug, 'picked') !== false && $currentStatus === 'Exchange processing') {
                        $updates['status'] = 'Exchange picked';
                        $updates['history']['exchangePicked'] = 'Exchange picked up by Pathao (' . $orderStatusSlug . ') on ' . gmdate('c');
                    } else {
                        continue;
                    }

                    $this->updateOrderAsCourierSystem(['id' => (string) $row['id'], 'updates' => $updates]);
                    $updated += 1;
                }
            }
        }

        return ['checked' => $checked, 'updated' => $updated];
    }

    // ===== Pathao Courier Methods =====

    /**
     * @return array<int, array{id: string, name: string}>
     */
    private function pathaoLocationCollection(array $response, string $idKey, string $nameKey): array
    {
        $payload = is_array($response['json'] ?? null) ? $response['json'] : [];
        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new RuntimeException((string) ($payload['message'] ?? $payload['error'] ?? ('Pathao location request failed with HTTP ' . $response['status'] . '.')));
        }

        $rows = $payload['data']['data'] ?? $payload['data'] ?? [];
        if (!is_array($rows)) {
            return [];
        }

        $locations = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = trim((string) ($row[$idKey] ?? $row['id'] ?? ''));
            $name = trim((string) ($row[$nameKey] ?? $row['name'] ?? ''));
            if ($id === '' || $name === '') {
                continue;
            }
            $locations[] = ['id' => $id, 'name' => $name];
        }

        return $locations;
    }

    /** GET {baseUrl}/aladdin/api/v1/city-list */
    public function fetchPathaoCities(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $accessToken = trim((string) ($params['accessToken'] ?? ''));
        if ($baseUrl === '') {
            throw new RuntimeException('Pathao base URL is not configured. Open Settings and enter the Pathao API base URL.');
        }
        if ($accessToken === '') {
            throw new RuntimeException('Pathao access token is not configured. Open Settings, enter your Pathao credentials, and save. The token will be generated automatically.');
        }

        return $this->pathaoLocationCollection($this->request(
            'GET',
            $baseUrl . '/aladdin/api/v1/city-list',
            ['Authorization' => 'Bearer ' . $accessToken, 'Accept' => 'application/json']
        ), 'city_id', 'city_name');
    }

    /** GET {baseUrl}/aladdin/api/v1/cities/{cityId}/zone-list */
    public function fetchPathaoZones(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $accessToken = trim((string) ($params['accessToken'] ?? ''));
        $cityId = trim((string) ($params['cityId'] ?? ''));
        if ($baseUrl === '' || $accessToken === '' || $cityId === '') {
            throw new RuntimeException('Select a Pathao city before loading zones.');
        }

        return $this->pathaoLocationCollection($this->request(
            'GET',
            $baseUrl . '/aladdin/api/v1/cities/' . rawurlencode($cityId) . '/zone-list',
            ['Authorization' => 'Bearer ' . $accessToken, 'Accept' => 'application/json']
        ), 'zone_id', 'zone_name');
    }

    /** GET {baseUrl}/aladdin/api/v1/zones/{zoneId}/area-list */
    public function fetchPathaoAreas(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $accessToken = trim((string) ($params['accessToken'] ?? ''));
        $zoneId = trim((string) ($params['zoneId'] ?? ''));
        if ($baseUrl === '' || $accessToken === '' || $zoneId === '') {
            throw new RuntimeException('Select a Pathao zone before loading areas.');
        }

        return $this->pathaoLocationCollection($this->request(
            'GET',
            $baseUrl . '/aladdin/api/v1/zones/' . rawurlencode($zoneId) . '/area-list',
            ['Authorization' => 'Bearer ' . $accessToken, 'Accept' => 'application/json']
        ), 'area_id', 'area_name');
    }

    /**
     * Generate a Pathao OAuth2 access token using the password grant.
     * POST {baseUrl}/aladdin/api/v1/issue-token
     */
    public function generatePathaoToken(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $clientId = trim((string) ($params['clientId'] ?? ''));
        $clientSecret = trim((string) ($params['clientSecret'] ?? ''));
        $username = trim((string) ($params['username'] ?? ''));
        $password = trim((string) ($params['password'] ?? ''));

        if ($baseUrl === '' || $clientId === '' || $clientSecret === '') {
            return ['error' => 'Missing required Pathao credentials (baseUrl, clientId, clientSecret)'];
        }
        if ($username === '' || $password === '') {
            return ['error' => 'Missing Pathao username or password for token generation'];
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/aladdin/api/v1/issue-token',
            ['Accept' => 'application/json'],
            [
                'client_id' => $clientId,
                'client_secret' => $clientSecret,
                'grant_type' => 'password',
                'username' => $username,
                'password' => $password,
            ]
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status'], 'raw' => $response['json'] ?? $response['body']];
        }

        $json = $response['json'];
        if (!is_array($json) || empty($json['access_token'])) {
            return ['error' => 'Pathao token response was missing required fields'];
        }

        return [
            'accessToken' => $json['access_token'],
            'refreshToken' => $json['refresh_token'] ?? '',
            'expiresIn' => (int) ($json['expires_in'] ?? 86400),
        ];
    }

    /**
     * Refresh a Pathao OAuth2 access token using the refresh_token grant.
     * POST {baseUrl}/aladdin/api/v1/issue-token
     */
    public function refreshPathaoToken(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $clientId = trim((string) ($params['clientId'] ?? ''));
        $clientSecret = trim((string) ($params['clientSecret'] ?? ''));
        $refreshToken = trim((string) ($params['refreshToken'] ?? ''));

        if ($baseUrl === '' || $clientId === '' || $clientSecret === '') {
            return ['error' => 'Missing required Pathao credentials (baseUrl, clientId, clientSecret)'];
        }
        if ($refreshToken === '') {
            return ['error' => 'Missing Pathao refresh token'];
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/aladdin/api/v1/issue-token',
            ['Accept' => 'application/json'],
            [
                'client_id' => $clientId,
                'client_secret' => $clientSecret,
                'grant_type' => 'refresh_token',
                'refresh_token' => $refreshToken,
            ]
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status'], 'raw' => $response['json'] ?? $response['body']];
        }

        $json = $response['json'];
        if (!is_array($json) || empty($json['access_token'])) {
            return ['error' => 'Pathao token response was missing required fields'];
        }

        return [
            'accessToken' => $json['access_token'],
            'refreshToken' => $json['refresh_token'] ?? '',
            'expiresIn' => (int) ($json['expires_in'] ?? 86400),
        ];
    }

    /**
     * Create a Pathao delivery order.
     * POST {baseUrl}/aladdin/api/v1/orders
     */
    public function submitPathaoOrder(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $accessToken = trim((string) ($params['accessToken'] ?? ''));
        $storeId = trim((string) ($params['storeId'] ?? ''));

        if ($baseUrl === '' || $accessToken === '' || $storeId === '') {
            return ['error' => 'Missing required Pathao parameters (baseUrl, accessToken, storeId)'];
        }

        $recipientName = trim((string) ($params['recipientName'] ?? ''));
        $recipientPhone = trim((string) ($params['recipientPhone'] ?? ''));
        $recipientAddress = trim((string) ($params['recipientAddress'] ?? ''));
        $recipientCity = trim((string) ($params['recipientCity'] ?? ''));
        $recipientZone = trim((string) ($params['recipientZone'] ?? ''));
        $recipientArea = trim((string) ($params['recipientArea'] ?? ''));

        if ($recipientName === '' || $recipientPhone === '' || $recipientAddress === '') {
            return ['error' => 'Missing required order fields: recipient name, phone, or address'];
        }

        $payload = [
            'store_id' => $storeId,
            'recipient_name' => $recipientName,
            'recipient_phone' => $recipientPhone,
            'recipient_address' => $recipientAddress,
            'delivery_type' => (int) ($params['deliveryType'] ?? 48),
            'item_type' => (int) ($params['itemType'] ?? 2),
            'item_description' => trim((string) ($params['itemDescription'] ?? '')),
            'item_quantity' => (int) ($params['itemQuantity'] ?? 1),
            'item_weight' => (float) ($params['itemWeight'] ?? 1.0),
            'amount_to_collect' => max(0, (int) round((float) ($params['amountToCollect'] ?? 0))),
        ];
        $merchantOrderId = trim((string) ($params['merchantOrderId'] ?? ''));
        if ($merchantOrderId !== '') {
            $payload['merchant_order_id'] = $merchantOrderId;
        }
        if ($recipientCity !== '') {
            $payload['recipient_city'] = (int) $recipientCity;
        }
        if ($recipientZone !== '') {
            $payload['recipient_zone'] = (int) $recipientZone;
        }
        if ($recipientArea !== '') {
            $payload['recipient_area'] = (int) $recipientArea;
        }

        $specialInstruction = trim((string) ($params['specialInstruction'] ?? ''));
        if ($specialInstruction !== '') {
            $payload['special_instruction'] = $specialInstruction;
        }

        $response = $this->request(
            'POST',
            $baseUrl . '/aladdin/api/v1/orders',
            [
                'Authorization' => 'Bearer ' . $accessToken,
                'Accept' => 'application/json',
            ],
            $payload
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status'], 'raw' => $response['json'] ?? $response['body']];
        }

        return is_array($response['json']) ? $response['json'] : ['error' => 'Invalid response'];
    }

    /**
     * Fetch Pathao order info (used for auto pickup/delivery status check).
    * GET {baseUrl}/aladdin/api/v1/orders/{consignmentId}/info
     */
    public function fetchPathaoOrderInfo(array $params): array
    {
        $baseUrl = $this->trimBaseUrl($params);
        $accessToken = trim((string) ($params['accessToken'] ?? ''));
        $consignmentId = trim((string) ($params['consignmentId'] ?? ''));

        if ($baseUrl === '' || $accessToken === '' || $consignmentId === '') {
            return ['error' => 'Missing required Pathao parameters (baseUrl, accessToken, consignmentId)'];
        }

        $response = $this->courierPollingRequest(
            $params,
            'pathao',
            $consignmentId,
            'GET',
            $baseUrl . '/aladdin/api/v1/orders/' . rawurlencode($consignmentId) . '/info',
            [
                'Authorization' => 'Bearer ' . $accessToken,
                'Accept' => 'application/json',
            ],
            null,
            $this->requestTimeout($params)
        );

        if ($response['status'] < 200 || $response['status'] >= 300) {
            return ['error' => 'HTTP ' . $response['status'], 'raw' => $response['json'] ?? $response['body']];
        }

        return ['data' => $response['json']];
    }

    /**
     * Classify a Pathao order status slug into a normalized status.
    * Paid return is a partial-delivery state; other return statuses are Returned.
     */
    private function classifyPathaoStatus(string $orderStatusSlug): array
    {
        $normalized = strtolower(trim($orderStatusSlug));
        $normalizedWords = preg_replace('/[._-]+/', ' ', $normalized) ?? $normalized;
        $status = null;

        if ($normalized !== '') {
            if (strpos($normalized, 'cancelled') !== false || strpos($normalized, 'canceled') !== false) {
                $status = 'Cancelled';
            } elseif (preg_match('/paid[\\s._-]*return/', $normalized) === 1) {
                $status = 'Partially Delivered';
            } elseif (strpos($normalized, 'return') !== false) {
                $status = 'Returned';
            } elseif (strpos($normalized, 'partial') !== false) {
                $status = 'Partially Delivered';
            } elseif (strpos($normalized, 'delivered') !== false) {
                $status = 'Delivered';
            } elseif (
                strpos($normalized, 'picked') !== false
                || strpos($normalized, 'pickup') !== false
                || strpos($normalized, 'pick up') !== false
                || strpos($normalized, 'transit') !== false
                || $normalizedWords === 'ready for delivery'
            ) {
                $status = 'Picked';
            }
        }

        return [
            'rawStatus' => $orderStatusSlug,
            'normalizedStatus' => $normalized,
            'status' => $status,
            'isPickedOrBeyond' => $status !== null && $status !== 'Cancelled',
        ];
    }

    /**
     * Sync delivery statuses for all Pathao orders.
     * Checks order_status_slug via the /info endpoint for keywords: picked, delivered.
     */
    public function syncPathaoDeliveryStatuses(array $params = []): array
    {
        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1');
        $baseUrl = rtrim(trim((string) ($settings['pathao_base_url'] ?? '')), '/');
        $clientId = trim((string) ($settings['pathao_client_id'] ?? ''));
        $clientSecret = trim((string) ($settings['pathao_client_secret'] ?? ''));
        $username = trim((string) ($settings['pathao_username'] ?? ''));
        $password = trim((string) ($settings['pathao_password'] ?? ''));

        if ($baseUrl === '' || $clientId === '' || $clientSecret === '') {
            return ['checked' => 0, 'updated' => 0];
        }
        $limit = max(1, min(1000000, (int) ($params['limit'] ?? 1000000)));
        $offset = max(0, min(1000000, (int) ($params['offset'] ?? 0)));

        // Get or refresh the access token
        $accessToken = trim((string) ($settings['pathao_access_token'] ?? ''));
        $tokenExpiresAt = trim((string) ($settings['pathao_token_expires_at'] ?? ''));
        $refreshToken = trim((string) ($settings['pathao_refresh_token'] ?? ''));

        $tokenExpired = $tokenExpiresAt !== '' && strtotime($tokenExpiresAt) < time();

        if ($accessToken === '' || $tokenExpired) {
            // Try refresh first, then password grant
            if ($refreshToken !== '') {
                $tokenResult = $this->refreshPathaoToken([
                    'baseUrl' => $baseUrl,
                    'clientId' => $clientId,
                    'clientSecret' => $clientSecret,
                    'refreshToken' => $refreshToken,
                ]);
            } elseif ($username !== '' && $password !== '') {
                $tokenResult = $this->generatePathaoToken([
                    'baseUrl' => $baseUrl,
                    'clientId' => $clientId,
                    'clientSecret' => $clientSecret,
                    'username' => $username,
                    'password' => $password,
                ]);
            } else {
                return ['checked' => 0, 'updated' => 0, 'error' => 'No valid Pathao token and no credentials to generate one'];
            }

            if (!empty($tokenResult['error'])) {
                return ['checked' => 0, 'updated' => 0, 'error' => $tokenResult['error']];
            }

            $accessToken = $tokenResult['accessToken'];
            $expiresIn = $tokenResult['expiresIn'] ?? 86400;
            $newRefreshToken = $tokenResult['refreshToken'] ?? $refreshToken;
            $newExpiresAt = gmdate('c', time() + $expiresIn);

            // Persist the new token
            $this->saveSingletonQuiet('courier_settings', 'courier-default', [
                'pathao_access_token' => $accessToken,
                'pathao_refresh_token' => $newRefreshToken,
                'pathao_token_expires_at' => $newExpiresAt,
            ]);
        }

        $rows = $this->database->fetchAll(
            "SELECT id, order_number, status, history, pathao_consignment_id
             FROM orders
             WHERE deleted_at IS NULL
               AND pathao_consignment_id IS NOT NULL
               AND pathao_consignment_id <> ''
               AND status IN ('On Hold', 'Processing', 'Courier assigned', 'Picked')
               ORDER BY created_at ASC
               LIMIT {$limit} OFFSET {$offset}"
        );

        $checked = 0;
        $updated = 0;
        $failed = 0;
        foreach ($rows as $row) {
            $consignmentId = trim((string) ($row['pathao_consignment_id'] ?? ''));
            if ($consignmentId === '') {
                continue;
            }
            $checked += 1;

            $details = $this->fetchPathaoOrderInfo([
                'baseUrl' => $baseUrl,
                'accessToken' => $accessToken,
                'consignmentId' => $consignmentId,
                'timeoutSeconds' => (int) ($params['timeoutSeconds'] ?? 30),
                'logPollingResponse' => true,
            ]);

            if (!empty($details['error']) || !is_array($details['data'] ?? null)) {
                $failed += 1;
                continue;
            }

            $responseData = $details['data'];
            // The response may have data nested under 'data' key
            $orderData = is_array($responseData['data'] ?? null) ? $responseData['data'] : $responseData;
            $orderStatusSlug = trim((string) ($orderData['order_status_slug'] ?? $orderData['order_status'] ?? ''));

            if ($orderStatusSlug === '') {
                continue;
            }

            $statusInfo = $this->classifyPathaoStatus($orderStatusSlug);
            if (empty($statusInfo['status'])) {
                continue;
            }
            $history = is_array(json_decode((string) ($row['history'] ?? ''), true)) ? json_decode((string) $row['history'], true) : [];
            $pathaoStatusNeedsDisplay = in_array(
                preg_replace('/[._-]+/', ' ', $statusInfo['normalizedStatus']) ?? $statusInfo['normalizedStatus'],
                ['in transit', 'ready for delivery'],
                true
            );
            if (
                $statusInfo['status'] === 'Picked'
                && (string) ($row['status'] ?? '') === 'Picked'
                && (
                    ($pathaoStatusNeedsDisplay && ($history['pathaoStatus'] ?? null) === $statusInfo['rawStatus'])
                    || (!$pathaoStatusNeedsDisplay && trim((string) ($history['pathaoStatus'] ?? '')) === '')
                )
            ) continue;

            if ($statusInfo['status'] === 'Picked') {
                if ($pathaoStatusNeedsDisplay) {
                    $history['pathaoStatus'] = $statusInfo['rawStatus'];
                } else {
                    unset($history['pathaoStatus']);
                }
            }
            $updates = ['history' => $history];

            if ($statusInfo['status'] === 'Partially Delivered') {
                $updates['status'] = 'pending_partial';
                $updates['history']['partiallyDelivered'] = 'Marked partially delivered automatically from Pathao order status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c') . '. Action required to confirm delivered items.';
                $updates['partial_delivery_action_required'] = 1;
                $updates['partial_delivered_at'] = gmdate('c');
            } elseif ($statusInfo['status'] === 'Delivered') {
                $deliveredTarget = $this->resolveDeliveredTargetStatus((string) ($row['status'] ?? ''), gmdate('c'));
                $updates['status'] = $deliveredTarget['status'];
                if (($deliveredTarget['pendingDelivered'] ?? false) === true) {
                    $updates['delivery_action_required'] = 1;
                    $updates['partial_delivered_at'] = gmdate('c');
                    $updates['history']['pendingDelivered'] = 'Marked pending delivered automatically from Pathao order status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c') . '. Action required to confirm delivery.';
                } else {
                    $updates['history']['completed'] = 'Marked delivered automatically from Pathao order status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
                }
            } elseif ($statusInfo['status'] === 'Returned') {
                $updates['status'] = 'Returned';
                $updates['history']['returned'] = 'Marked returned automatically from Pathao order status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
            } elseif ($statusInfo['status'] === 'Cancelled') {
                $updates['status'] = 'Cancelled';
                $updates['history']['cancelled'] = 'Marked cancelled automatically from Pathao order status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c');
            } else {
                $updates['status'] = 'Picked';
                $updates['history']['picked'] = $updates['history']['picked'] ?? ('Marked picked automatically from Pathao order status "' . $statusInfo['rawStatus'] . '" on ' . gmdate('c'));
            }

            $this->attachSyncedCharge(
                $updates,
                'pathao',
                is_array($orderData ?? null) ? $orderData : [],
                (string) ($row['pathao_consignment_id'] ?? ''),
                (string) ($row['order_number'] ?? ''),
                (string) $row['id']
            );
            $this->updateOrderAsCourierSystem([
                'id' => (string) $row['id'],
                'updates' => $updates,
            ]);
            $updated += 1;
        }

        return ['checked' => $checked, 'updated' => $updated, 'failed' => $failed];
    }

    /**
     * Receive one signed provider event. Exact retries are idempotent and the
     * entire status/charge/expense operation shares one database transaction.
     *
     * @param array<string, string> $headers
     * @return array<string, mixed>
     */
    public function handleWebhook(string $provider, string $rawBody, array $headers, bool $trustedReplay = false): array
    {
        $provider = strtolower(trim($provider));
        if (!in_array($provider, ['carrybee', 'paperfly', 'steadfast', 'pathao'], true)) {
            throw new RuntimeException('Unsupported courier webhook provider.');
        }

        // CarryBee and Pathao webhook integration handshakes — bypass secret
        // verification because these events fire before the user stores the
        // secret in our app.
        if (in_array($provider, ['carrybee', 'pathao'], true)) {
            $earlyPayload = json_decode($rawBody, true);
            $integrationEvent = is_array($earlyPayload) ? ($earlyPayload['event'] ?? '') : '';
            if ($integrationEvent === 'webhook.integration' || $integrationEvent === 'webhook_integration') {
                $result = [
                    'status' => 'success',
                    'provider' => $provider,
                    'event' => $integrationEvent,
                    'integrationVerified' => true,
                ];
                if ($provider === 'pathao') {
                    $settings = $this->database->fetchOne('SELECT pathao_merchant_webhook_secret FROM courier_settings LIMIT 1') ?? [];
                    $result['merchantWebhookSecret'] = (string) ($settings['pathao_merchant_webhook_secret'] ?? '');
                } else {
                    // CarryBee demands a configurable response header whose name
                    // and value it may change at any time.
                    $settings = $this->database->fetchOne(
                        'SELECT carrybee_webhook_integration_header, carrybee_webhook_integration_value FROM courier_settings LIMIT 1'
                    ) ?? [];
                    $result['webhookIntegrationHeader'] = trim((string) ($settings['carrybee_webhook_integration_header'] ?? ''))
                        ?: 'X-CB-Webhook-Integration-Header';
                    $result['webhookIntegrationValue'] = trim((string) ($settings['carrybee_webhook_integration_value'] ?? ''))
                        ?: '40489fe0-9386-4fc9-8e92-2b2fcb9d451c';
                }
                return $result;
            }
        }

        if (!$this->tableExists('courier_webhook_events') || !$this->tableExists('courier_order_charges')) {
            throw new RuntimeException('Courier webhook database upgrade has not been applied.');
        }

        $settings = $this->database->fetchOne('SELECT * FROM courier_settings LIMIT 1') ?? [];
        $idempotencyKey = $provider === 'steadfast'
            ? trim($this->webhookHeader($headers, 'Idempotency-Key'))
            : '';
        if (strlen($idempotencyKey) > 255) {
            throw new RuntimeException('Invalid courier webhook idempotency key.');
        }
        if (!$trustedReplay) $this->verifyWebhookRequest($provider, $rawBody, $headers, $settings);

        try {
            $payload = json_decode($rawBody, true, 64, JSON_THROW_ON_ERROR);
        } catch (\JsonException $exception) {
            throw new RuntimeException('Invalid courier webhook JSON.');
        }
        if (!is_array($payload)) {
            throw new RuntimeException('Invalid courier webhook payload.');
        }

        $details = $this->webhookDetails($provider, $payload);
        $eventKey = $idempotencyKey !== ''
            ? hash('sha256', $provider . '|idempotency|' . $idempotencyKey)
            : hash('sha256', $provider . '|' . $rawBody);
        $now = $this->database->nowUtc();

        return $this->database->transaction(function () use (
            $provider,
            $rawBody,
            $idempotencyKey,
            $details,
            $eventKey,
            $now
        ): array {
            $savingEnabled = $this->webhookSavingEnabled();
            $eventId = '';
            if ($savingEnabled) {
                $candidateId = $this->uuid4();
                $this->database->execute(
                    "INSERT INTO courier_webhook_events (
                        id, provider, event_key, idempotency_key, event_name, merchant_reference, consignment_id,
                        event_at, payload, processing_status, received_at
                     ) VALUES (
                        :id, :provider, :event_key, :idempotency_key, :event_name, :merchant_reference, :consignment_id,
                        :event_at, :payload, 'received', :received_at
                            ) ON DUPLICATE KEY UPDATE
                                event_key = VALUES(event_key),
                                received_at = VALUES(received_at)",
                    [
                        ':id' => $candidateId,
                        ':provider' => $provider,
                        ':event_key' => $eventKey,
                        ':idempotency_key' => $idempotencyKey !== '' ? $idempotencyKey : null,
                        ':event_name' => $details['eventName'],
                        ':merchant_reference' => $details['merchantReference'] !== '' ? $details['merchantReference'] : null,
                        ':consignment_id' => $details['consignmentId'] !== '' ? $details['consignmentId'] : null,
                        ':event_at' => $details['eventAt'],
                        ':payload' => $rawBody,
                        ':received_at' => $now,
                    ]
                );
                $eventRow = $this->database->fetchOne(
                    'SELECT * FROM courier_webhook_events WHERE provider = :provider AND event_key = :event_key LIMIT 1 FOR UPDATE',
                    [':provider' => $provider, ':event_key' => $eventKey]
                );
                if ($eventRow === null) {
                    throw new RuntimeException('Courier webhook event could not be stored.');
                }
                if ((string) ($eventRow['processing_status'] ?? '') === 'processed') {
                    return [
                        'status' => 'success',
                        'provider' => $provider,
                        'event' => $details['eventName'],
                        'duplicate' => true,
                    ];
                }
                $eventId = (string) $eventRow['id'];
            }

            $orderMatch = $this->findWebhookOrder(
                $provider,
                $details['consignmentId'],
                $details['merchantReference'],
                $details['eventName']
            );
            $orderId = trim((string) ($orderMatch['id'] ?? ''));
            $charge = $this->upsertWebhookCharge(
                $provider,
                $details,
                $eventId !== '' ? $eventId : null,
                $orderId
            );

            if ($provider === 'steadfast' && $orderId !== '' && $details['eventName'] === 'tracking_update') {
                $this->recordSteadfastTrackingUpdate($details, $orderId, $eventKey);
            }

            if ($orderId === '') {
                $message = 'No local order matched the courier identifiers.';
                if ($savingEnabled) {
                    $this->finishWebhookEvent($eventId, 'unmatched', $message, null);
                }
                return [
                    'status' => 'success',
                    'provider' => $provider,
                    'event' => $details['eventName'],
                    'duplicate' => false,
                    'orderMatched' => false,
                    'webhookEventSaved' => $savingEnabled,
                ];
            }

            $updates = $this->buildWebhookOrderUpdates(
                $provider,
                $details,
                $orderMatch,
                $charge
            );
            $updated = false;
            if ($updates !== []) {
                $this->updateOrderAsCourierSystem(['id' => $orderId, 'updates' => $updates]);
                $updated = true;
            }

            $chargeAfter = $charge === null ? null : $this->database->fetchOne(
                'SELECT expense_status FROM courier_order_charges WHERE id = :id LIMIT 1',
                [':id' => (string) $charge['id']]
            );
            if ($savingEnabled) {
                $message = $updates === [] ? 'Event stored; no safe order status change was required.' : 'Order updated from courier webhook.';
                $this->finishWebhookEvent($eventId, 'processed', $message, $orderId);
            }

            return [
                'status' => 'success',
                'provider' => $provider,
                'event' => $details['eventName'],
                'duplicate' => false,
                'orderMatched' => true,
                'orderUpdated' => $updated,
                'expenseRecorded' => (string) ($chargeAfter['expense_status'] ?? '') === 'recorded',
                'webhookEventSaved' => $savingEnabled,
            ];
        });
    }

    /**
     * Retry authenticated webhook payloads that arrived before their local
     * order identifiers were available. This is CLI-only so the trusted replay
     * path cannot be invoked through the public action dispatcher.
     *
     * @return array{checked:int,matched:int,updated:int,failed:int}
     */
    public function reconcileUnmatchedWebhookEvents(array $params = []): array
    {
        if (PHP_SAPI !== 'cli') throw new RuntimeException('Courier webhook reconciliation is CLI-only.');
        if (!$this->tableExists('courier_webhook_events')) return ['checked' => 0, 'matched' => 0, 'updated' => 0, 'failed' => 0];

        $provider = strtolower(trim((string) ($params['provider'] ?? '')));
        if (!in_array($provider, ['carrybee', 'paperfly', 'steadfast', 'pathao'], true)) {
            throw new RuntimeException('Unsupported courier webhook reconciliation provider.');
        }
        $limit = max(1, min(10, (int) ($params['limit'] ?? 3)));
        $rows = $this->database->fetchAll(
            "SELECT payload FROM courier_webhook_events
             WHERE provider = :provider AND processing_status = 'unmatched'
             ORDER BY COALESCE(processed_at, received_at) ASC, received_at ASC
             LIMIT {$limit}",
            [':provider' => $provider]
        );
        $matched = 0;
        $updated = 0;
        $failed = 0;
        foreach ($rows as $row) {
            try {
                $result = $this->handleWebhook($provider, (string) ($row['payload'] ?? ''), [], true);
                if (!empty($result['orderMatched'])) $matched += 1;
                if (!empty($result['orderUpdated'])) $updated += 1;
            } catch (\Throwable $exception) {
                $failed += 1;
                error_log('Stored courier webhook reconciliation failed: ' . $exception->getMessage());
            }
        }
        return ['checked' => count($rows), 'matched' => $matched, 'updated' => $updated, 'failed' => $failed];
    }

    /** @param array<string, string> $headers @param array<string, mixed> $settings */
    private function verifyWebhookRequest(string $provider, string $rawBody, array $headers, array $settings): void
    {
        $authorization = $this->webhookHeader($headers, 'Authorization');
        if ($provider === 'carrybee') {
            // Real CarryBee events sign with the configurable
            // X-Carrybee-Webhook-Signature header carrying the dashboard secret.
            $expected = trim((string) ($settings['carrybee_webhook_signature'] ?? ''));
            $signatureHeader = trim((string) ($settings['carrybee_webhook_header'] ?? '')) ?: 'X-Carrybee-Webhook-Signature';
            $provided = $this->webhookHeader($headers, $signatureHeader);
        } elseif ($provider === 'steadfast') {
            $authToken = trim((string) ($settings['steadfast_webhook_auth_token'] ?? ''));
            $providedToken = preg_replace('/^Bearer\s+/i', '', $authorization) ?? '';
            $providedSignature = strtolower(trim($this->webhookHeader($headers, 'X-Signature')));
            $expectedSignature = $authToken === '' ? '' : hash_hmac('sha256', $rawBody, $authToken);
            if (
                $authToken === ''
                || $providedToken === ''
                || !hash_equals($authToken, trim($providedToken))
                || $providedSignature === ''
                || !hash_equals($expectedSignature, $providedSignature)
            ) {
                throw new RuntimeException('Invalid courier webhook signature.');
            }
        } elseif ($provider === 'paperfly') {
            $expected = trim((string) ($settings['paperfly_webhook_secret'] ?? ''));
            $provided = '';
            foreach (['X-Paperfly-Webhook-Secret', 'X-Webhook-Secret', 'Secret-Key'] as $headerName) {
                $candidate = $this->webhookHeader($headers, $headerName);
                if ($candidate !== '') {
                    $provided = $candidate;
                    break;
                }
            }
            if ($provided === '' && $authorization !== '') {
                $provided = preg_replace('/^Bearer\s+/i', '', $authorization) ?? '';
            }
        } else {
            // Pathao always sends the signature in X-PATHAO-Signature.
            $expected = trim((string) ($settings['pathao_webhook_secret'] ?? ''));
            $provided = $this->webhookHeader($headers, 'X-PATHAO-Signature');
            if ($provided === '') {
                // Fallback for legacy configurable header name.
                $legacyHeader = trim((string) ($settings['pathao_webhook_header'] ?? ''));
                if ($legacyHeader !== '' && strcasecmp($legacyHeader, 'X-PATHAO-Signature') !== 0) {
                    $provided = $this->webhookHeader($headers, $legacyHeader);
                }
            }
        }

        if ($expected === '' || $provided === '' || !hash_equals($expected, trim($provided))) {
            throw new RuntimeException('Invalid courier webhook signature.');
        }
    }

    /** @param array<string, string> $headers */
    private function webhookHeader(array $headers, string $name): string
    {
        foreach ($headers as $key => $value) {
            if (strcasecmp((string) $key, $name) === 0) {
                return trim((string) $value);
            }
        }
        return '';
    }

    /** @return array<string, mixed> */
    private function webhookDetails(string $provider, array $payload): array
    {
        $data = is_array($payload['data'] ?? null) ? $payload['data'] : [];
        $containers = [$payload, $data];
        $eventName = $this->firstWebhookValue($containers, ['event', 'notification_type', 'event_type', 'type']);
        if ($eventName === '') {
            $eventName = 'status.update';
        }
        $consignmentId = $this->firstWebhookValue($containers, [
            'consignment_id', 'consignmentId', 'order_number', 'tracking_code', 'tracking_number', 'barcode',
        ]);
        $merchantReference = $this->firstWebhookValue($containers, [
            'merchant_order_id', 'merchant_order_reference', 'merchantOrderReference', 'invoice', 'merchant_order_ref',
        ]);
        $eventAtRaw = $this->firstWebhookValue($containers, [
            'timestamptz', 'timestamp', 'updated_at', 'action_date_time', 'action_datetime', 'event_at',
        ]);
        $eventAt = null;
        if ($eventAtRaw !== '' && strtotime($eventAtRaw) !== false) {
            $eventAt = gmdate('Y-m-d H:i:s', (int) strtotime($eventAtRaw));
        }

        $rawStatus = '';
        $codFee = $this->firstWebhookNumber($containers, ['cod_fee', 'cod_charge', 'collection_charge', 'collection_fee']);
        $deliveryFee = $this->firstWebhookNumber($containers, ['delivery_fee', 'delivery_charge', 'shipping_fee', 'shipping_charge']);
        $directTotal = $this->firstWebhookNumber($containers, ['total_charge', 'courier_charge', 'shipping_cost']);
        $totalCharge = round($codFee + $deliveryFee, 2);
        if ($totalCharge <= 0 && $directTotal > 0) {
            $totalCharge = round($directTotal, 2);
        }

        // Collected amount from courier: Steadfast uses cod_amount, others use collected_amount.
        $collectedAmount = 0.0;
        if ($provider === 'steadfast') {
            $collectedAmount = $this->firstWebhookNumber($containers, ['cod_amount']);
        } else {
            $collectedAmount = $this->firstWebhookNumber($containers, ['collected_amount']);
        }

        // Steadfast cancel events collect nothing — prevent paid-return income booking.
        if ($provider === 'steadfast' && (str_contains($eventName, 'cancel') || str_contains($rawStatus, 'cancel'))) {
            $collectedAmount = 0.0;
        }

        $rawStatus = $this->firstWebhookValue($containers, [
            'order_status_slug', 'order_status', 'delivery_status', 'status', 'tracking_status',
        ]);
        $mappedStatus = $this->mapWebhookStatus($provider, $eventName, $rawStatus);
        $trackingMessage = $this->firstWebhookValue($containers, [
            'tracking_message', 'trackingMessage', 'status_message', 'message',
        ]);

        return [
            'eventName' => $eventName,
            'consignmentId' => $consignmentId,
            'merchantReference' => $merchantReference,
            'eventAt' => $eventAt,
            'codFee' => max(0, round($codFee, 2)),
            'deliveryFee' => max(0, round($deliveryFee, 2)),
            'totalCharge' => max(0, $totalCharge),
            'collectedAmount' => max(0, round($collectedAmount, 2)),
            'currency' => strtoupper($this->firstWebhookValue($containers, ['currency'])) ?: 'BDT',
            'rawStatus' => $rawStatus !== '' ? $rawStatus : $eventName,
            'mappedStatus' => $mappedStatus,
            'trackingMessage' => $trackingMessage,
        ];
    }

    /**
     * Persist a Steadfast tracking_update webhook message so the order detail
     * page can render a "Courier tracking" timeline. Exact webhook retries and
     * unmatched-event replays share one event_key, so the unique key keeps the
     * stored timeline single-sourced while a replay attaches the order id.
     *
     * @param array<string, mixed> $details
     */
    private function recordSteadfastTrackingUpdate(array $details, string $orderId, string $eventKey): void
    {
        if (!$this->tableExists('courier_tracking_events')) {
            return;
        }
        $message = trim((string) ($details['trackingMessage'] ?? ''));
        if ($message === '') {
            return;
        }
        $consignmentId = trim((string) ($details['consignmentId'] ?? ''));
        $merchantReference = trim((string) ($details['merchantReference'] ?? ''));
        $id = $this->uuid4();
        $this->database->execute(
            "INSERT INTO courier_tracking_events (
                id, provider, event_key, order_id, consignment_id, merchant_reference,
                tracking_message, event_at, received_at, created_at, updated_at
             ) VALUES (
                :id, 'steadfast', :event_key, :order_id, :consignment_id, :merchant_reference,
                :tracking_message, :event_at, :received_at, :created_at, :updated_at
             )
             ON DUPLICATE KEY UPDATE
                order_id = COALESCE(VALUES(order_id), order_id),
                merchant_reference = COALESCE(VALUES(merchant_reference), merchant_reference),
                updated_at = VALUES(updated_at)",
            [
                ':id' => $id,
                ':event_key' => $eventKey,
                ':order_id' => $orderId,
                ':consignment_id' => $consignmentId !== '' ? $consignmentId : null,
                ':merchant_reference' => $merchantReference !== '' ? $merchantReference : null,
                ':tracking_message' => $message,
                ':event_at' => $details['eventAt'],
                ':received_at' => $this->database->nowUtc(),
                ':created_at' => $this->database->nowUtc(),
                ':updated_at' => $this->database->nowUtc(),
            ]
        );
    }

    /**
     * Courier tracking timeline for one order. Only Steadfast tracking_update
     * webhook messages are stored, oldest event first.
     *
     * @return array{data: array<int, array<string, mixed>>}
     */
    public function fetchCourierTrackingEvents(array $params): array
    {
        $this->currentUser();
        $orderId = trim((string) ($params['orderId'] ?? ''));
        if ($orderId === '') {
            throw new RuntimeException('Order id is required.');
        }
        if (!$this->tableExists('courier_tracking_events')) {
            return ['data' => []];
        }
        $rows = $this->database->fetchAll(
            "SELECT tracking_message, event_at, received_at
             FROM courier_tracking_events
             WHERE order_id = :order_id AND provider = 'steadfast'
               AND tracking_message IS NOT NULL AND tracking_message <> ''
             ORDER BY event_at ASC, received_at ASC, id ASC",
            [':order_id' => $orderId]
        );
        return [
            'data' => array_map(static function (array $row): array {
                return [
                    'trackingMessage' => (string) $row['tracking_message'],
                    'eventAt' => $row['event_at'] !== null ? (string) $row['event_at'] : null,
                    'receivedAt' => (string) $row['received_at'],
                ];
            }, $rows),
        ];
    }

    /** @param array<int, array<string, mixed>> $containers @param array<int, string> $keys */
    private function firstWebhookValue(array $containers, array $keys): string
    {
        foreach ($containers as $container) {
            foreach ($keys as $key) {
                if (isset($container[$key]) && is_scalar($container[$key])) {
                    $value = trim((string) $container[$key]);
                    if ($value !== '') {
                        return $value;
                    }
                }
            }
        }
        return '';
    }

    /** @param array<int, array<string, mixed>> $containers @param array<int, string> $keys */
    private function firstWebhookNumber(array $containers, array $keys): float
    {
        foreach ($containers as $container) {
            foreach ($keys as $key) {
                if (isset($container[$key]) && is_numeric($container[$key])) {
                    return max(0, (float) $container[$key]);
                }
            }
        }
        return 0.0;
    }

    private function mapWebhookStatus(string $provider, string $eventName, string $rawStatus): ?string
    {
        $event = strtolower(trim($eventName));
        $status = strtolower(trim($rawStatus));
        $combined = $event . ' ' . $status;

        if ($provider === 'carrybee') {
            return match ($event) {
                'order.picked' => 'Picked',
                'order.delivered', 'order.exchange' => 'Delivered',
                'order.partial_delivery', 'order.partial-delivery' => 'Partially Delivered',
                'order.returned', 'order.paid_return', 'order.paid-return' => 'Returned',
                'order.cancelled', 'order.canceled' => 'Cancelled',
                default => null,
            };
        }
        if ($provider === 'paperfly') {
            if (in_array($event, ['parcel.delivered', 'parcel.exchange'], true)) return 'Delivered';
            if ($event === 'parcel.partial') return 'Partially Delivered';
            if (in_array($event, ['parcel.return', 'parcel.return_to_merchant'], true)) return 'Returned';
            if ($event === 'parcel.cancelled') return 'Cancelled';
            if (in_array($event, [
                'parcel.picked_up', 'parcel.in_transit', 'parcel.received_at_point',
                'parcel.assigned_for_delivery', 'parcel.return_transit',
            ], true)) return 'Picked';
            return null;
        }
        if ($provider === 'steadfast' && $event === 'tracking_update') {
            // Tracking-only notifications have no status and must remain
            // reference data. A tracking_update carrying an explicit status,
            // however, is a real state transition and must be applied.
            $statusOnly = trim($status);
            if ($statusOnly === '' || $statusOnly === 'tracking_update') return null;
        }
        if ($provider === 'steadfast') {
            // Steadfast return_status notifications only mean the return flow
            // has started; they carry no status field and must never cancel
            // the order. The order is flagged action-required instead, and
            // real status transitions are applied only from delivery_status
            // notifications. Exact status mapping:
            //   delivered            → Delivered
            //   partial_delivered    → Partially Delivered
            //   pending              → Picked
            //   cancelled            → Returned
            // Everything else (e.g. in_review, delivered_approval_pending) is ignored.
            if ($event === 'return_status') return null;
            if ($status === 'cancelled') return 'Returned';
            if ($status === 'delivered') return 'Delivered';
            if ($status === 'partial_delivered') return 'Partially Delivered';
            if ($status === 'pending') return 'Picked';
            return null;
        }
        if ($provider === 'pathao' && preg_match('/paid[\\s._-]*return/', $combined) === 1) return 'Partially Delivered';
        if (str_contains($combined, 'cancel') || str_contains($combined, 'canceled')) return 'Cancelled';
        if (str_contains($combined, 'return')) return 'Returned';
        if (str_contains($combined, 'partial')) return 'Partially Delivered';
        if (
            str_contains($status, 'deliver')
            || preg_match('/(^|[._ -])delivered?($|[._ -])/', $event) === 1
        ) return 'Delivered';
        if (
            str_contains($combined, 'pick') || str_contains($combined, 'transit')
            || str_contains($combined, 'assigned') || str_contains($combined, 'out for delivery')
            || str_contains($combined, 'received at')
            || str_contains($combined, 'pending')
        ) return 'Picked';
        return null;
    }

    /** @return array<string, mixed>|null */
    private function findWebhookOrder(
        string $provider,
        string $consignmentId,
        string $merchantReference,
        string $eventName
    ): ?array {
        $columns = match ($provider) {
            'carrybee' => ['carrybee_consignment_id', 'exchange_carrybee_consignment_id'],
            'paperfly' => ['paperfly_tracking_number', 'exchange_paperfly_tracking_number'],
            'steadfast' => ['steadfast_consignment_id', 'exchange_steadfast_consignment_id'],
            'pathao' => ['pathao_consignment_id', 'exchange_pathao_consignment_id'],
        };
        $conditions = [];
        $bindings = [];
        if ($consignmentId !== '') {
            // A supplied consignment is the strongest identity. Never let a
            // reused/incorrect merchant reference select a different order.
            $exact = $this->database->fetchOne(
                'SELECT * FROM orders WHERE deleted_at IS NULL
                 AND (' . $columns[0] . ' = :consignment_main OR ' . $columns[1] . ' = :consignment_exchange)
                 ORDER BY created_at DESC LIMIT 1 FOR UPDATE',
                [':consignment_main' => $consignmentId, ':consignment_exchange' => $consignmentId]
            );
            if ($exact !== null) {
                $mainId = trim((string) ($exact[$columns[0]] ?? ''));
                $exchangeId = trim((string) ($exact[$columns[1]] ?? ''));
                $isExchange = $exchangeId === $consignmentId && $mainId !== $consignmentId;
                if (($provider === 'paperfly' && strtolower($eventName) === 'parcel.exchange')
                    || ($provider === 'carrybee' && strtolower($eventName) === 'order.exchange')
                ) {
                    $isExchange = true;
                }
                $exact['isExchange'] = $isExchange;
                return $exact;
            }
            // No exact consignment match: retain the event as unmatched until
            // the provider identifier is stored, rather than guessing.
            return null;
        }
        if ($merchantReference !== '') {
            $conditions[] = '(order_number = :merchant_order_number OR id = :merchant_order_id)';
            $bindings[':merchant_order_number'] = $merchantReference;
            $bindings[':merchant_order_id'] = $merchantReference;
        }
        if ($conditions === []) {
            return null;
        }

        $row = $this->database->fetchOne(
            'SELECT * FROM orders WHERE deleted_at IS NULL AND (' . implode(' OR ', $conditions) . ')
             ORDER BY created_at DESC LIMIT 1 FOR UPDATE',
            $bindings
        );
        if ($row === null) {
            return null;
        }
        $mainId = trim((string) ($row[$columns[0]] ?? ''));
        $exchangeId = trim((string) ($row[$columns[1]] ?? ''));
        $isExchange = $consignmentId !== '' && $exchangeId === $consignmentId && $mainId !== $consignmentId;
        if (($provider === 'paperfly' && strtolower($eventName) === 'parcel.exchange')
            || ($provider === 'carrybee' && strtolower($eventName) === 'order.exchange')
        ) {
            $isExchange = true;
        }
        $consignmentDidNotIdentifyMain = $consignmentId === '' || $mainId !== $consignmentId;
        if (
            !$isExchange
            && $consignmentDidNotIdentifyMain
            && $exchangeId !== ''
            && in_array((string) ($row['status'] ?? ''), ['Exchange processing', 'Exchange picked'], true)
        ) {
            $isExchange = true;
        }
        $row['isExchange'] = $isExchange;
        return $row;
    }

    /** @return array<string, mixed>|null */
    private function upsertWebhookCharge(
        string $provider,
        array $details,
        ?string $eventId,
        string $orderId
    ): ?array {
        $reference = $details['consignmentId'] !== '' ? $details['consignmentId'] : $details['merchantReference'];
        if ($reference === '') {
            return null;
        }
        // A provider may quote a fee using only the merchant reference, then
        // reveal the consignment number later. Claim that still-unassigned row
        // when the consignment arrives, but never merge two already identified
        // main/exchange consignments that share one merchant order reference.
        $existingCharge = null;
        if ($details['consignmentId'] !== '') {
            $conditions = ['consignment_id = :match_consignment'];
            $matchBindings = [
                ':match_provider' => $provider,
                ':match_consignment' => $details['consignmentId'],
                ':rank_consignment' => $details['consignmentId'],
            ];
            if ($details['merchantReference'] !== '') {
                $conditions[] = '(merchant_reference = :match_merchant AND consignment_id IS NULL)';
                $matchBindings[':match_merchant'] = $details['merchantReference'];
            }
            $existingCharge = $this->database->fetchOne(
                'SELECT * FROM courier_order_charges
                 WHERE provider = :match_provider AND (' . implode(' OR ', $conditions) . ')
                 ORDER BY CASE WHEN consignment_id = :rank_consignment THEN 0 ELSE 1 END,
                          created_at ASC, id ASC
                 LIMIT 1 FOR UPDATE',
                $matchBindings
            );
        } elseif ($details['merchantReference'] !== '') {
            $existingCharge = $this->database->fetchOne(
                'SELECT * FROM courier_order_charges
                 WHERE provider = :match_provider AND merchant_reference = :match_merchant
                 ORDER BY CASE WHEN consignment_id IS NULL THEN 0 ELSE 1 END,
                          created_at ASC, id ASC
                 LIMIT 1 FOR UPDATE',
                [
                    ':match_provider' => $provider,
                    ':match_merchant' => $details['merchantReference'],
                ]
            );
        }
        $chargeKey = trim((string) ($existingCharge['charge_key'] ?? ''));
        if ($chargeKey === '') {
            $chargeKey = hash('sha256', $provider . '|' . $reference);
        }
        $id = $this->uuid4();
        $this->database->execute(
            "INSERT INTO courier_order_charges (
                id, provider, charge_key, order_id, consignment_id, merchant_reference,
                cod_fee, delivery_fee, total_charge, collected_amount, currency, source_event_id,
                provider_updated_at, created_at, updated_at
             ) VALUES (
                :id, :provider, :charge_key, :order_id, :consignment_id, :merchant_reference,
                :cod_fee, :delivery_fee, :total_charge, :collected_amount, :currency, :source_event_id,
                :provider_updated_at, :created_at, :updated_at
             ) ON DUPLICATE KEY UPDATE
                order_id = COALESCE(VALUES(order_id), order_id),
                consignment_id = COALESCE(VALUES(consignment_id), consignment_id),
                merchant_reference = COALESCE(VALUES(merchant_reference), merchant_reference),
                cod_fee = IF(VALUES(cod_fee) > 0, VALUES(cod_fee), cod_fee),
                delivery_fee = IF(VALUES(delivery_fee) > 0, VALUES(delivery_fee), delivery_fee),
                total_charge = IF(VALUES(total_charge) > 0, VALUES(total_charge), total_charge),
                collected_amount = IF(VALUES(collected_amount) > 0, VALUES(collected_amount), collected_amount),
                currency = VALUES(currency),
                source_event_id = COALESCE(VALUES(source_event_id), source_event_id),
                provider_updated_at = COALESCE(VALUES(provider_updated_at), provider_updated_at),
                updated_at = VALUES(updated_at)",
            [
                ':id' => $id,
                ':provider' => $provider,
                ':charge_key' => $chargeKey,
                ':order_id' => $orderId !== '' ? $orderId : null,
                ':consignment_id' => $details['consignmentId'] !== '' ? $details['consignmentId'] : null,
                ':merchant_reference' => $details['merchantReference'] !== '' ? $details['merchantReference'] : null,
                ':cod_fee' => $this->formatMoney($details['codFee']),
                ':delivery_fee' => $this->formatMoney($details['deliveryFee']),
                ':total_charge' => $this->formatMoney($details['totalCharge']),
                ':collected_amount' => $this->formatMoney($details['collectedAmount']),
                ':currency' => $details['currency'],
                ':source_event_id' => $eventId !== null && $eventId !== '' ? $eventId : null,
                ':provider_updated_at' => $details['eventAt'],
                ':created_at' => $this->database->nowUtc(),
                ':updated_at' => $this->database->nowUtc(),
            ]
        );
        $this->database->execute(
            'UPDATE courier_order_charges
             SET total_charge = CASE
                 WHEN cod_fee > 0 OR delivery_fee > 0 THEN ROUND(cod_fee + delivery_fee, 2)
                 ELSE total_charge
             END
             WHERE provider = :provider AND charge_key = :charge_key',
            [':provider' => $provider, ':charge_key' => $chargeKey]
        );
        return $this->database->fetchOne(
            'SELECT * FROM courier_order_charges WHERE provider = :provider AND charge_key = :charge_key LIMIT 1 FOR UPDATE',
            [':provider' => $provider, ':charge_key' => $chargeKey]
        );
    }

    /**
     * Extract charge fields from a provider API status-poll response (not a
     * webhook). Mirrors webhookDetails semantics so polled and pushed money
     * follow one consistent rule: Steadfast reports cod_amount, all others
     * collected_amount, and fee keys use the same families.
     *
     * @return array<string, mixed>
     */
    private function syncChargeDetails(string $provider, array $data, string $consignmentId, string $merchantReference): array
    {
        $containers = [$data];
        if (is_array($data['data'] ?? null)) {
            $containers[] = $data['data'];
        }
        if (is_array($data['data']['data'] ?? null)) {
            $containers[] = $data['data']['data'];
        }

        $codFee = $this->firstWebhookNumber($containers, ['cod_fee', 'cod_charge', 'collection_charge', 'collection_fee']);
        $deliveryFee = $this->firstWebhookNumber($containers, ['delivery_fee', 'delivery_charge', 'shipping_fee', 'shipping_charge']);
        $directTotal = $this->firstWebhookNumber($containers, ['total_charge', 'courier_charge', 'shipping_cost']);
        $totalCharge = round($codFee + $deliveryFee, 2);
        if ($totalCharge <= 0 && $directTotal > 0) {
            $totalCharge = round($directTotal, 2);
        }

        $collectedAmount = 0.0;
        if ($provider === 'steadfast') {
            $collectedAmount = $this->firstWebhookNumber($containers, ['cod_amount']);
        } else {
            $collectedAmount = $this->firstWebhookNumber($containers, ['collected_amount']);
        }

        $eventAtRaw = $this->firstWebhookValue($containers, [
            'timestamptz', 'timestamp', 'updated_at', 'action_date_time', 'action_datetime', 'event_at',
        ]);
        $eventAt = null;
        if ($eventAtRaw !== '' && strtotime($eventAtRaw) !== false) {
            $eventAt = gmdate('Y-m-d H:i:s', (int) strtotime($eventAtRaw));
        }

        return [
            'eventName' => 'status.sync',
            'consignmentId' => $consignmentId,
            'merchantReference' => $merchantReference,
            'eventAt' => $eventAt,
            'codFee' => max(0, round($codFee, 2)),
            'deliveryFee' => max(0, round($deliveryFee, 2)),
            'totalCharge' => max(0, $totalCharge),
            'collectedAmount' => max(0, round($collectedAmount, 2)),
            'currency' => strtoupper($this->firstWebhookValue($containers, ['currency'])) ?: 'BDT',
            'rawStatus' => '',
            'mappedStatus' => null,
        ];
    }

    /**
     * Upsert the provider charge from a status-poll response and attach it to
     * the updates applied via updateOrderAsCourierSystem. Polling syncs then
     * book the same automatic expense/income the webhook path books: the row
     * merges with any webhook-created charge (one expense per consignment) and
     * terminal-transition income resolves the collected amount from it.
     *
     * @param array<string, mixed> $updates
     * @param float|null $collectedAmountOverride When non-null, forces the charge's collected_amount to this value (e.g. 0 for Steadfast cancels to prevent paid-return income booking).
     */
    private function attachSyncedCharge(array &$updates, string $provider, array $data, string $consignmentId, string $merchantReference, string $orderId, ?float $collectedAmountOverride = null): void
    {
        $details = $this->syncChargeDetails($provider, $data, $consignmentId, $merchantReference);
        if ($collectedAmountOverride !== null) {
            $details['collectedAmount'] = max(0.0, $collectedAmountOverride);
        }
        $charge = $this->upsertWebhookCharge($provider, $details, null, $orderId);
        if ($charge !== null && trim((string) ($charge['id'] ?? '')) !== '') {
            if ($collectedAmountOverride !== null) {
                $this->database->execute(
                    'UPDATE courier_order_charges SET collected_amount = :amount WHERE id = :id',
                    [':amount' => $this->formatMoney($collectedAmountOverride), ':id' => (string) $charge['id']]
                );
            }
            $updates['courierAutomaticExpense'] = [
                'chargeId' => trim((string) $charge['id']),
                'provider' => $provider,
                'recordedAt' => $details['eventAt'] ?? $this->database->nowUtc(),
            ];
        }
    }

    /**
     * Decide the target `orders.status` when a courier reports a "Delivered"
     * event. The order is staged into `pending_delivered` (with action
     * required) only when BOTH automation flags are on AND the previous
     * status is `Picked` — mirroring the manual finalise path in
     * `OperationsApi::completePickedOrder`. Otherwise the order completes
     * immediately so the webhook/polled payload's already-known shipping
     * fee + collected COD can post as automatic expense + income.
     *
     * @return array{status:string, delivery_action_required?:int, partial_delivered_at?:string, pendingDelivered:bool}
     */
    private function resolveDeliveredTargetStatus(string $previousStatus, string $recordedAt): array
    {
        $columns = 'automatically_deduct_shipping_costs';
        if ($this->columnExists('courier_settings', 'automatically_record_sales_income')) {
            $columns .= ', automatically_record_sales_income';
        }
        $row = $this->database->fetchOne(
            "SELECT {$columns} FROM courier_settings LIMIT 1"
        );
        $autoDeductShipping = (bool) ($row['automatically_deduct_shipping_costs'] ?? false);
        $autoRecordIncome = (bool) ($row['automatically_record_sales_income'] ?? false);

        if (
            $autoDeductShipping
            && $autoRecordIncome
            && $previousStatus === 'Picked'
        ) {
            return [
                'status' => 'pending_delivered',
                'delivery_action_required' => 1,
                'partial_delivered_at' => $recordedAt,
                'pendingDelivered' => true,
            ];
        }

        return ['status' => 'Completed', 'pendingDelivered' => false];
    }

    /** @return array<string, mixed> */
    private function buildWebhookOrderUpdates(string $provider, array $details, array $order, ?array $charge): array
    {
        $mapped = $details['mappedStatus'];
        $current = (string) ($order['status'] ?? '');
        if (
            $provider === 'pathao'
            && strtolower(trim((string) ($details['eventName'] ?? ''))) === 'order.updated'
            && $current === 'Courier assigned'
        ) {
            $mapped = 'Picked';
        }
        $isExchange = (bool) ($order['isExchange'] ?? false);
        $chargeId = trim((string) ($charge['id'] ?? ''));
        $terminal = ['Completed', 'Returned', 'Cancelled', 'Exchange delivered', 'partially_delivered', 'pending_partial'];
        $providerLabel = match ($provider) {
            'carrybee' => 'CarryBee',
            'paperfly' => 'Paperfly',
            'steadfast' => 'Steadfast',
            'pathao' => 'Pathao',
        };
        $when = (string) ($details['eventAt'] ?? $this->database->nowUtc());
        $raw = trim((string) ($details['rawStatus'] ?? $details['eventName']));
        $isSteadfastReturnNotice = $provider === 'steadfast'
            && strtolower(trim((string) ($details['eventName'] ?? ''))) === 'return_status';
        $updates = [];
        $history = is_array(json_decode((string) ($order['history'] ?? ''), true))
            ? json_decode((string) $order['history'], true)
            : [];

        if ($mapped !== null) {
            $mainEventDuringExchange = !$isExchange
                && in_array($current, ['Exchange processing', 'Exchange picked'], true);
            $delivered = $mapped === 'Delivered' && !$isExchange
                ? $this->resolveDeliveredTargetStatus($current, $when)
                : null;
            $target = match ($mapped) {
                'Delivered' => $isExchange
                    ? 'Exchange delivered'
                    : ($delivered['status'] ?? 'Completed'),
                'Partially Delivered' => $isExchange ? null : 'pending_partial',
                'Returned' => $isExchange ? null : 'Returned',
                'Cancelled' => $isExchange ? null : 'Cancelled',
                'Picked' => $isExchange ? 'Exchange picked' : 'Picked',
                default => null,
            };
            if (
                $target !== null
                && !$mainEventDuringExchange
                && (!in_array($current, $terminal, true) || $current === $target)
            ) {
                if ($current !== $target) {
                    $updates['status'] = $target;
                    // An authoritative status transition resolves any pending
                    // Steadfast return notice.
                    $updates['courier_return_action_required'] = 0;
                    if ($target === 'pending_delivered') {
                        $updates['delivery_action_required'] = 1;
                        $updates['partial_delivered_at'] = $when;
                    } elseif ($current === 'pending_delivered' && $target === 'Completed') {
                        // A second delivered webhook while pending confirmation
                        // clears the action flag so the order leaves
                        // "action required" reports.
                        $updates['delivery_action_required'] = 0;
                    }
                    if ($mapped === 'Delivered') {
                        $key = $isExchange ? 'exchangeDelivered' : 'completed';
                        $history[$key] = sprintf(
                            'Marked delivered automatically from %s webhook event "%s" on %s.',
                            $providerLabel,
                            $raw,
                            $when
                        );
                    } elseif ($mapped === 'Partially Delivered') {
                        $history['partiallyDelivered'] = sprintf(
                            'Marked partially delivered automatically from %s webhook event "%s" on %s. Action required to confirm delivered items.',
                            $providerLabel,
                            $raw,
                            $when
                        );
                        $updates['partial_delivery_action_required'] = 1;
                        $updates['partial_delivered_at'] = $when;
                        $updates['partial_cod_amount'] = round((float) ($details['collectedAmount'] ?? 0), 2);
                        $updates['partial_shipping_amount'] = round((float) ($details['deliveryFee'] ?? 0), 2);
                        // Calculate total COGS from order items for deferred recording
                        $orderItems = is_array(json_decode((string) ($order['items'] ?? '[]'), true))
                            ? json_decode((string) ($order['items'] ?? '[]'), true)
                            : [];
                        $totalCogs = 0.0;
                        foreach ($orderItems as $oi) {
                            if (!is_array($oi)) continue;
                            $qty = max(0, (float) ($oi['quantity'] ?? 0));
                            $pid = trim((string) ($oi['productId'] ?? ''));
                            if ($qty <= 0 || $pid === '') continue;
                            $prod = $this->database->fetchOne('SELECT purchase_price FROM products WHERE id = :id LIMIT 1', [':id' => $pid]);
                            $totalCogs += round(max(0.0, (float) ($prod['purchase_price'] ?? 0)) * $qty, 2);
                        }
                        $updates['partial_cogs_amount'] = round($totalCogs, 2);
                    } elseif ($mapped === 'Returned') {
                        $history['returned'] = sprintf(
                            'Marked returned automatically from %s webhook event "%s" on %s.',
                            $providerLabel,
                            $raw,
                            $when
                        );
                    } elseif ($mapped === 'Cancelled') {
                        $history['cancelled'] = sprintf(
                            'Marked cancelled automatically from %s webhook event "%s" on %s.',
                            $providerLabel,
                            $raw,
                            $when
                        );
                    } else {
                        $key = $isExchange ? 'exchangePicked' : 'picked';
                        $history[$key] = $history[$key] ?? sprintf(
                            'Marked picked automatically from %s webhook event "%s" on %s.',
                            $providerLabel,
                            $raw,
                            $when
                        );
                    }
                    $updates['history'] = $history;
                }
            } elseif ($isExchange && in_array($mapped, ['Returned', 'Cancelled'], true)) {
                $history['exchangeCourier'] = trim((string) ($history['exchangeCourier'] ?? ''))
                    . sprintf(' | Exchange returned/cancelled from %s webhook event "%s" on %s.', $providerLabel, $raw, $when);
                $updates['history'] = $history;
            }
        }

        if ($mapped === null && $isSteadfastReturnNotice && !in_array($current, $terminal, true)) {
            // The return notice is not a status transition: the parcel may not
            // actually be returned yet. Flag the order action-required so the
            // merchant reviews it instead of silently cancelling.
            $updates['courier_return_action_required'] = 1;
            $history['courierReturn'] = trim((string) ($history['courierReturn'] ?? ''))
                . sprintf(' | Steadfast return notice "%s" received on %s. Action required to review the return.', $raw, $when);
            $updates['history'] = $history;
        }

        $effectiveTarget = (string) ($updates['status'] ?? $current);
        if ($chargeId !== '') {
            // Attach the charge for every matched event (even fee-less ones):
            // income resolves the collected amount from this triggering charge,
            // and the expense recorder skips rows whose total is zero.
            $updates['courierAutomaticExpense'] = [
                'chargeId' => $chargeId,
                'provider' => $provider,
                'recordedAt' => $details['eventAt'] ?? $this->database->nowUtc(),
            ];
        }
        return $updates;
    }

    /**
     * Whether raw courier webhook events should be persisted in
     * courier_webhook_events. Developer-controlled; defaults to enabled even
     * before the 2026-08-16_webhook_event_logging migration has run.
     */
    private function webhookSavingEnabled(): bool
    {
        if (!$this->tableExists('courier_settings')) {
            return true;
        }
        $row = $this->database->fetchOne('SELECT save_webhook_events FROM courier_settings LIMIT 1');
        $value = $row['save_webhook_events'] ?? null;
        if ($value === null) {
            return true;
        }
        return (bool) $value;
    }

    private function requireDeveloperUser(): array
    {
        $user = $this->currentUser();
        if (trim((string) ($user['role'] ?? '')) !== 'Developer') {
            throw new ApiException('Developer access required.', 403, 'DEVELOPER_ACCESS_REQUIRED');
        }
        return $user;
    }

    private function webhookPageSize(array $params): int
    {
        $pageSize = (int) ($params['pageSize'] ?? 25);
        return min(100, max(1, $pageSize === 0 ? 25 : $pageSize));
    }

    private function webhookPageOffset(array $params): int
    {
        $page = max(1, (int) ($params['page'] ?? 1));
        return ($page - 1) * $this->webhookPageSize($params);
    }

    /** @param array<string, mixed>|null $filter */
    private function appendWebhookLikeFilter(string &$where, array &$bindings, string $key, ?array $filter, string $column): void
    {
        if (!is_array($filter)) {
            return;
        }
        $value = trim((string) ($filter['value'] ?? ''));
        if ($value === '') {
            return;
        }
        $operator = trim((string) ($filter['operator'] ?? 'contains'));
        $placeholder = ':' . $key . '_value';
        if (in_array($operator, ['=', '≠', 'is', 'is not', 'not'], true)) {
            $match = $column . ' = ' . $placeholder;
        } elseif (in_array($operator, ['does not contain', 'not contains'], true)) {
            $match = '(COALESCE(' . $column . ", '') NOT LIKE CONCAT('%', " . $placeholder . ", '%'))";
        } else {
            $match = $column . ' LIKE CONCAT(\'%\', ' . $placeholder . ', \'%\')';
        }
        $bindings[$placeholder] = $value;
        $where .= ' AND ' . $match;
    }

    /**
     * Developer-only: paginated list of stored courier webhook events with the
     * matched order visible alongside each raw payload.
     *
     * @return array<string, mixed>
     */
    public function fetchWebhookEventsPage(array $params): array
    {
        $this->requireDeveloperUser();
        if (!$this->tableExists('courier_webhook_events')) {
            return ['data' => [], 'count' => 0, 'savingEnabled' => true, 'options' => ['providers' => [], 'eventNames' => [], 'processingStatuses' => []]];
        }

        $filters = is_array($params['filters'] ?? null) ? $params['filters'] : [];
        $dynamicFilters = is_array($params['dynamicFilters'] ?? null) ? $params['dynamicFilters'] : [];
        $where = 'WHERE 1 = 1';
        $bindings = [];

        $provider = strtolower(trim((string) ($filters['provider'] ?? '')));
        if ($provider !== '') {
            $where .= ' AND e.provider = :provider';
            $bindings[':provider'] = $provider;
        }
        $processingStatus = strtolower(trim((string) ($filters['processingStatus'] ?? '')));
        if ($processingStatus !== '') {
            $where .= ' AND e.processing_status = :processing_status';
            $bindings[':processing_status'] = $processingStatus;
        }
        $dateFrom = trim((string) ($filters['dateFrom'] ?? ''));
        if ($dateFrom !== '') {
            $where .= ' AND e.received_at >= :date_from';
            $bindings[':date_from'] = $dateFrom;
        }
        $dateTo = trim((string) ($filters['dateTo'] ?? ''));
        if ($dateTo !== '') {
            $where .= ' AND e.received_at <= :date_to';
            $bindings[':date_to'] = $dateTo;
        }
        $search = trim((string) ($filters['search'] ?? ''));
        if ($search !== '') {
            $where .= ' AND (e.consignment_id LIKE :search_consignment OR e.merchant_reference LIKE :search_merchant OR e.event_name LIKE :search_event OR o.order_number LIKE :search_order)';
            $searchValue = '%' . $search . '%';
            $bindings[':search_consignment'] = $searchValue;
            $bindings[':search_merchant'] = $searchValue;
            $bindings[':search_event'] = $searchValue;
            $bindings[':search_order'] = $searchValue;
        }

        $providerNot = strtolower(trim((string) ($dynamicFilters['providerNot'] ?? '')));
        if ($providerNot !== '') {
            $where .= ' AND e.provider <> :provider_not';
            $bindings[':provider_not'] = $providerNot;
        }
        $processingStatusNot = strtolower(trim((string) ($dynamicFilters['processingStatusNot'] ?? '')));
        if ($processingStatusNot !== '') {
            $where .= ' AND e.processing_status <> :processing_status_not';
            $bindings[':processing_status_not'] = $processingStatusNot;
        }
        foreach (['eventName' => 'e.event_name', 'consignmentId' => 'e.consignment_id', 'merchantReference' => 'e.merchant_reference'] as $filterKey => $column) {
            $this->appendWebhookLikeFilter($where, $bindings, $filterKey, $dynamicFilters[$filterKey] ?? null, $column);
        }
        $orderFilter = $dynamicFilters['orderId'] ?? null;
        if (is_array($orderFilter)) {
            $value = trim((string) ($orderFilter['value'] ?? ''));
            if ($value !== '') {
                $operator = trim((string) ($orderFilter['operator'] ?? '='));
                $like = in_array($operator, ['contains', 'does not contain'], true);
                $orderValue = $like ? '%' . $value . '%' : $value;
                $bindings[':order_value_number'] = $orderValue;
                $bindings[':order_value_id'] = $orderValue;
                if ($operator === 'does not contain') {
                    $where .= ' AND (o.order_number NOT LIKE :order_value_number AND (e.order_id IS NULL OR e.order_id NOT LIKE :order_value_id))';
                } elseif ($operator === '≠') {
                    $where .= ' AND (o.order_number <> :order_value_number AND (e.order_id IS NULL OR e.order_id <> :order_value_id))';
                } elseif ($operator === 'contains') {
                    $where .= ' AND (o.order_number LIKE :order_value_number OR e.order_id LIKE :order_value_id)';
                } else {
                    $where .= ' AND (o.order_number = :order_value_number OR e.order_id = :order_value_id)';
                }
            }
        }
        $receivedOn = trim((string) ($dynamicFilters['receivedOn'] ?? ''));
        if ($receivedOn !== '') {
            $where .= ' AND DATE(e.received_at) = :received_on';
            $bindings[':received_on'] = $receivedOn;
        }
        $receivedBefore = trim((string) ($dynamicFilters['receivedBefore'] ?? ''));
        if ($receivedBefore !== '') {
            $where .= ' AND e.received_at < :received_before';
            $bindings[':received_before'] = $receivedBefore . ' 23:59:59';
        }
        $receivedAfter = trim((string) ($dynamicFilters['receivedAfter'] ?? ''));
        if ($receivedAfter !== '') {
            $where .= ' AND e.received_at >= :received_after';
            $bindings[':received_after'] = $receivedAfter . ' 00:00:00';
        }

        $pageSize = $this->webhookPageSize($params);
        $offset = $this->webhookPageOffset($params);

        $sql = "SELECT e.id, e.provider, e.event_name, e.order_id, e.merchant_reference, e.consignment_id,
                       e.event_at, e.received_at, e.processing_status, e.processing_message,
                       o.order_number, o.status AS order_status
                FROM courier_webhook_events e
                LEFT JOIN orders o ON o.id = e.order_id
                {$where}
                ORDER BY e.received_at DESC, e.id DESC
                LIMIT {$pageSize} OFFSET {$offset}";
        $rows = $this->database->fetchAll($sql, $bindings);

        $countRow = $this->database->fetchOne(
            "SELECT COUNT(*) AS cnt
             FROM courier_webhook_events e
             LEFT JOIN orders o ON o.id = e.order_id
             {$where}",
            $bindings
        );

        $eventNames = array_map(
            static fn(array $row): string => (string) $row['event_name'],
            $this->database->fetchAll(
                "SELECT DISTINCT event_name FROM courier_webhook_events WHERE event_name <> '' ORDER BY event_name ASC"
            )
        );

        return [
            'data' => array_map(static function (array $row): array {
                return [
                    'id' => (string) $row['id'],
                    'provider' => (string) $row['provider'],
                    'eventName' => (string) $row['event_name'],
                    'orderId' => $row['order_id'] !== null ? (string) $row['order_id'] : '',
                    'orderNumber' => $row['order_number'] !== null ? (string) $row['order_number'] : '',
                    'orderStatus' => $row['order_status'] !== null ? (string) $row['order_status'] : '',
                    'merchantReference' => $row['merchant_reference'] !== null ? (string) $row['merchant_reference'] : '',
                    'consignmentId' => $row['consignment_id'] !== null ? (string) $row['consignment_id'] : '',
                    'eventAt' => $row['event_at'] ?? null,
                    'receivedAt' => (string) $row['received_at'],
                    'processingStatus' => (string) $row['processing_status'],
                    'processingMessage' => $row['processing_message'] !== null ? (string) $row['processing_message'] : '',
                ];
            }, $rows),
            'count' => (int) ($countRow['cnt'] ?? 0),
            'savingEnabled' => $this->webhookSavingEnabled(),
            'options' => [
                'providers' => ['carrybee', 'paperfly', 'steadfast', 'pathao'],
                'eventNames' => $eventNames,
                'processingStatuses' => ['received', 'processed', 'unmatched'],
            ],
        ];
    }

    /**
     * Developer-only: one stored webhook event with its decoded raw JSON
     * payload plus the matched order and any linked courier charges.
     *
     * @return array<string, mixed>
     */
    public function fetchWebhookEventDetail(array $params): array
    {
        $this->requireDeveloperUser();
        $id = trim((string) ($params['id'] ?? ''));
        if ($id === '') {
            throw new RuntimeException('Webhook event id is required.');
        }
        if (!$this->tableExists('courier_webhook_events')) {
            throw new RuntimeException('Courier webhook database upgrade has not been applied.');
        }
        $row = $this->database->fetchOne(
            'SELECT * FROM courier_webhook_events WHERE id = :id LIMIT 1',
            [':id' => $id]
        );
        if ($row === null) {
            throw new RuntimeException('Webhook event not found.');
        }

        $payloadRaw = (string) ($row['payload'] ?? '');
        $payload = json_decode($payloadRaw, true);
        $payload = is_array($payload) ? $payload : $payloadRaw;

        $orderId = trim((string) ($row['order_id'] ?? ''));
        $order = null;
        $charges = [];
        if ($orderId !== '') {
            $orderRow = $this->database->fetchOne(
                'SELECT id, order_number, status, total, paid_amount FROM orders WHERE id = :id LIMIT 1',
                [':id' => $orderId]
            );
            if ($orderRow !== null) {
                $order = [
                    'id' => (string) $orderRow['id'],
                    'orderNumber' => (string) $orderRow['order_number'],
                    'status' => (string) $orderRow['status'],
                    'total' => (float) $orderRow['total'],
                    'paidAmount' => (float) $orderRow['paid_amount'],
                ];
            }
            $chargeRows = $this->database->fetchAll(
                'SELECT provider, consignment_id, cod_fee, delivery_fee, total_charge, collected_amount,
                        expense_status, expense_transaction_id, source_event_id
                 FROM courier_order_charges
                 WHERE order_id = :order_id
                 ORDER BY created_at ASC, id ASC',
                [':order_id' => $orderId]
            );
            $charges = array_map(static function (array $charge): array {
                return [
                    'provider' => (string) $charge['provider'],
                    'consignmentId' => $charge['consignment_id'] !== null ? (string) $charge['consignment_id'] : '',
                    'codFee' => (float) $charge['cod_fee'],
                    'deliveryFee' => (float) $charge['delivery_fee'],
                    'totalCharge' => (float) $charge['total_charge'],
                    'collectedAmount' => (float) $charge['collected_amount'],
                    'expenseStatus' => (string) $charge['expense_status'],
                    'expenseTransactionId' => $charge['expense_transaction_id'] !== null ? (string) $charge['expense_transaction_id'] : '',
                    'sourceEventId' => $charge['source_event_id'] !== null ? (string) $charge['source_event_id'] : '',
                ];
            }, $chargeRows);
        }

        return [
            'event' => [
                'id' => (string) $row['id'],
                'provider' => (string) $row['provider'],
                'eventKey' => (string) $row['event_key'],
                'eventName' => (string) $row['event_name'],
                'merchantReference' => $row['merchant_reference'] !== null ? (string) $row['merchant_reference'] : '',
                'consignmentId' => $row['consignment_id'] !== null ? (string) $row['consignment_id'] : '',
                'eventAt' => $row['event_at'] ?? null,
                'receivedAt' => (string) $row['received_at'],
                'processedAt' => $row['processed_at'] !== null ? (string) $row['processed_at'] : '',
                'processingStatus' => (string) $row['processing_status'],
                'processingMessage' => $row['processing_message'] !== null ? (string) $row['processing_message'] : '',
                'payload' => $payload,
            ],
            'order' => $order,
            'charges' => $charges,
        ];
    }

    /**
     * Developer-only: toggle whether raw webhook events are persisted. While
     * disabled, webhooks are still processed (status changes, charges,
     * expenses, income) but no event row is stored.
     *
     * @return array{savingEnabled: bool}
     */
    public function setWebhookSavingEnabled(array $params): array
    {
        $this->requireDeveloperUser();
        $enabled = (bool) ($params['enabled'] ?? false);
        $this->saveSingleton(
            'courier_settings',
            'courier-default',
            ['save_webhook_events' => $enabled ? 1 : 0],
            fn(): array => ['savingEnabled' => $enabled]
        );
        return ['savingEnabled' => $enabled];
    }

    private function finishWebhookEvent(string $eventId, string $status, string $message, ?string $orderId): void
    {
        $this->database->execute(
            'UPDATE courier_webhook_events
             SET order_id = :order_id, processing_status = :processing_status,
                 processing_message = :processing_message, processed_at = :processed_at
             WHERE id = :id',
            [
                ':order_id' => $orderId,
                ':processing_status' => $status,
                ':processing_message' => $message,
                ':processed_at' => $this->database->nowUtc(),
                ':id' => $eventId,
            ]
        );
    }

    /**
     * Quietly save settings without requiring admin auth (used for token persistence during sync).
     */
    private function saveSingletonQuiet(string $table, string $id, array $updates): void
    {
        $existing = $this->database->fetchOne("SELECT id FROM {$table} WHERE id = ?", [$id]);
        if ($existing === null) {
            $columns = array_keys($updates);
            $columns[] = 'id';
            $placeholders = array_fill(0, count($columns), '?');
            $sql = "INSERT INTO {$table} (" . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')';
            $values = array_values($updates);
            $values[] = $id;
            $this->database->execute($sql, $values);
        } else {
            $setClauses = [];
            $values = [];
            foreach ($updates as $column => $value) {
                $setClauses[] = "{$column} = ?";
                $values[] = $value;
            }
            $sql = "UPDATE {$table} SET " . implode(', ', $setClauses) . ' WHERE id = ?';
            $values[] = $id;
            $this->database->execute($sql, $values);
        }
    }
}
