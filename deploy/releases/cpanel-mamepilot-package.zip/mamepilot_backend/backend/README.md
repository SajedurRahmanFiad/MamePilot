# MariaDB + PHP Backend

## What this does

- Creates the local MariaDB schema used by the app
- Provides a PHP API that replaces the former Supabase query/edge-function layer
- Includes a Supabase-to-MariaDB importer
- Includes a bootstrap admin creator for emergency/local access

## Commands

- `php backend/bin/repair_employee_order_credits.php`
  Reconciles employee commission credits against current payroll settings and order statuses in one transaction, then reports any credits or reversals added. Back up the database before running it after a commission-calculation fix.

- `npm run backend:setup`
  Creates `bdhatbela_management` and applies [`schema.sql`](/f:/Projects/React/BDHATBELA-MANAGEMENT-FINAL/backend/database/schema.sql)

- `npm run backend:setup-import`
  Runs setup, then attempts a live import from Supabase

- `npm run backend:import`
  Attempts a live import from Supabase into the existing MariaDB schema

- `npm run backend:serve`
  Starts the PHP API on `http://127.0.0.1:8001`

- `php backend/bin/create_admin.php --name="Admin" --phone="017XXXXXXXX" --password="secret"`
  Creates a local admin account when a live import is unavailable

## Frontend

- Vite proxies `/api` to `http://127.0.0.1:8001`
- The React app now calls the PHP API through [`apiClient.ts`](/f:/Projects/React/BDHATBELA-MANAGEMENT-FINAL/src/services/apiClient.ts)

## Environment

The backend config loader reads:

- project `.env`
- project `.env.local`
- `backend/.env`
- `backend/.env.local`

For local MariaDB, the defaults already match:

- host `127.0.0.1`
- port `3306`
- database `bdhatbela_management`
- user `root`
- password empty

## External Data API

The scoped integration API exposes paginated reads for orders, customers, transactions, bills, vendors, and accounts at `/api/v1`. Separate create, update, and delete scopes are available for orders, customers, bills, and vendors; transactions and accounts remain read-only. Integration keys are revocable and require `APP_API_KEY_PEPPER` to be configured in the backend environment.

See [docs/EXTERNAL_DATA_API.md](../docs/EXTERNAL_DATA_API.md) for the full filter catalog, authentication setup, pagination and incremental-sync behavior. The machine-readable contract is [docs/external-data-api.openapi.yaml](../docs/external-data-api.openapi.yaml).
