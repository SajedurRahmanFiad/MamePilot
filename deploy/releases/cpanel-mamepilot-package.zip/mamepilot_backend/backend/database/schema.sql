-- MamePilot pure schema file.
-- Safe for fresh installs and repeated production updates.
-- This file must not contain INSERT/seed data.

SET NAMES utf8mb4;
SET time_zone = '+00:00';
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(64) NOT NULL,
  role VARCHAR(32) NOT NULL,
  is_system TINYINT(1) NOT NULL DEFAULT 0,
  image LONGTEXT NULL,
  email VARCHAR(255) NULL,
  address TEXT NULL,
  birthday DATE NULL,
  nid_passport_copy LONGTEXT NULL,
  gender VARCHAR(32) NULL,
  blood_group VARCHAR(16) NULL,
  nationality VARCHAR(128) NULL,
  cv LONGTEXT NULL,
  is_commission_based TINYINT(1) NOT NULL DEFAULT 0,
  fixed_salary DECIMAL(12,2) NULL,
  password_hash VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_phone (phone),
  KEY idx_users_role (role),
  KEY idx_users_created_at (created_at),
  KEY idx_users_deleted_at (deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS customers (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(64) NOT NULL,
  address TEXT NULL,
  total_orders INT NOT NULL DEFAULT 0,
  due_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  fraud_check_result LONGTEXT NULL,
  fraud_check_percentage DECIMAL(5,2) NULL,
  fraud_check_phone VARCHAR(64) NULL,
  fraud_checked_at DATETIME NULL,
  created_by VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  KEY idx_customers_name (name),
  KEY idx_customers_phone (phone),
  KEY idx_customers_created_by (created_by),
  KEY idx_customers_created_at (created_at),
  KEY idx_customers_deleted_at (deleted_at),
  KEY idx_customers_deleted_created_at (deleted_at, created_at),
  CONSTRAINT fk_customers_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT fk_customers_deleted_by FOREIGN KEY (deleted_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS fraud_check_result LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS fraud_check_percentage DECIMAL(5,2) NULL,
  ADD COLUMN IF NOT EXISTS fraud_check_phone VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS fraud_checked_at DATETIME NULL;
CREATE TABLE IF NOT EXISTS vendors (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(64) NOT NULL,
  address TEXT NULL,
  total_purchases INT NOT NULL DEFAULT 0,
  due_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_by VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  KEY idx_vendors_name (name),
  KEY idx_vendors_phone (phone),
  KEY idx_vendors_created_by (created_by),
  KEY idx_vendors_created_at (created_at),
  KEY idx_vendors_deleted_at (deleted_at),
  KEY idx_vendors_deleted_created_at (deleted_at, created_at),
  CONSTRAINT fk_vendors_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT fk_vendors_deleted_by FOREIGN KEY (deleted_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS units (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(100) NOT NULL,
  short_name VARCHAR(32) NOT NULL,
  description TEXT NULL,
  is_fraction TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_units_name (name),
  UNIQUE KEY uq_units_short_name (short_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NULL,
  sku VARCHAR(191) NULL,
  image LONGTEXT NULL,
  category VARCHAR(255) NULL,
  unit_id VARCHAR(64) NULL,
  sale_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  purchase_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  stock INT NOT NULL DEFAULT 0,
  dynamic_pricing LONGTEXT NULL,
  created_by VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_products_slug (slug),
  UNIQUE KEY uq_products_sku (sku),
  KEY idx_products_name (name),
  KEY idx_products_category (category),
  KEY idx_products_created_by (created_by),
  KEY idx_products_created_at (created_at),
  KEY idx_products_deleted_at (deleted_at),
  KEY idx_products_deleted_created_at (deleted_at, created_at),
  CONSTRAINT fk_products_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT fk_products_deleted_by FOREIGN KEY (deleted_by) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT fk_products_unit_id FOREIGN KEY (unit_id) REFERENCES units (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Upgrade compatibility for the v0.0.52 product-unit feature. Keep this in
-- schema.sql so the release that upgrades the updater itself also repairs
-- existing databases while that process is still running the old PHP class.
ALTER TABLE `units`
  ADD COLUMN IF NOT EXISTS `is_fraction` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `products`
  ADD COLUMN IF NOT EXISTS `slug` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `unit_id` VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS `dynamic_pricing` LONGTEXT NULL;
SET @mamepilot_product_unit_fk_sql = (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
      WHERE CONSTRAINT_SCHEMA = DATABASE()
        AND TABLE_NAME = 'products'
        AND CONSTRAINT_NAME = 'fk_products_unit_id'
        AND CONSTRAINT_TYPE = 'FOREIGN KEY'
    ),
    'SET @mamepilot_product_unit_fk_noop = 1',
    'ALTER TABLE `products` ADD CONSTRAINT `fk_products_unit_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE SET NULL'
  )
);
PREPARE mamepilot_product_unit_fk_stmt FROM @mamepilot_product_unit_fk_sql;
EXECUTE mamepilot_product_unit_fk_stmt;
DEALLOCATE PREPARE mamepilot_product_unit_fk_stmt;
CREATE TABLE IF NOT EXISTS accounts (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(32) NOT NULL,
  opening_balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  current_balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_accounts_name (name),
  KEY idx_accounts_type (type),
  KEY idx_accounts_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS categories (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(32) NOT NULL,
  color VARCHAR(16) NOT NULL DEFAULT '#3B82F6',
  parent_id VARCHAR(64) NULL,
  is_system BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categories_name_type (name, type),
  KEY idx_categories_type (type),
  KEY idx_categories_parent_id (parent_id),
  CONSTRAINT fk_categories_parent_id FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS payment_methods (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_payment_methods_name (name),
  KEY idx_payment_methods_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS company_settings (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL DEFAULT 'MamePilot',
  phone VARCHAR(64) NULL,
  email VARCHAR(255) NULL,
  address TEXT NULL,
  logo LONGTEXT NULL,
  pages LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS order_settings (
  id VARCHAR(64) NOT NULL,
  prefix VARCHAR(32) NOT NULL DEFAULT 'ORD-',
  next_number BIGINT NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS invoice_settings (
  id VARCHAR(64) NOT NULL,
  title VARCHAR(255) NOT NULL DEFAULT 'Invoice',
  logo_width INT NOT NULL DEFAULT 120,
  logo_height INT NOT NULL DEFAULT 120,
  footer TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS system_defaults (
  id VARCHAR(64) NOT NULL,
  default_account_id VARCHAR(64) NULL,
  default_payment_method VARCHAR(255) NULL,
  income_category_id VARCHAR(64) NULL,
  expense_category_id VARCHAR(64) NULL,
  records_per_page INT NOT NULL DEFAULT 10,
  max_transaction_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  white_label TINYINT(1) NOT NULL DEFAULT 0,
  theme_color VARCHAR(32) NOT NULL DEFAULT '#0f2f57',
  automatic_fraud_check_on_order_creation TINYINT(1) NOT NULL DEFAULT 0,
  low_stock_threshold INT NOT NULL DEFAULT 10,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_system_defaults_account FOREIGN KEY (default_account_id) REFERENCES accounts (id) ON DELETE SET NULL,
  CONSTRAINT fk_system_defaults_income_category FOREIGN KEY (income_category_id) REFERENCES categories (id) ON DELETE SET NULL,
  CONSTRAINT fk_system_defaults_expense_category FOREIGN KEY (expense_category_id) REFERENCES categories (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Upgrade compatibility for existing databases (no IF NOT EXISTS for MySQL <8.0.29 compat)
ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `email` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `address` TEXT NULL,
  ADD COLUMN IF NOT EXISTS `birthday` DATE NULL,
  ADD COLUMN IF NOT EXISTS `nid_passport_copy` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `gender` VARCHAR(32) NULL,
  ADD COLUMN IF NOT EXISTS `blood_group` VARCHAR(16) NULL,
  ADD COLUMN IF NOT EXISTS `nationality` VARCHAR(128) NULL,
  ADD COLUMN IF NOT EXISTS `cv` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `is_commission_based` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `fixed_salary` DECIMAL(12,2) NULL;
ALTER TABLE `system_defaults`
  ADD COLUMN IF NOT EXISTS `white_label` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `theme_color` VARCHAR(32) NOT NULL DEFAULT '#0f2f57',
  ADD COLUMN IF NOT EXISTS `automatic_fraud_check_on_order_creation` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `low_stock_threshold` INT NOT NULL DEFAULT 10;
CREATE TABLE IF NOT EXISTS courier_settings (
  id VARCHAR(64) NOT NULL,
  steadfast_enabled TINYINT(1) NOT NULL DEFAULT 0,
  steadfast_base_url VARCHAR(255) NULL,
  steadfast_api_key VARCHAR(500) NULL,
  steadfast_secret_key VARCHAR(500) NULL,
  steadfast_invoice VARCHAR(100) NULL,
  carrybee_enabled TINYINT(1) NOT NULL DEFAULT 0,
  carrybee_base_url VARCHAR(255) NULL,
  carrybee_client_id VARCHAR(255) NULL,
  carrybee_client_secret VARCHAR(500) NULL,
  carrybee_client_context VARCHAR(255) NULL,
  carrybee_store_id VARCHAR(255) NULL,
  paperfly_base_url VARCHAR(255) NULL,
  paperfly_username VARCHAR(255) NULL,
  paperfly_password VARCHAR(500) NULL,
  paperfly_key VARCHAR(500) NULL,
  paperfly_default_shop_name VARCHAR(255) NULL,
  paperfly_max_weight_kg DECIMAL(10,3) NOT NULL DEFAULT 0.300,
  fraud_checker_provider VARCHAR(32) NOT NULL DEFAULT 'bdcourier',
  fraud_checker_api_key VARCHAR(500) NULL,
  fraudspy_api_key VARCHAR(500) NULL,
  pathao_enabled TINYINT(1) NOT NULL DEFAULT 0,
  pathao_base_url VARCHAR(255) NULL,
  pathao_client_id VARCHAR(255) NULL,
  pathao_client_secret VARCHAR(500) NULL,
  pathao_username VARCHAR(255) NULL,
  pathao_password VARCHAR(500) NULL,
  pathao_store_id VARCHAR(255) NULL,
  pathao_default_quantity INT NOT NULL DEFAULT 1,
  pathao_default_weight DECIMAL(10,2) NOT NULL DEFAULT 1.00,
  pathao_default_delivery_type INT NOT NULL DEFAULT 48,
  pathao_default_item_type INT NOT NULL DEFAULT 2,
  pathao_access_token TEXT NULL,
  pathao_refresh_token TEXT NULL,
  pathao_token_expires_at VARCHAR(64) NULL,
  automatically_deduct_shipping_costs TINYINT(1) NOT NULL DEFAULT 0,
  automatically_mark_paid_after_delivery TINYINT(1) NOT NULL DEFAULT 0,
  save_webhook_events TINYINT(1) NOT NULL DEFAULT 1,
  carrybee_webhook_signature VARCHAR(500) NULL,
  carrybee_webhook_header VARCHAR(128) NULL,
  carrybee_webhook_integration_header VARCHAR(128) NULL,
  carrybee_webhook_integration_value VARCHAR(500) NULL,
  paperfly_webhook_secret VARCHAR(500) NULL,
  pathao_webhook_header VARCHAR(128) NULL,
  pathao_webhook_secret VARCHAR(500) NULL,
  pathao_merchant_webhook_secret VARCHAR(500) NULL,
  steadfast_default_account_id VARCHAR(64) NULL,
  steadfast_default_expense_category_id VARCHAR(64) NULL,
  steadfast_default_income_category_id VARCHAR(64) NULL,
  steadfast_default_payment_method VARCHAR(255) NULL,
  carrybee_default_account_id VARCHAR(64) NULL,
  carrybee_default_expense_category_id VARCHAR(64) NULL,
  carrybee_default_income_category_id VARCHAR(64) NULL,
  carrybee_default_payment_method VARCHAR(255) NULL,
  paperfly_default_account_id VARCHAR(64) NULL,
  paperfly_default_expense_category_id VARCHAR(64) NULL,
  paperfly_default_income_category_id VARCHAR(64) NULL,
  paperfly_default_payment_method VARCHAR(255) NULL,
  pathao_default_account_id VARCHAR(64) NULL,
  pathao_default_expense_category_id VARCHAR(64) NULL,
  pathao_default_income_category_id VARCHAR(64) NULL,
  pathao_default_payment_method VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `courier_settings`
  ADD COLUMN IF NOT EXISTS `pathao_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `pathao_base_url` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_client_id` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_client_secret` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_username` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_password` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_store_id` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_default_quantity` INT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `pathao_default_weight` DECIMAL(10,2) NOT NULL DEFAULT 1.00,
  ADD COLUMN IF NOT EXISTS `pathao_default_delivery_type` INT NOT NULL DEFAULT 48,
  ADD COLUMN IF NOT EXISTS `pathao_default_item_type` INT NOT NULL DEFAULT 2,
  ADD COLUMN IF NOT EXISTS `pathao_access_token` TEXT NULL,
  ADD COLUMN IF NOT EXISTS `pathao_refresh_token` TEXT NULL,
  ADD COLUMN IF NOT EXISTS `pathao_token_expires_at` VARCHAR(64) NULL;
ALTER TABLE `courier_settings`
  ADD COLUMN IF NOT EXISTS `automatically_deduct_shipping_costs` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `automatically_mark_paid_after_delivery` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `save_webhook_events` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `steadfast_invoice` VARCHAR(100) NULL,
  ADD COLUMN IF NOT EXISTS `carrybee_webhook_signature` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `carrybee_webhook_header` VARCHAR(128) NULL,
  ADD COLUMN IF NOT EXISTS `carrybee_webhook_integration_header` VARCHAR(128) NULL,
  ADD COLUMN IF NOT EXISTS `carrybee_webhook_integration_value` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `paperfly_webhook_secret` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_webhook_header` VARCHAR(128) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_webhook_secret` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `pathao_merchant_webhook_secret` VARCHAR(500) NULL;
CREATE TABLE IF NOT EXISTS role_permissions (
  role_name VARCHAR(64) NOT NULL,
  permissions LONGTEXT NULL,
  is_custom TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (role_name),
  KEY idx_role_permissions_is_custom (is_custom)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS app_capability_settings (
  id VARCHAR(64) NOT NULL,
  capabilities LONGTEXT NULL,
  client_name VARCHAR(255) NULL,
  license_key VARCHAR(255) NULL,
  license_api_url VARCHAR(500) NULL,
  license_owner_token VARCHAR(500) NULL,
  tier_key VARCHAR(64) NULL,
  plan_name VARCHAR(255) NULL,
  license_status VARCHAR(64) NOT NULL DEFAULT 'local',
  renewal_date DATETIME NULL,
  override_enabled TINYINT(1) NOT NULL DEFAULT 0,
  show_inactive_subscription_features TINYINT(1) NOT NULL DEFAULT 1,
  maintenance_enabled TINYINT(1) NOT NULL DEFAULT 0,
  maintenance_image_url VARCHAR(1000) NULL,
  maintenance_caption VARCHAR(500) NULL,
  maintenance_subtitle TEXT NULL,
  maintenance_explanation TEXT NULL,
  maintenance_ends_at DATETIME NULL,
  available_tiers LONGTEXT NULL,
  pricing_metadata LONGTEXT NULL,
  last_synced_at DATETIME NULL,
  last_sync_status VARCHAR(64) NULL,
  last_sync_message TEXT NULL,
  sync_grace_until DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `app_capability_settings`
  ADD COLUMN IF NOT EXISTS `client_name` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `license_owner_token` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `tier_key` VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS `override_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `show_inactive_subscription_features` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `maintenance_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `maintenance_image_url` VARCHAR(1000) NULL,
  ADD COLUMN IF NOT EXISTS `maintenance_caption` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `maintenance_subtitle` TEXT NULL,
  ADD COLUMN IF NOT EXISTS `maintenance_explanation` TEXT NULL,
  ADD COLUMN IF NOT EXISTS `maintenance_ends_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `available_tiers` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `pricing_metadata` LONGTEXT NULL;
CREATE TABLE IF NOT EXISTS payment_gateway_settings (
  id VARCHAR(64) NOT NULL,
  piprapay_base_url VARCHAR(500) NULL,
  piprapay_api_key VARCHAR(500) NULL,
  piprapay_merchant_id VARCHAR(255) NULL,
  piprapay_ipn_secret VARCHAR(500) NULL,
  piprapay_webhook_url VARCHAR(1000) NULL,
  piprapay_return_url VARCHAR(1000) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS agent_settings (
  id VARCHAR(64) NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  main_provider VARCHAR(32) NOT NULL DEFAULT 'anthropic',
  anthropic_enabled TINYINT(1) NOT NULL DEFAULT 0,
  anthropic_base_url VARCHAR(500) NULL,
  anthropic_api_key VARCHAR(500) NULL,
  anthropic_model VARCHAR(255) NULL,
  anthropic_organization VARCHAR(255) NULL,
  anthropic_project VARCHAR(255) NULL,
  openai_enabled TINYINT(1) NOT NULL DEFAULT 0,
  openai_base_url VARCHAR(500) NULL,
  openai_api_key VARCHAR(500) NULL,
  openai_model VARCHAR(255) NULL,
  openai_organization VARCHAR(255) NULL,
  openai_project VARCHAR(255) NULL,
  google_enabled TINYINT(1) NOT NULL DEFAULT 0,
  google_base_url VARCHAR(500) NULL,
  google_api_key VARCHAR(500) NULL,
  google_model VARCHAR(255) NULL,
  google_organization VARCHAR(255) NULL,
  google_project VARCHAR(255) NULL,
  groq_enabled TINYINT(1) NOT NULL DEFAULT 0,
  groq_base_url VARCHAR(500) NULL,
  groq_api_key VARCHAR(500) NULL,
  groq_model VARCHAR(255) NULL,
  show_reasoning_summaries TINYINT(1) NOT NULL DEFAULT 1,
  show_tool_activity TINYINT(1) NOT NULL DEFAULT 1,
  max_reasoning_steps INT NOT NULL DEFAULT 8,
  max_tool_calls INT NOT NULL DEFAULT 12,
  query_row_limit INT NOT NULL DEFAULT 100,
  query_timeout_ms INT NOT NULL DEFAULT 15000,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS agent_conversations (
  id VARCHAR(64) NOT NULL,
  user_id VARCHAR(64) NOT NULL,
  title VARCHAR(255) NOT NULL DEFAULT 'New conversation',
  status VARCHAR(32) NOT NULL DEFAULT 'active',
  last_message_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_agent_conversations_user_id (user_id),
  KEY idx_agent_conversations_last_message_at (last_message_at),
  CONSTRAINT fk_agent_conversations_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS agent_runs (
  id VARCHAR(64) NOT NULL,
  conversation_id VARCHAR(64) NOT NULL,
  user_id VARCHAR(64) NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'queued',
  main_provider VARCHAR(32) NULL,
  main_model VARCHAR(255) NULL,
  deterministic_provider VARCHAR(32) NULL,
  deterministic_model VARCHAR(255) NULL,
  current_step INT NOT NULL DEFAULT 0,
  max_steps INT NOT NULL DEFAULT 0,
  stream_token VARCHAR(128) NULL,
  error_message TEXT NULL,
  started_at DATETIME NULL,
  finished_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_agent_runs_conversation_id (conversation_id),
  KEY idx_agent_runs_user_id (user_id),
  KEY idx_agent_runs_status (status),
  KEY idx_agent_runs_stream_token (stream_token),
  CONSTRAINT fk_agent_runs_conversation_id FOREIGN KEY (conversation_id) REFERENCES agent_conversations (id) ON DELETE CASCADE,
  CONSTRAINT fk_agent_runs_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS agent_messages (
  id VARCHAR(64) NOT NULL,
  conversation_id VARCHAR(64) NOT NULL,
  run_id VARCHAR(64) NULL,
  role VARCHAR(16) NOT NULL,
  content LONGTEXT NULL,
  reasoning_summary LONGTEXT NULL,
  metadata_json LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_agent_messages_conversation_id (conversation_id),
  KEY idx_agent_messages_run_id (run_id),
  KEY idx_agent_messages_created_at (created_at),
  CONSTRAINT fk_agent_messages_conversation_id FOREIGN KEY (conversation_id) REFERENCES agent_conversations (id) ON DELETE CASCADE,
  CONSTRAINT fk_agent_messages_run_id FOREIGN KEY (run_id) REFERENCES agent_runs (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS agent_run_events (
  id VARCHAR(64) NOT NULL,
  run_id VARCHAR(64) NOT NULL,
  event_type VARCHAR(64) NOT NULL,
  sequence_no INT NOT NULL,
  payload_json LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_agent_run_events_run_id (run_id),
  KEY idx_agent_run_events_sequence_no (sequence_no),
  CONSTRAINT fk_agent_run_events_run_id FOREIGN KEY (run_id) REFERENCES agent_runs (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS agent_tool_calls (
  id VARCHAR(64) NOT NULL,
  run_id VARCHAR(64) NOT NULL,
  step_no INT NOT NULL DEFAULT 0,
  tool_name VARCHAR(64) NOT NULL,
  tool_input_json LONGTEXT NULL,
  tool_result_json LONGTEXT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'pending',
  duration_ms INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_agent_tool_calls_run_id (run_id),
  KEY idx_agent_tool_calls_step_no (step_no),
  CONSTRAINT fk_agent_tool_calls_run_id FOREIGN KEY (run_id) REFERENCES agent_runs (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS agent_db_query_audit (
  id VARCHAR(64) NOT NULL,
  run_id VARCHAR(64) NULL,
  tool_call_id VARCHAR(64) NULL,
  user_id VARCHAR(64) NOT NULL,
  sql_text LONGTEXT NOT NULL,
  normalized_sql LONGTEXT NULL,
  row_count INT NOT NULL DEFAULT 0,
  duration_ms INT NOT NULL DEFAULT 0,
  safety_flags_json LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_agent_db_query_audit_run_id (run_id),
  KEY idx_agent_db_query_audit_tool_call_id (tool_call_id),
  KEY idx_agent_db_query_audit_user_id (user_id),
  CONSTRAINT fk_agent_db_query_audit_run_id FOREIGN KEY (run_id) REFERENCES agent_runs (id) ON DELETE SET NULL,
  CONSTRAINT fk_agent_db_query_audit_tool_call_id FOREIGN KEY (tool_call_id) REFERENCES agent_tool_calls (id) ON DELETE SET NULL,
  CONSTRAINT fk_agent_db_query_audit_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `payment_gateway_settings`
  ADD COLUMN IF NOT EXISTS `piprapay_base_url` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `piprapay_api_key` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `piprapay_merchant_id` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `piprapay_ipn_secret` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `piprapay_webhook_url` VARCHAR(1000) NULL,
  ADD COLUMN IF NOT EXISTS `piprapay_return_url` VARCHAR(1000) NULL;
ALTER TABLE `agent_settings`
  ADD COLUMN IF NOT EXISTS `enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `main_provider` VARCHAR(32) NOT NULL DEFAULT 'anthropic',
  ADD COLUMN IF NOT EXISTS `anthropic_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `anthropic_base_url` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `anthropic_api_key` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `anthropic_model` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `anthropic_organization` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `anthropic_project` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `openai_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `openai_base_url` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `openai_api_key` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `openai_model` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `openai_organization` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `openai_project` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `google_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `google_base_url` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `google_api_key` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `google_model` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `google_organization` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `google_project` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `groq_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `groq_base_url` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `groq_api_key` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `groq_model` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `show_reasoning_summaries` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `show_tool_activity` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `max_reasoning_steps` INT NOT NULL DEFAULT 8,
  ADD COLUMN IF NOT EXISTS `max_tool_calls` INT NOT NULL DEFAULT 12,
  ADD COLUMN IF NOT EXISTS `query_row_limit` INT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `query_timeout_ms` INT NOT NULL DEFAULT 15000;
CREATE TABLE IF NOT EXISTS notifications (
  id VARCHAR(64) NOT NULL,
  system_key VARCHAR(191) NULL,
  subject VARCHAR(255) NOT NULL,
  content_html LONGTEXT NOT NULL,
  target_roles LONGTEXT NOT NULL,
  starts_at DATETIME NULL,
  ends_at DATETIME NULL,
  action_config LONGTEXT NULL,
  metadata LONGTEXT NULL,
  created_by VARCHAR(64) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  is_system_generated TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_notifications_system_key (system_key),
  KEY idx_notifications_active_window (is_active, starts_at, ends_at),
  KEY idx_notifications_created_by (created_by),
  KEY idx_notifications_created_at (created_at),
  CONSTRAINT fk_notifications_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS notification_receipts (
  notification_id VARCHAR(64) NOT NULL,
  user_id VARCHAR(64) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  read_at DATETIME NULL,
  action_result VARCHAR(32) NULL,
  acted_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (notification_id, user_id),
  KEY idx_notification_receipts_user_read (user_id, is_read, read_at),
  KEY idx_notification_receipts_action_result (action_result),
  CONSTRAINT fk_notification_receipts_notification FOREIGN KEY (notification_id) REFERENCES notifications (id) ON DELETE CASCADE,
  CONSTRAINT fk_notification_receipts_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS service_subscription_settings (
  id VARCHAR(64) NOT NULL,
  plan_name VARCHAR(255) NULL,
  billing_interval VARCHAR(32) NULL,
  subscription_status VARCHAR(64) NOT NULL DEFAULT 'unconfigured',
  current_period_end DATETIME NULL,
  due_at DATETIME NULL,
  reset_day_of_month TINYINT UNSIGNED NULL,
  reset_time_of_day TIME NULL,
  warning_days INT NOT NULL DEFAULT 7,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  nagad_number VARCHAR(64) NULL,
  billing_version INT NOT NULL DEFAULT 1,
  created_by VARCHAR(64) NULL,
  updated_by VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_service_subscription_settings_due_at (due_at),
  CONSTRAINT fk_service_subscription_settings_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT fk_service_subscription_settings_updated_by FOREIGN KEY (updated_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `service_subscription_settings`
  ADD COLUMN IF NOT EXISTS `plan_name` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `billing_interval` VARCHAR(32) NULL,
  ADD COLUMN IF NOT EXISTS `subscription_status` VARCHAR(64) NOT NULL DEFAULT 'unconfigured',
  ADD COLUMN IF NOT EXISTS `current_period_end` DATETIME NULL;
CREATE TABLE IF NOT EXISTS service_subscription_items (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT NULL,
  amount DECIMAL(12,2) NULL,
  is_optional TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  display_order INT NOT NULL DEFAULT 0,
  system_key VARCHAR(191) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_service_subscription_items_system_key (system_key),
  KEY idx_service_subscription_items_active_order (is_active, display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS service_subscription_methods (
  id VARCHAR(64) NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  display_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_service_subscription_methods_active_order (is_active, display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS service_subscription_payments (
  id VARCHAR(64) NOT NULL,
  billing_version INT NOT NULL,
  local_reference VARCHAR(255) NULL,
  gateway_payment_id VARCHAR(255) NULL,
  gateway_name VARCHAR(64) NULL,
  billing_interval VARCHAR(32) NULL,
  invoice_url VARCHAR(500) NULL,
  raw_payload LONGTEXT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  base_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  tip_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  payment_method_id VARCHAR(64) NULL,
  payment_method_name VARCHAR(255) NOT NULL,
  transaction_id VARCHAR(255) NOT NULL,
  submitted_by VARCHAR(64) NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'processing',
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reactivate_at DATETIME NULL,
  processed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_service_subscription_payments_version_tx (billing_version, transaction_id),
  KEY idx_service_subscription_payments_status_ready (status, reactivate_at),
  KEY idx_service_subscription_payments_billing_version (billing_version, submitted_at),
  KEY idx_service_subscription_payments_submitted_by (submitted_by),
  CONSTRAINT fk_service_subscription_payments_method FOREIGN KEY (payment_method_id) REFERENCES service_subscription_methods (id) ON DELETE SET NULL,
  CONSTRAINT fk_service_subscription_payments_submitted_by FOREIGN KEY (submitted_by) REFERENCES users (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `service_subscription_payments`
  ADD COLUMN IF NOT EXISTS `local_reference` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `gateway_payment_id` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `gateway_name` VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS `billing_interval` VARCHAR(32) NULL,
  ADD COLUMN IF NOT EXISTS `invoice_url` VARCHAR(500) NULL,
  ADD COLUMN IF NOT EXISTS `raw_payload` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `transaction_id` VARCHAR(255) NULL;
CREATE TABLE IF NOT EXISTS payment_webhook_logs (
  id VARCHAR(64) NOT NULL,
  gateway VARCHAR(64) NOT NULL,
  event_id VARCHAR(255) NULL,
  local_reference VARCHAR(255) NULL,
  status VARCHAR(64) NULL,
  verified TINYINT(1) NOT NULL DEFAULT 0,
  raw_payload LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_payment_webhook_logs_gateway_event (gateway, event_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS payroll_settings (
  id VARCHAR(64) NOT NULL,
  singleton TINYINT(1) NOT NULL DEFAULT 1,
  unit_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  counted_statuses LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_payroll_settings_singleton (singleton)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(64) NOT NULL,
  order_number VARCHAR(100) NOT NULL,
  order_seq BIGINT NULL,
  order_date DATE NOT NULL,
  customer_id VARCHAR(64) NOT NULL,
  page_id VARCHAR(64) NULL,
  created_by VARCHAR(64) NOT NULL,
  status VARCHAR(32) NOT NULL,
  items LONGTEXT NULL,
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  discount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  shipping DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes TEXT NULL,
  history LONGTEXT NULL,
  page_snapshot LONGTEXT NULL,
  carrybee_consignment_id VARCHAR(255) NULL,
  steadfast_consignment_id VARCHAR(255) NULL,
  steadfast_invoice VARCHAR(100) NULL,
  steadfast_tracking_link VARCHAR(1000) NULL,
  paperfly_tracking_number VARCHAR(255) NULL,
  pathao_consignment_id VARCHAR(255) NULL,
  exchange_courier VARCHAR(32) NULL,
  exchange_steadfast_consignment_id VARCHAR(255) NULL,
  exchange_carrybee_consignment_id VARCHAR(255) NULL,
  exchange_paperfly_tracking_number VARCHAR(255) NULL,
  exchange_pathao_consignment_id VARCHAR(255) NULL,
  exchange_courier_history TEXT NULL,
  source_ad VARCHAR(64) NULL,
  processed_at DATETIME NULL,
  courier_assigned_at DATETIME NULL,
  picked_at DATETIME NULL,
  completed_at DATETIME NULL,
  returned_at DATETIME NULL,
  cancelled_at DATETIME NULL,
  partial_delivered_at DATETIME NULL,
  partial_delivery_action_required TINYINT(1) NOT NULL DEFAULT 0,
  partial_cogs_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  partial_shipping_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  partial_cod_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  exchange_processing_at DATETIME NULL,
  exchange_picked_at DATETIME NULL,
  exchange_delivered_at DATETIME NULL,
  exchange_returned_at DATETIME NULL,
  exchange_cancelled_at DATETIME NULL,
  survey_id VARCHAR(64) NULL,
  survey_status VARCHAR(32) NULL DEFAULT NULL,
  survey_response VARCHAR(16) NULL,
  survey_call_status VARCHAR(32) NULL,
  survey_duration_seconds INT NOT NULL DEFAULT 0,
  survey_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  confirmation_status VARCHAR(32) NULL,
  survey_result_fetch_at DATETIME NULL,
  survey_next_retry_at DATETIME NULL,
  survey_retry_count INT NOT NULL DEFAULT 0,
  survey_last_retry_reason VARCHAR(32) NULL,
  survey_last_retry_at DATETIME NULL,
  survey_triggered_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_orders_order_number (order_number),
  UNIQUE KEY uq_orders_order_seq (order_seq),
  UNIQUE KEY uq_orders_steadfast_invoice (steadfast_invoice),
  KEY idx_orders_customer_id (customer_id),
  KEY idx_orders_page_id (page_id),
  KEY idx_orders_created_by (created_by),
  KEY idx_orders_status_created_at (status, created_at),
  KEY idx_orders_order_date_created_at (order_date, created_at),
  KEY idx_orders_deleted_created_at (deleted_at, created_at),
  KEY idx_orders_deleted_status_created_at (deleted_at, status, created_at),
  KEY idx_orders_deleted_created_by_created_at (deleted_at, created_by, created_at),
  KEY idx_orders_carrybee_consignment_id (carrybee_consignment_id),
  KEY idx_orders_steadfast_consignment_id (steadfast_consignment_id),
  KEY idx_orders_paperfly_tracking_number (paperfly_tracking_number),
  KEY idx_orders_pathao_consignment_id (pathao_consignment_id),
  KEY idx_orders_survey_status (survey_status),
  KEY idx_orders_processed_at (processed_at),
  KEY idx_orders_courier_assigned_at (courier_assigned_at),
  KEY idx_orders_picked_at (picked_at),
  KEY idx_orders_completed_at (completed_at),
  KEY idx_orders_returned_at (returned_at),
  KEY idx_orders_cancelled_at (cancelled_at),
  KEY idx_orders_partial_delivered_at (partial_delivered_at),
  KEY idx_orders_exchange_processing_at (exchange_processing_at),
  KEY idx_orders_exchange_picked_at (exchange_picked_at),
  KEY idx_orders_exchange_delivered_at (exchange_delivered_at),
  KEY idx_orders_exchange_returned_at (exchange_returned_at),
  KEY idx_orders_exchange_cancelled_at (exchange_cancelled_at),
  KEY idx_orders_confirmation_status (confirmation_status),
  KEY idx_orders_survey_next_retry_at (survey_next_retry_at),
  KEY idx_orders_deleted_at (deleted_at),
  CONSTRAINT fk_orders_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
  CONSTRAINT fk_orders_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT,
  CONSTRAINT fk_orders_deleted_by FOREIGN KEY (deleted_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS voice_survey_settings (
  id VARCHAR(64) NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  delay_minutes INT NOT NULL DEFAULT 5,
  api_token TEXT NULL,
  sender VARCHAR(64) NULL,
  template_name VARCHAR(191) NULL,
  webhook_secret VARCHAR(255) NULL,
  webhook_url VARCHAR(1000) NULL,
  balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  pulse_seconds INT NOT NULL DEFAULT 60,
  taka_per_pulse DECIMAL(12,4) NOT NULL DEFAULT 0.5500,
  recharge_notification_enabled TINYINT(1) NOT NULL DEFAULT 1,
  max_survey_time_seconds INT NOT NULL DEFAULT 120,
  missed_call_retry_minutes INT NOT NULL DEFAULT 30,
  missed_call_retry_count INT NOT NULL DEFAULT 3,
  no_key_retry_minutes INT NOT NULL DEFAULT 10,
  no_key_retry_count INT NOT NULL DEFAULT 2,
  trigger_statuses TEXT NULL,
  cron_last_run DATETIME NULL,
  cron_last_success_at DATETIME NULL,
  cron_last_error TEXT NULL,
  cron_last_processed_count INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS voice_survey_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_id VARCHAR(64) NOT NULL,
  survey_id VARCHAR(64) NULL,
  event_type VARCHAR(32) NOT NULL,
  call_status VARCHAR(32) NULL,
  response VARCHAR(32) NULL,
  details TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_voice_survey_events_order_created (order_id, created_at),
  KEY idx_voice_survey_events_survey_id (survey_id),
  CONSTRAINT fk_voice_survey_events_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS woocommerce_stores (
  id VARCHAR(64) NOT NULL,
  store_name VARCHAR(191) NOT NULL,
  store_url VARCHAR(500) NOT NULL,
  consumer_key VARCHAR(255) NULL,
  consumer_secret VARCHAR(255) NULL,
  webhook_secret VARCHAR(255) NULL,
  webhook_base_url VARCHAR(1000) NULL,
  webhook_id BIGINT NULL,
  company_page_id VARCHAR(64) NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  last_synced_at DATETIME NULL,
  last_sync_status VARCHAR(32) NULL,
  last_sync_message VARCHAR(1000) NULL,
  orders_synced INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_woocommerce_stores_enabled (enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS woocommerce_order_links (
  id VARCHAR(64) NOT NULL,
  store_id VARCHAR(64) NOT NULL,
  wc_order_id BIGINT NOT NULL,
  wc_order_number VARCHAR(64) NULL,
  order_id VARCHAR(64) NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'imported',
  message VARCHAR(1000) NULL,
  payload_hash VARCHAR(64) NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_wc_order_links_store_order (store_id, wc_order_id),
  KEY idx_wc_order_links_store_created (store_id, created_at),
  CONSTRAINT fk_wc_order_links_store FOREIGN KEY (store_id) REFERENCES woocommerce_stores(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS woocommerce_product_links (
  id VARCHAR(64) NOT NULL,
  store_id VARCHAR(64) NOT NULL,
  wc_product_id BIGINT NOT NULL,
  wc_variation_id BIGINT NOT NULL DEFAULT 0,
  sku VARCHAR(191) NULL,
  product_id VARCHAR(64) NOT NULL,
  auto_created TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_wc_product_links_remote (store_id, wc_product_id, wc_variation_id),
  KEY idx_wc_product_links_product (product_id),
  CONSTRAINT fk_wc_product_links_store FOREIGN KEY (store_id) REFERENCES woocommerce_stores(id) ON DELETE CASCADE,
  CONSTRAINT fk_wc_product_links_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS shopify_stores (
  id VARCHAR(64) NOT NULL,
  store_name VARCHAR(191) NOT NULL,
  store_url VARCHAR(500) NOT NULL,
  access_token VARCHAR(255) NULL,
  api_secret VARCHAR(255) NULL,
  webhook_secret VARCHAR(255) NULL,
  webhook_base_url VARCHAR(1000) NULL,
  webhook_id VARCHAR(255) NULL,
  company_page_id VARCHAR(64) NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  last_synced_at DATETIME NULL,
  last_products_synced_at DATETIME NULL,
  last_orders_synced_at DATETIME NULL,
  last_sync_status VARCHAR(32) NULL,
  last_sync_message VARCHAR(1000) NULL,
  products_synced INT NOT NULL DEFAULT 0,
  orders_synced INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_shopify_stores_enabled (enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS shopify_order_links (
  id VARCHAR(64) NOT NULL,
  store_id VARCHAR(64) NOT NULL,
  shopify_order_id VARCHAR(255) NOT NULL,
  shopify_order_number VARCHAR(64) NULL,
  dedupe_key VARCHAR(191) NULL,
  order_id VARCHAR(64) NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'imported',
  message VARCHAR(1000) NULL,
  payload_hash VARCHAR(64) NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_shopify_order_links_store_order (store_id, shopify_order_id),
  UNIQUE KEY uq_shopify_order_links_store_dedupe (store_id, dedupe_key),
  KEY idx_shopify_order_links_store_created (store_id, created_at),
  CONSTRAINT fk_shopify_order_links_store FOREIGN KEY (store_id) REFERENCES shopify_stores(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS shopify_product_links (
  id VARCHAR(64) NOT NULL,
  store_id VARCHAR(64) NOT NULL,
  shopify_product_id VARCHAR(255) NOT NULL,
  shopify_variant_id VARCHAR(255) NOT NULL DEFAULT '0',
  sku VARCHAR(191) NULL,
  product_id VARCHAR(64) NOT NULL,
  auto_created TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_shopify_product_links_remote (store_id, shopify_product_id, shopify_variant_id),
  KEY idx_shopify_product_links_product (product_id),
  CONSTRAINT fk_shopify_product_links_store FOREIGN KEY (store_id) REFERENCES shopify_stores(id) ON DELETE CASCADE,
  CONSTRAINT fk_shopify_product_links_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS shopify_webhook_subscriptions (
  id VARCHAR(64) NOT NULL,
  store_id VARCHAR(64) NOT NULL,
  topic VARCHAR(64) NOT NULL,
  remote_id VARCHAR(255) NOT NULL,
  uri VARCHAR(1000) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_shopify_webhook_subscriptions_store_topic (store_id, topic),
  UNIQUE KEY uq_shopify_webhook_subscriptions_remote (store_id, remote_id),
  KEY idx_shopify_webhook_subscriptions_store (store_id),
  CONSTRAINT fk_shopify_webhook_subscriptions_store FOREIGN KEY (store_id) REFERENCES shopify_stores(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS shopify_webhook_events (
  id VARCHAR(64) NOT NULL,
  store_id VARCHAR(64) NOT NULL,
  webhook_id VARCHAR(255) NOT NULL,
  event_id VARCHAR(255) NULL,
  topic VARCHAR(64) NOT NULL,
  resource_id VARCHAR(255) NULL,
  payload_hash VARCHAR(64) NOT NULL,
  payload LONGTEXT NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'processing',
  message VARCHAR(1000) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_shopify_webhook_events_store_webhook (store_id, webhook_id),
  KEY idx_shopify_webhook_events_status_created (status, created_at),
  CONSTRAINT fk_shopify_webhook_events_store FOREIGN KEY (store_id) REFERENCES shopify_stores(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS bills (
  id VARCHAR(64) NOT NULL,
  bill_number VARCHAR(100) NOT NULL,
  bill_seq BIGINT NULL,
  bill_date DATE NOT NULL,
  vendor_id VARCHAR(64) NOT NULL,
  created_by VARCHAR(64) NOT NULL,
  status VARCHAR(32) NOT NULL,
  items LONGTEXT NULL,
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  discount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  shipping DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  notes TEXT NULL,
  history LONGTEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_bills_bill_number (bill_number),
  UNIQUE KEY uq_bills_bill_seq (bill_seq),
  KEY idx_bills_vendor_id (vendor_id),
  KEY idx_bills_created_by (created_by),
  KEY idx_bills_status_created_at (status, created_at),
  KEY idx_bills_bill_date_created_at (bill_date, created_at),
  KEY idx_bills_deleted_created_at (deleted_at, created_at),
  KEY idx_bills_deleted_created_by_created_at (deleted_at, created_by, created_at),
  KEY idx_bills_deleted_at (deleted_at),
  CONSTRAINT fk_bills_vendor_id FOREIGN KEY (vendor_id) REFERENCES vendors (id) ON DELETE RESTRICT,
  CONSTRAINT fk_bills_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT,
  CONSTRAINT fk_bills_deleted_by FOREIGN KEY (deleted_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS transactions (
  id VARCHAR(64) NOT NULL,
  date DATETIME NOT NULL,
  type VARCHAR(32) NOT NULL,
  category VARCHAR(255) NOT NULL,
  account_id VARCHAR(64) NOT NULL,
  transaction_id VARCHAR(255) NULL,
  account_name VARCHAR(255) NULL,
  to_account_id VARCHAR(64) NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  description TEXT NOT NULL,
  reference_id VARCHAR(64) NULL,
  contact_id VARCHAR(64) NULL,
  payment_method VARCHAR(255) NOT NULL,
  attachment_name TEXT NULL,
  attachment_url LONGTEXT NULL,
  created_by VARCHAR(64) NOT NULL,
  history LONGTEXT NULL,
  approval_status VARCHAR(32) NOT NULL DEFAULT 'approved',
  account_effect_applied TINYINT(1) NOT NULL DEFAULT 1,
  approval_requested_by VARCHAR(64) NULL,
  approval_requested_at DATETIME NULL,
  approved_by VARCHAR(64) NULL,
  approved_at DATETIME NULL,
  declined_by VARCHAR(64) NULL,
  declined_at DATETIME NULL,
  approval_note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  KEY idx_transactions_account_id (account_id),
  KEY idx_transactions_to_account_id (to_account_id),
  KEY idx_transactions_created_by (created_by),
  KEY idx_transactions_type_created_at (type, created_at),
  KEY idx_transactions_date_created_at (date, created_at),
  KEY idx_transactions_deleted_created_at (deleted_at, created_at),
  KEY idx_transactions_deleted_created_by_created_at (deleted_at, created_by, created_at),
  KEY idx_transactions_deleted_type_created_at (deleted_at, type, created_at),
  KEY idx_transactions_deleted_approval_status_created_at (deleted_at, approval_status, created_at),
  KEY idx_transactions_reference_id (reference_id),
  KEY idx_transactions_contact_id (contact_id),
  KEY idx_transactions_deleted_at (deleted_at),
  CONSTRAINT fk_transactions_account_id FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
  CONSTRAINT fk_transactions_to_account_id FOREIGN KEY (to_account_id) REFERENCES accounts (id) ON DELETE SET NULL,
  CONSTRAINT fk_transactions_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT,
  CONSTRAINT fk_transactions_deleted_by FOREIGN KEY (deleted_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `transactions`
  ADD COLUMN IF NOT EXISTS `transaction_id` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `account_name` VARCHAR(255) NULL;
CREATE TABLE IF NOT EXISTS `courier_webhook_events` (
  id VARCHAR(64) NOT NULL,
  provider VARCHAR(32) NOT NULL,
  event_key CHAR(64) NOT NULL,
  event_name VARCHAR(128) NOT NULL,
  order_id VARCHAR(64) NULL,
  merchant_reference VARCHAR(255) NULL,
  consignment_id VARCHAR(255) NULL,
  event_at DATETIME NULL,
  payload LONGTEXT NOT NULL,
  processing_status VARCHAR(32) NOT NULL DEFAULT 'received',
  processing_message TEXT NULL,
  received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_courier_webhook_provider_event (provider, event_key),
  KEY idx_courier_webhook_order_received (order_id, received_at),
  KEY idx_courier_webhook_provider_received (provider, received_at),
  KEY idx_courier_webhook_unmatched_retry (provider, processing_status, processed_at),
  CONSTRAINT fk_courier_webhook_order FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `courier_order_charges` (
  id VARCHAR(64) NOT NULL,
  provider VARCHAR(32) NOT NULL,
  charge_key CHAR(64) NOT NULL,
  order_id VARCHAR(64) NULL,
  consignment_id VARCHAR(255) NULL,
  merchant_reference VARCHAR(255) NULL,
  cod_fee DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  delivery_fee DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total_charge DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  collected_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(8) NOT NULL DEFAULT 'BDT',
  source_event_id VARCHAR(64) NULL,
  provider_updated_at DATETIME NULL,
  expense_transaction_id VARCHAR(64) NULL,
  expense_status VARCHAR(32) NOT NULL DEFAULT 'not_recorded',
  expense_error TEXT NULL,
  expense_recorded_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_courier_charge_provider_key (provider, charge_key),
  KEY idx_courier_charge_order (order_id, provider),
  KEY idx_courier_charge_consignment (provider, consignment_id),
  KEY idx_courier_charge_reference (provider, merchant_reference),
  CONSTRAINT fk_courier_charge_order FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE SET NULL,
  CONSTRAINT fk_courier_charge_event FOREIGN KEY (source_event_id) REFERENCES courier_webhook_events (id) ON DELETE SET NULL,
  CONSTRAINT fk_courier_charge_transaction FOREIGN KEY (expense_transaction_id) REFERENCES transactions (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `courier_poll_worker_state` (
  provider VARCHAR(32) NOT NULL,
  row_offset INT UNSIGNED NOT NULL DEFAULT 0,
  last_run_at DATETIME NULL,
  last_success_at DATETIME NULL,
  last_error_at DATETIME NULL,
  last_error TEXT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (provider)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `courier_tracking_events` (
  id VARCHAR(64) NOT NULL,
  provider VARCHAR(32) NOT NULL,
  event_key CHAR(64) NOT NULL,
  order_id VARCHAR(64) NOT NULL,
  consignment_id VARCHAR(255) NULL,
  merchant_reference VARCHAR(255) NULL,
  tracking_message TEXT NULL,
  event_at DATETIME NULL,
  received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_courier_tracking_provider_event (provider, event_key),
  KEY idx_courier_tracking_order_at (order_id, event_at),
  CONSTRAINT fk_courier_tracking_order FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS payroll_payments (
  id VARCHAR(64) NOT NULL,
  employee_id VARCHAR(64) NOT NULL,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  period_kind VARCHAR(16) NOT NULL,
  period_label VARCHAR(255) NOT NULL,
  unit_amount_snapshot DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  counted_statuses_snapshot LONGTEXT NULL,
  order_count_snapshot INT NOT NULL DEFAULT 0,
  compensation_type VARCHAR(32) NOT NULL DEFAULT 'commission',
  fixed_salary_snapshot DECIMAL(12,2) NULL,
  base_amount_snapshot DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  bonus_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  deduction_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  amount_snapshot DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  wallet_payout_id VARCHAR(64) NULL,
  transaction_id VARCHAR(64) NULL,
  account_id VARCHAR(64) NULL,
  payment_method VARCHAR(255) NULL,
  category_id VARCHAR(64) NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_by VARCHAR(64) NOT NULL,
  note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_payroll_payments_employee_paid_at (employee_id, paid_at),
  KEY idx_payroll_payments_period (period_start, period_end),
  KEY idx_payroll_payments_employee_period (employee_id, period_start, period_end),
  UNIQUE KEY uq_payroll_payments_wallet_payout (wallet_payout_id),
  UNIQUE KEY uq_payroll_payments_transaction (transaction_id),
  CONSTRAINT fk_payroll_payments_employee FOREIGN KEY (employee_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_payroll_payments_paid_by FOREIGN KEY (paid_by) REFERENCES users (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `payroll_payments`
  ADD COLUMN IF NOT EXISTS `compensation_type` VARCHAR(32) NOT NULL DEFAULT 'commission',
  ADD COLUMN IF NOT EXISTS `fixed_salary_snapshot` DECIMAL(12,2) NULL,
  ADD COLUMN IF NOT EXISTS `base_amount_snapshot` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `bonus_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `deduction_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `wallet_payout_id` VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS `transaction_id` VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS `account_id` VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS `payment_method` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `category_id` VARCHAR(64) NULL;
ALTER TABLE `payroll_payments`
  ADD KEY IF NOT EXISTS `idx_payroll_payments_employee_period` (`employee_id`, `period_start`, `period_end`),
  ADD UNIQUE KEY IF NOT EXISTS `uq_payroll_payments_wallet_payout` (`wallet_payout_id`),
  ADD UNIQUE KEY IF NOT EXISTS `uq_payroll_payments_transaction` (`transaction_id`);
CREATE TABLE IF NOT EXISTS wallet_payouts (
  id VARCHAR(64) NOT NULL,
  employee_id VARCHAR(64) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  account_id VARCHAR(64) NOT NULL,
  payment_method VARCHAR(255) NOT NULL,
  category_id VARCHAR(64) NOT NULL,
  transaction_id VARCHAR(64) NOT NULL,
  payroll_payment_id VARCHAR(64) NULL,
  paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_by VARCHAR(64) NOT NULL,
  note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_wallet_payouts_transaction_id (transaction_id),
  UNIQUE KEY uq_wallet_payouts_payroll_payment (payroll_payment_id),
  KEY idx_wallet_payouts_employee_paid_at (employee_id, paid_at),
  KEY idx_wallet_payouts_paid_at (paid_at),
  CONSTRAINT fk_wallet_payouts_employee FOREIGN KEY (employee_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_wallet_payouts_account FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
  CONSTRAINT fk_wallet_payouts_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE RESTRICT,
  CONSTRAINT fk_wallet_payouts_transaction FOREIGN KEY (transaction_id) REFERENCES transactions (id) ON DELETE RESTRICT,
  CONSTRAINT fk_wallet_payouts_paid_by FOREIGN KEY (paid_by) REFERENCES users (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `wallet_payouts`
  ADD COLUMN IF NOT EXISTS `transaction_id` VARCHAR(64) NULL,
  ADD COLUMN IF NOT EXISTS `payroll_payment_id` VARCHAR(64) NULL;
ALTER TABLE `wallet_payouts`
  ADD UNIQUE KEY IF NOT EXISTS `uq_wallet_payouts_payroll_payment` (`payroll_payment_id`);
CREATE TABLE IF NOT EXISTS wallet_entries (
  id VARCHAR(64) NOT NULL,
  employee_id VARCHAR(64) NOT NULL,
  entry_type VARCHAR(32) NOT NULL,
  amount_delta DECIMAL(12,2) NOT NULL,
  unit_amount_snapshot DECIMAL(12,2) NULL,
  source_order_id VARCHAR(64) NULL,
  source_order_number VARCHAR(100) NULL,
  wallet_payout_id VARCHAR(64) NULL,
  payroll_payment_id VARCHAR(64) NULL,
  note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by VARCHAR(64) NULL,
  PRIMARY KEY (id),
  KEY idx_wallet_entries_order_entry_type (source_order_id, entry_type),
  UNIQUE KEY uq_wallet_entries_wallet_payout_id (wallet_payout_id),
  KEY idx_wallet_entries_employee_created_at (employee_id, created_at),
  KEY idx_wallet_entries_created_at (created_at),
  KEY idx_wallet_entries_entry_type (entry_type),
  KEY idx_wallet_entries_payroll_payment (payroll_payment_id),
  UNIQUE KEY uq_wallet_entries_payroll_entry (payroll_payment_id, entry_type),
  CONSTRAINT fk_wallet_entries_employee FOREIGN KEY (employee_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_wallet_entries_order FOREIGN KEY (source_order_id) REFERENCES orders (id) ON DELETE SET NULL,
  CONSTRAINT fk_wallet_entries_wallet_payout FOREIGN KEY (wallet_payout_id) REFERENCES wallet_payouts (id) ON DELETE SET NULL,
  CONSTRAINT fk_wallet_entries_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
ALTER TABLE `wallet_entries`
  ADD COLUMN IF NOT EXISTS `payroll_payment_id` VARCHAR(64) NULL;
ALTER TABLE `wallet_entries`
  ADD KEY IF NOT EXISTS `idx_wallet_entries_order_entry_type` (`source_order_id`, `entry_type`);
ALTER TABLE `wallet_entries`
  DROP INDEX IF EXISTS `uq_wallet_entries_order_entry_type`,
  ADD KEY IF NOT EXISTS `idx_wallet_entries_payroll_payment` (`payroll_payment_id`),
  ADD UNIQUE KEY IF NOT EXISTS `uq_wallet_entries_payroll_entry` (`payroll_payment_id`, `entry_type`);
DROP VIEW IF EXISTS orders_with_customer_creator;
ALTER TABLE `orders`
  ADD COLUMN IF NOT EXISTS `pathao_consignment_id` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `exchange_pathao_consignment_id` VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS `steadfast_invoice` VARCHAR(100) NULL,
  ADD COLUMN IF NOT EXISTS `steadfast_tracking_link` VARCHAR(1000) NULL,
  ADD COLUMN IF NOT EXISTS `source_ad` VARCHAR(64) NULL;
ALTER TABLE `orders`
  ADD KEY IF NOT EXISTS `idx_orders_pathao_consignment_id` (`pathao_consignment_id`);
ALTER TABLE `orders`
  ADD UNIQUE KEY IF NOT EXISTS `uq_orders_steadfast_invoice` (`steadfast_invoice`);
CREATE VIEW orders_with_customer_creator AS
SELECT
  o.id,
  o.order_number AS orderNumber,
  o.order_date AS orderDate,
  o.customer_id AS customerId,
  o.page_id AS pageId,
  c.name AS customerName,
  c.phone AS customerPhone,
  c.address AS customerAddress,
  o.created_by AS createdBy,
  u.name AS creatorName,
  o.status,
  o.items,
  o.subtotal,
  o.discount,
  o.shipping,
  o.total,
  o.paid_amount AS paidAmount,
  o.notes,
  o.history,
  o.page_snapshot AS pageSnapshot,
  o.created_at AS createdAt,
  o.deleted_at AS deletedAt,
  o.deleted_by AS deletedBy,
  o.carrybee_consignment_id AS carrybeeConsignmentId,
  o.steadfast_consignment_id AS steadfastConsignmentId,
  o.steadfast_invoice AS steadfastInvoice,
  o.steadfast_tracking_link AS steadfastTrackingLink,
  o.paperfly_tracking_number AS paperflyTrackingNumber,
  o.pathao_consignment_id AS pathaoConsignmentId,
  o.exchange_courier AS exchangeCourier,
  o.exchange_steadfast_consignment_id AS exchangeSteadfastConsignmentId,
  o.exchange_carrybee_consignment_id AS exchangeCarrybeeConsignmentId,
  o.exchange_paperfly_tracking_number AS exchangePaperflyTrackingNumber,
  o.exchange_pathao_consignment_id AS exchangePathaoConsignmentId,
  o.exchange_courier_history AS exchangeCourierHistory,
  o.source_ad AS sourceAd,
  o.processed_at AS processedAt,
  o.courier_assigned_at AS courierAssignedAt,
  o.picked_at AS pickedAt,
  o.completed_at AS completedAt,
  o.returned_at AS returnedAt,
  o.cancelled_at AS cancelledAt,
  o.partial_delivered_at AS partialDeliveredAt,
  o.exchange_processing_at AS exchangeProcessingAt,
  o.exchange_picked_at AS exchangePickedAt,
  o.exchange_delivered_at AS exchangeDeliveredAt,
  o.exchange_returned_at AS exchangeReturnedAt,
  o.exchange_cancelled_at AS exchangeCancelledAt
FROM orders o
LEFT JOIN customers c ON c.id = o.customer_id
LEFT JOIN users u ON u.id = o.created_by
WHERE o.deleted_at IS NULL;
DROP VIEW IF EXISTS bills_with_vendor_creator;
CREATE VIEW bills_with_vendor_creator AS
SELECT
  b.id,
  b.bill_number AS billNumber,
  b.bill_date AS billDate,
  b.vendor_id AS vendorId,
  v.name AS vendorName,
  v.phone AS vendorPhone,
  v.address AS vendorAddress,
  b.created_by AS createdBy,
  u.name AS creatorName,
  b.status,
  b.items,
  b.subtotal,
  b.discount,
  b.shipping,
  b.total,
  b.paid_amount AS paidAmount,
  b.notes,
  b.history,
  b.created_at AS createdAt,
  b.deleted_at AS deletedAt,
  b.deleted_by AS deletedBy
FROM bills b
LEFT JOIN vendors v ON v.id = b.vendor_id
LEFT JOIN users u ON u.id = b.created_by
WHERE b.deleted_at IS NULL;
DROP VIEW IF EXISTS transactions_with_relations;
CREATE VIEW transactions_with_relations AS
SELECT
  t.id,
  t.date,
  t.type,
  t.category,
  t.account_id AS accountId,
  a.name AS accountName,
  t.to_account_id AS toAccountId,
  t.amount,
  t.description,
  t.reference_id AS referenceId,
  t.contact_id AS contactId,
  COALESCE(c.name, v.name) AS contactName,
  CASE
    WHEN c.id IS NOT NULL THEN 'Customer'
    WHEN v.id IS NOT NULL THEN 'Vendor'
    ELSE NULL
  END AS contactType,
  t.payment_method AS paymentMethod,
  t.attachment_name AS attachmentName,
  t.attachment_url AS attachmentUrl,
  t.created_by AS createdBy,
  u.name AS creatorName,
  t.approval_status AS approvalStatus,
  t.account_effect_applied AS accountEffectApplied,
  t.approval_requested_at AS approvalRequestedAt,
  t.approved_at AS approvedAt,
  t.declined_at AS declinedAt,
  t.approval_note AS approvalNote,
  t.created_at AS createdAt,
  t.deleted_at AS deletedAt,
  t.deleted_by AS deletedBy
FROM transactions t
LEFT JOIN accounts a ON a.id = t.account_id
LEFT JOIN customers c ON c.id = t.contact_id
LEFT JOIN vendors v ON v.id = t.contact_id
LEFT JOIN users u ON u.id = t.created_by
WHERE t.deleted_at IS NULL;
DROP VIEW IF EXISTS employee_wallet_balances;
CREATE VIEW employee_wallet_balances AS
SELECT
  u.id AS employeeId,
  u.name AS employeeName,
  u.role AS employeeRole,
  ROUND(COALESCE(SUM(
    CASE
      WHEN we.entry_type IN ('order_credit', 'order_reversal')
        AND o.created_at >= '2026-03-31 18:00:00' THEN we.amount_delta
      WHEN we.entry_type NOT IN ('order_credit', 'order_reversal')
        AND we.created_at >= '2026-03-31 18:00:00' THEN we.amount_delta
      ELSE 0
    END
  ), 0), 2) AS currentBalance,
  ROUND(COALESCE(SUM(
    CASE
      WHEN we.entry_type = 'order_credit'
        AND o.created_at >= '2026-03-31 18:00:00' THEN we.amount_delta
      ELSE 0
    END
  ), 0), 2) AS totalEarned,
  ROUND(ABS(COALESCE(SUM(
    CASE
      WHEN we.entry_type = 'payout'
        AND we.created_at >= '2026-03-31 18:00:00' THEN we.amount_delta
      ELSE 0
    END
  ), 0)), 2) AS totalPaid,
  COALESCE(active_wallet_orders.credited_orders, 0) AS creditedOrders,
  MAX(
    CASE
      WHEN we.entry_type IN ('order_credit', 'order_reversal')
        AND o.created_at >= '2026-03-31 18:00:00' THEN we.created_at
      WHEN we.entry_type NOT IN ('order_credit', 'order_reversal')
        AND we.created_at >= '2026-03-31 18:00:00' THEN we.created_at
      ELSE NULL
    END
  ) AS lastActivityAt
FROM users u
LEFT JOIN wallet_entries we ON we.employee_id = u.id
LEFT JOIN orders o ON o.id = we.source_order_id
LEFT JOIN (
  SELECT
    active_order_credits.employee_id,
    COUNT(*) AS credited_orders
  FROM (
    SELECT
      we.employee_id,
      we.source_order_id
    FROM wallet_entries we
    INNER JOIN orders o ON o.id = we.source_order_id
    WHERE we.entry_type IN ('order_credit', 'order_reversal')
      AND o.created_at >= '2026-03-31 18:00:00'
    GROUP BY we.employee_id, we.source_order_id
    HAVING ROUND(COALESCE(SUM(we.amount_delta), 0), 2) > 0
  ) active_order_credits
  GROUP BY active_order_credits.employee_id
) active_wallet_orders ON active_wallet_orders.employee_id = u.id
WHERE u.role IN ('Employee')
  AND u.deleted_at IS NULL
GROUP BY u.id, u.name, u.role, active_wallet_orders.credited_orders;
DROP VIEW IF EXISTS wallet_activity_with_relations;
CREATE VIEW wallet_activity_with_relations AS
SELECT
  we.id,
  we.employee_id AS employeeId,
  employee_user.name AS employeeName,
  employee_user.role AS employeeRole,
  we.entry_type AS entryType,
  we.amount_delta AS amountDelta,
  we.unit_amount_snapshot AS unitAmountSnapshot,
  we.source_order_id AS orderId,
  COALESCE(we.source_order_number, o.order_number) AS orderNumber,
  we.wallet_payout_id AS payoutId,
  COALESCE(we.payroll_payment_id, wp.payroll_payment_id) AS payrollPaymentId,
  wp.transaction_id AS transactionId,
  wp.account_id AS accountId,
  a.name AS accountName,
  wp.payment_method AS paymentMethod,
  wp.category_id AS categoryId,
  c.name AS categoryName,
  pp.compensation_type AS compensationType,
  pp.base_amount_snapshot AS baseAmountSnapshot,
  pp.bonus_amount AS bonusAmount,
  pp.deduction_amount AS deductionAmount,
  pp.amount_snapshot AS netAmount,
  pp.period_start AS periodStart,
  pp.period_end AS periodEnd,
  we.note,
  we.created_at AS createdAt,
  we.created_by AS createdBy,
  creator_user.name AS createdByName,
  wp.paid_at AS paidAt,
  wp.paid_by AS paidBy,
  paid_by_user.name AS paidByName
FROM wallet_entries we
LEFT JOIN users employee_user ON employee_user.id = we.employee_id
LEFT JOIN orders o ON o.id = we.source_order_id
LEFT JOIN wallet_payouts wp ON wp.id = we.wallet_payout_id
LEFT JOIN payroll_payments pp ON pp.id = COALESCE(we.payroll_payment_id, wp.payroll_payment_id)
LEFT JOIN accounts a ON a.id = wp.account_id
LEFT JOIN categories c ON c.id = wp.category_id
LEFT JOIN users creator_user ON creator_user.id = we.created_by
LEFT JOIN users paid_by_user ON paid_by_user.id = wp.paid_by;

-- v0.0.42: Order/Bill Return & Exchange
-- No schema changes. Return/exchange tracking uses existing items JSON column.
-- New fields inside items JSON: returnedQty, exchangedQty, exchangedWith.
-- New API endpoints: processOrderReturnExchange, processBillReturn.
-- New permission keys: orders.processReturnExchangeOwn/Any, bills.processReturnOwn/Any.
-- See migrations/2026-07-11_order_bill_return_exchange.sql for details.

-- Production-scale stable pagination indexes (2026-08-08).
ALTER TABLE `users`
  ADD INDEX IF NOT EXISTS `idx_users_active_created_id` (`deleted_at`, `is_system`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_users_active_role_name_id` (`deleted_at`, `is_system`, `role`, `name`, `id`);
ALTER TABLE `customers`
  ADD INDEX IF NOT EXISTS `idx_customers_active_created_id` (`deleted_at`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_customers_active_creator_created_id` (`deleted_at`, `created_by`, `created_at`, `id`);
ALTER TABLE `vendors`
  ADD INDEX IF NOT EXISTS `idx_vendors_active_created_id` (`deleted_at`, `created_at`, `id`);
ALTER TABLE `products`
  ADD INDEX IF NOT EXISTS `idx_products_active_created_id` (`deleted_at`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_products_active_category_created_id` (`deleted_at`, `category`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_products_active_creator_created_id` (`deleted_at`, `created_by`, `created_at`, `id`);
ALTER TABLE `orders`
  ADD INDEX IF NOT EXISTS `idx_orders_active_created_id` (`deleted_at`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_orders_active_status_created_id` (`deleted_at`, `status`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_orders_active_creator_created_id` (`deleted_at`, `created_by`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_orders_active_customer_created_id` (`deleted_at`, `customer_id`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_orders_active_source_ad_created_id` (`deleted_at`, `source_ad`, `created_at`, `id`);
ALTER TABLE `bills`
  ADD INDEX IF NOT EXISTS `idx_bills_active_created_id` (`deleted_at`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_bills_active_status_created_id` (`deleted_at`, `status`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_bills_active_creator_created_id` (`deleted_at`, `created_by`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_bills_active_vendor_created_id` (`deleted_at`, `vendor_id`, `created_at`, `id`);
ALTER TABLE `transactions`
  ADD INDEX IF NOT EXISTS `idx_transactions_active_created_id` (`deleted_at`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_transactions_active_date_id` (`deleted_at`, `date`, `id`),
  ADD INDEX IF NOT EXISTS `idx_transactions_active_type_created_id` (`deleted_at`, `type`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_transactions_active_approval_created_id` (`deleted_at`, `approval_status`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_transactions_active_creator_created_id` (`deleted_at`, `created_by`, `created_at`, `id`);
ALTER TABLE `lead_profiles`
  ADD INDEX IF NOT EXISTS `idx_leads_active_updated_id` (`archived_at`, `updated_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_leads_active_status_updated_id` (`archived_at`, `status`, `updated_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_leads_active_channel_updated_id` (`archived_at`, `source_channel`, `updated_at`, `id`);
ALTER TABLE `notifications`
  ADD INDEX IF NOT EXISTS `idx_notifications_active_updated_id` (`is_active`, `updated_at`, `id`);
ALTER TABLE `notification_receipts`
  ADD INDEX IF NOT EXISTS `idx_notification_receipts_user_updated` (`user_id`, `updated_at`, `notification_id`);
ALTER TABLE `whatsapp_contacts`
  ADD INDEX IF NOT EXISTS `idx_whatsapp_contacts_last_message_id` (`last_message_at`, `updated_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_whatsapp_contacts_unread_last_message_id` (`unread_count`, `last_message_at`, `id`);
ALTER TABLE `whatsapp_messages`
  ADD INDEX IF NOT EXISTS `idx_whatsapp_messages_contact_time_id` (`contact_id`, `message_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_whatsapp_messages_contact_updated_id` (`contact_id`, `updated_at`, `id`);
ALTER TABLE `messenger_contacts`
  ADD INDEX IF NOT EXISTS `idx_messenger_contacts_last_message_id` (`last_message_at`, `updated_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_messenger_contacts_unread_last_message_id` (`unread_count`, `last_message_at`, `id`);
ALTER TABLE `messenger_messages`
  ADD INDEX IF NOT EXISTS `idx_messenger_messages_contact_time_id` (`contact_id`, `message_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_messenger_messages_contact_updated_id` (`contact_id`, `updated_at`, `id`);
ALTER TABLE `meta_ads`
  ADD INDEX IF NOT EXISTS `idx_meta_ads_status_updated_id` (`effective_status`, `updated_time`, `id`),
  ADD INDEX IF NOT EXISTS `idx_meta_ads_account_updated_id` (`ad_account_id`, `updated_time`, `id`),
  ADD INDEX IF NOT EXISTS `idx_meta_ads_business_updated_id` (`business_id`, `updated_time`, `id`),
  ADD INDEX IF NOT EXISTS `idx_meta_ads_campaign_updated_id` (`campaign_id`, `updated_time`, `id`);
ALTER TABLE `wallet_entries`
  ADD INDEX IF NOT EXISTS `idx_wallet_entries_employee_created_id` (`employee_id`, `created_at`, `id`),
  ADD INDEX IF NOT EXISTS `idx_wallet_entries_employee_type_order` (`employee_id`, `entry_type`, `source_order_id`, `created_at`, `id`);
ALTER TABLE `payroll_payments`
  ADD INDEX IF NOT EXISTS `idx_payroll_payments_type_employee_paid_id` (`compensation_type`, `employee_id`, `paid_at`, `id`);
ALTER TABLE `recurring_transactions`
  ADD INDEX IF NOT EXISTS `idx_recurring_active_next_run_id` (`is_active`, `next_run_at`, `id`);

-- ─── Batch Management Tables ───────────────────────────────────────

CREATE TABLE IF NOT EXISTS batch_categories (
  id VARCHAR(36) NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT NULL,
  color VARCHAR(50) NOT NULL DEFAULT '#ebf4ff',
  parent_id VARCHAR(36) NULL,
  is_system TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(36) NULL,
  PRIMARY KEY (id),
  KEY idx_batch_categories_parent_id (parent_id),
  KEY idx_batch_categories_deleted_at (deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS batches (
  id VARCHAR(36) NOT NULL,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NULL,
  sku VARCHAR(100) NULL,
  category_id VARCHAR(36) NULL,
  image VARCHAR(500) NOT NULL DEFAULT '/uploads/Empty_product.png',
  population INT NOT NULL DEFAULT 0,
  average_age_days INT NOT NULL DEFAULT 0,
  sale_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  purchase_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  description TEXT NULL,
  created_by VARCHAR(36) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at DATETIME NULL,
  deleted_by VARCHAR(36) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_batches_slug (slug),
  KEY idx_batches_category_id (category_id),
  KEY idx_batches_created_by (created_by),
  KEY idx_batches_deleted_at (deleted_at),
  CONSTRAINT fk_batches_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS batch_event_types (
  id VARCHAR(36) NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT NULL,
  is_system TINYINT(1) NOT NULL DEFAULT 1,
  requires_population_change TINYINT(1) NOT NULL DEFAULT 0,
  requires_expense_amount TINYINT(1) NOT NULL DEFAULT 0,
  requires_account_id TINYINT(1) NOT NULL DEFAULT 0,
  requires_payment_method TINYINT(1) NOT NULL DEFAULT 0,
  requires_notes TINYINT(1) NOT NULL DEFAULT 0,
  stock_adjustment_direction VARCHAR(20) NOT NULL DEFAULT 'none',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS batch_events (
  id VARCHAR(36) NOT NULL,
  batch_id VARCHAR(36) NOT NULL,
  event_type_id VARCHAR(36) NOT NULL,
  event_date DATE NOT NULL,
  population_change INT NOT NULL DEFAULT 0,
  population_after INT NOT NULL DEFAULT 0,
  expense_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  account_id VARCHAR(36) NULL,
  payment_method VARCHAR(36) NULL,
  notes TEXT NULL,
  created_by VARCHAR(36) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_batch_events_batch_id (batch_id),
  KEY idx_batch_events_event_type_id (event_type_id),
  KEY idx_batch_events_event_date (event_date),
  KEY idx_batch_events_created_by (created_by),
  CONSTRAINT fk_batch_events_batch FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
  CONSTRAINT fk_batch_events_event_type FOREIGN KEY (event_type_id) REFERENCES batch_event_types(id) ON DELETE RESTRICT,
  CONSTRAINT fk_batch_events_account FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_batch_events_payment_method FOREIGN KEY (payment_method) REFERENCES payment_methods(id) ON DELETE SET NULL,
  CONSTRAINT fk_batch_events_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS batch_stock_adjustments (
  id VARCHAR(36) NOT NULL,
  batch_id VARCHAR(36) NOT NULL,
  change_amount INT NOT NULL DEFAULT 0,
  direction VARCHAR(20) NOT NULL,
  created_by VARCHAR(36) NULL,
  event_id VARCHAR(36) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_batch_stock_adj_batch_id (batch_id),
  KEY idx_batch_stock_adj_event_id (event_id),
  CONSTRAINT fk_batch_stock_adj_batch FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
  CONSTRAINT fk_batch_stock_adj_event FOREIGN KEY (event_id) REFERENCES batch_events(id) ON DELETE SET NULL,
  CONSTRAINT fk_batch_stock_adj_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Fix: point batches.category_id FK to categories (where Batch-type categories live)
ALTER TABLE `batches` DROP FOREIGN KEY `fk_batches_category`;
ALTER TABLE `batches` ADD CONSTRAINT `fk_batches_category` FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL;
