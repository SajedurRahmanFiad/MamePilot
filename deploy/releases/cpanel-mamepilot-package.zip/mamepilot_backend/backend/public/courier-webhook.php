<?php

declare(strict_types=1);

use App\Auth;
use App\Config;
use App\CourierApi;
use App\Database;
use App\OperationsApi;

require_once dirname(__DIR__) . '/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['error' => 'Method not allowed.']);
    exit;
}

try {
    $provider = strtolower(trim((string) ($_GET['provider'] ?? '')));
    $rawBody = (string) file_get_contents('php://input');
    $headers = [];
    if (function_exists('getallheaders')) {
        foreach ((array) getallheaders() as $name => $value) {
            if (is_scalar($value)) {
                $headers[(string) $name] = (string) $value;
            }
        }
    }
    foreach ($_SERVER as $name => $value) {
        if (!is_scalar($value)) {
            continue;
        }
        if (str_starts_with($name, 'HTTP_')) {
            $headerName = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
            $headers[$headerName] = (string) $value;
        } elseif ($name === 'CONTENT_TYPE') {
            $headers['Content-Type'] = (string) $value;
        }
    }
    foreach (['HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION', 'Authorization'] as $authorizationKey) {
        if (isset($_SERVER[$authorizationKey]) && is_scalar($_SERVER[$authorizationKey])) {
            $headers['Authorization'] = (string) $_SERVER[$authorizationKey];
            break;
        }
    }

    $config = Config::load(dirname(__DIR__, 2));
    $database = new Database($config);
    if ($provider === 'pathao') {
        $settings = $database->fetchOne('SELECT pathao_merchant_webhook_secret FROM courier_settings LIMIT 1') ?? [];
        $merchantSecret = trim((string) ($settings['pathao_merchant_webhook_secret'] ?? ''));
        if ($merchantSecret !== '') {
            header('X-Pathao-Merchant-Webhook-Integration-Secret: ' . $merchantSecret, true);
        }
    }
    $auth = new Auth($config, $database);
    $operations = new OperationsApi($database, $auth, $config);
    $courier = new CourierApi($database, $auth, $config, $operations);
    $result = $courier->handleWebhook($provider, $rawBody, $headers);

    if ($provider === 'carrybee' && !empty($result['integrationVerified'])) {
        // CarryBee requires HTTP 202 plus the configured integration header
        // name/value for the webhook.integration handshake only; real events
        // are acknowledged with a normal 200 response.
        http_response_code(202);
        $integrationHeader = trim((string) ($result['webhookIntegrationHeader'] ?? ''));
        $integrationValue = trim((string) ($result['webhookIntegrationValue'] ?? ''));
        if ($integrationHeader !== '' && $integrationValue !== '') {
            header($integrationHeader . ': ' . $integrationValue, true);
        }
    } elseif ($provider === 'pathao' && !empty($result['integrationVerified'])) {
        http_response_code(202);
    } else {
        http_response_code(200);
    }
    if ($provider === 'steadfast') {
        $result = array_merge([
            'status' => 'success',
            'message' => 'Webhook received successfully.',
        ], $result);
    }
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $exception) {
    $message = $exception->getMessage();
    error_log('Courier webhook processing failed for provider ' . ($provider ?? 'unknown') . ': ' . $message);
    $isAuthenticationError = str_contains(strtolower($message), 'signature');
    $isPayloadError = str_contains(strtolower($message), 'json')
        || str_contains(strtolower($message), 'payload')
        || str_contains(strtolower($message), 'provider');
    http_response_code($isAuthenticationError ? 403 : ($isPayloadError ? 400 : 500));
    echo json_encode([
        'status' => 'error',
        'message' => $isAuthenticationError
            ? 'Webhook verification failed.'
            : ($isPayloadError ? $message : 'Courier webhook processing failed.'),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
